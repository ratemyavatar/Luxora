using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Roblox.Games.Relay.Properties;

[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "12.0.0.0")]
[CompilerGenerated]
internal sealed class Settings : ApplicationSettingsBase
{
	private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

	public static Settings Default => defaultInstance;

	[DefaultSettingValue("Information")]
	[ApplicationScopedSetting]
	[DebuggerNonUserCode]
	public string LogLevel => (string)this["LogLevel"];

	[ApplicationScopedSetting]
	[DefaultSettingValue("00000000-0000-0000-0000-000000000000")]
	[DebuggerNonUserCode]
	public Guid GamesRelayApiKey => (Guid)this["GamesRelayApiKey"];

	[DefaultSettingValue("00:00:04")]
	[ApplicationScopedSetting]
	[DebuggerNonUserCode]
	public TimeSpan RequestDispatchInterval => (TimeSpan)this["RequestDispatchInterval"];

	[ApplicationScopedSetting]
	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	public string GameServiceUrl => (string)this["GameServiceUrl"];

	[DefaultSettingValue("http://localhost:64989")]
	[DebuggerNonUserCode]
	[ApplicationScopedSetting]
	public string ArbiterEndpoint => (string)this["ArbiterEndpoint"];
}
