using System;
using JetBrains.Annotations;

namespace Roblox.EventLog;

public interface ILogger
{
	Func<LogLevel> MaxLogLevel { get; set; }

	bool LogThreadID { get; set; }

	[StringFormatMethod("format")]
	void Debug(string format, params object[] args);

	[StringFormatMethod("format")]
	void Error(Exception ex);

	[StringFormatMethod("format")]
	void Error(string format, params object[] args);

	[StringFormatMethod("format")]
	void Info(string format, params object[] args);

	void Info(Func<string> messageGetter);

	[StringFormatMethod("format")]
	void Warning(string format, params object[] args);

	[StringFormatMethod("format")]
	void Verbose(string format, params object[] args);

	void Verbose(Func<string> messageGetter);

	[StringFormatMethod("format")]
	void LifecycleEvent(string format, params object[] args);
}
