using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;

namespace Roblox.EventLog;

public class Logger : ILogger
{
	private const int _MaximumEventLogMessageSize = 30000;

	public static ILogger DummyLogger = new Logger("DummyLogger", () => LogLevel.None);

	private readonly string _Source;

	public Func<LogLevel> MaxLogLevel { get; set; }

	public bool LogToConsole { get; set; }

	public bool LogThreadID { get; set; }

	public bool LogMethodName { get; set; }

	public bool LogClassAndMethodName { get; set; }

	public Logger(string source, Func<LogLevel> maxLogLevel, bool logThreadID = false)
	{
		if (!System.Diagnostics.EventLog.SourceExists(source))
		{
			MaxLogLevel = () => LogLevel.None;
			if (source != "DummyLogger")
			{
				string text = $"EventLog source: {source}. Doesn't exist. There will be no logging";
				WriteEventLogEntry("Roblox", text, EventLogEntryType.Warning);
				WriteEventLogEntry("Application", text, EventLogEntryType.Warning);
				Console.WriteLine(text);
			}
		}
		else
		{
			_Source = source;
			MaxLogLevel = maxLogLevel;
			LogThreadID = logThreadID;
		}
	}

	public Logger(string source, Func<string> maxLogLevel, bool logThreadID = false)
		: this(source, () => (LogLevel)Enum.Parse(typeof(LogLevel), maxLogLevel()), logThreadID)
	{
	}

	public Logger(string source, LogLevel maxLogLevel = LogLevel.Information, bool logThreadID = false)
		: this(source, () => maxLogLevel, logThreadID)
	{
	}

	private string GetPrefix()
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (LogThreadID)
		{
			Thread currentThread = Thread.CurrentThread;
			string arg = currentThread.Name ?? currentThread.ManagedThreadId.ToString();
			stringBuilder.AppendFormat("[{0}] ", arg);
		}
		if (LogMethodName || LogClassAndMethodName)
		{
			StackFrame stackFrame = new StackFrame(3, fNeedFileInfo: true);
			MethodBase method = stackFrame.GetMethod();
			string arg2 = ((method != null) ? method.Name : "<Unknown method>");
			string arg3 = "";
			if (LogClassAndMethodName)
			{
				arg3 = ((method != null && method.DeclaringType != null) ? (method.DeclaringType.Name + ".") : "");
			}
			stringBuilder.AppendFormat("[{0}{1}] ", arg3, arg2);
		}
		return stringBuilder.ToString();
	}

	private void Log(EventLogEntryType entryType, string format, params object[] args)
	{
		try
		{
			string text = ((args == null || args.Length <= 0) ? format : string.Format(format, args));
			string prefix = GetPrefix();
			if (LogToConsole)
			{
				Console.WriteLine("[{0}] {1}", entryType, prefix + text);
			}
			WriteEventLogEntry(_Source, prefix + text, entryType);
		}
		catch (Exception ex)
		{
			string message = string.Empty;
			try
			{
				Func<string, string[]> func = (string s) => s.Split(new string[1] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
				List<string> second = func(Environment.StackTrace).Skip(3).ToList();
				string[] second2 = func(ex.StackTrace);
				string[] first = new string[1] { ex.Message };
				IEnumerable<string> values = first.Concat(second2).Concat(second);
				message = string.Join("\r\n", values);
				WriteEventLogEntry(_Source, message, entryType);
			}
			catch (Exception)
			{
				try
				{
					WriteEventLogEntry("Application", message, entryType);
				}
				catch (Exception)
				{
				}
			}
		}
	}

	public void Debug(string format, params object[] args)
	{
	}

	public void Error(Exception ex)
	{
		if (MaxLogLevel() >= LogLevel.Error)
		{
			Log(EventLogEntryType.Error, ex.ToString());
		}
	}

	public void Error(string format, params object[] args)
	{
		if (MaxLogLevel() >= LogLevel.Error)
		{
			Log(EventLogEntryType.Error, format, args);
		}
	}

	public void Info(string format, params object[] args)
	{
		if (MaxLogLevel() >= LogLevel.Information)
		{
			Log(EventLogEntryType.Information, format, args);
		}
	}

	public void Info(Func<string> messageGetter)
	{
		if (MaxLogLevel() >= LogLevel.Information)
		{
			Log(EventLogEntryType.Information, messageGetter(), null);
		}
	}

	public void Warning(string format, params object[] args)
	{
		if (MaxLogLevel() >= LogLevel.Warning)
		{
			Log(EventLogEntryType.Warning, format, args);
		}
	}

	public void Verbose(string format, params object[] args)
	{
		if (MaxLogLevel() >= LogLevel.Verbose)
		{
			Log(EventLogEntryType.Information, format, args);
		}
	}

	public void Verbose(Func<string> messageGetter)
	{
		if (MaxLogLevel() >= LogLevel.Verbose)
		{
			Log(EventLogEntryType.Information, messageGetter(), null);
		}
	}

	public void LifecycleEvent(string format, params object[] args)
	{
		Log(EventLogEntryType.Information, format, args);
	}

	private static void WriteEventLogEntry(string source, string message, EventLogEntryType entryType)
	{
		if (message.Length > 30000)
		{
			message = "MESSAGE TRIMMED: " + message.Substring(0, 30000);
		}
		System.Diagnostics.EventLog.WriteEntry(source, message, entryType);
	}
}
