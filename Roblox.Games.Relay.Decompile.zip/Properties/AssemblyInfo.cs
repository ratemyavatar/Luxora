using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("Roblox.Games.Relay")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: Guid("84b1310e-63a4-4669-b6f8-11ec7dc38ae6")]
[assembly: AssemblyCompany("ROBLOX")]
[assembly: ComVisible(false)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Roblox.Games.Relay")]
[assembly: AssemblyCopyright("Copyright © ROBLOX 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.5855.31724")]
