using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Threading;
using Microsoft.VisualBasic.Devices;

namespace Roblox.Games.Relay;

internal sealed class PerfStatsMonitor : IDisposable
{
	private const int _TimerIntervalInMilliseconds = 1000;

	private const float _BytesInGigabyte = 1.0737418E+09f;

	private static readonly string _AssemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();

	private readonly ComputerInfo _ComputerInfo = new ComputerInfo();

	private readonly int _LogicalCoreCount = Environment.ProcessorCount;

	private List<NetworkAdapterMonitor> _Adapters = new List<NetworkAdapterMonitor>();

	private PerformanceCounter _ProcessorTimeTotalCounter;

	private Timer _Timer;

	private float _CpuUsage;

	private int _PhysicalCoreCount;

	private float _TotalPhysicalMemory;

	internal void Start()
	{
		_TotalPhysicalMemory = (float)_ComputerInfo.TotalPhysicalMemory / 1.0737418E+09f;
		PerformanceCounterCategory performanceCounterCategory = new PerformanceCounterCategory("Network Interface");
		IEnumerable<string> source = from n in performanceCounterCategory.GetInstanceNames()
			where n != "MS TCP Loopback interface"
			select n;
		_Adapters = source.Select((string n) => new NetworkAdapterMonitor(n)).ToList();
		_ProcessorTimeTotalCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
		_Timer = new Timer(TimerTick, null, 1000, 1000);
		ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select NumberOfCores from Win32_Processor");
		ManagementObjectCollection source2 = managementObjectSearcher.Get();
		_PhysicalCoreCount = source2.Cast<ManagementBaseObject>().Sum((ManagementBaseObject item) => int.Parse(item["NumberOfCores"].ToString()));
	}

	internal ServerStatistics GetServerStatistics()
	{
		ServerStatistics serverStatistics = new ServerStatistics();
		serverStatistics.TotalPhysicalMemoryGigabytes = _TotalPhysicalMemory;
		serverStatistics.ProcessorCount = _PhysicalCoreCount;
		serverStatistics.LogicalProcessorCount = _LogicalCoreCount;
		serverStatistics.AvailablePhysicalMemoryGigabytes = (float)_ComputerInfo.AvailablePhysicalMemory / 1.0737418E+09f;
		serverStatistics.UploadSpeedKilobytesPerSecond = _Adapters.Sum((NetworkAdapterMonitor a) => a.UploadSpeedKilobytesPerSecond);
		serverStatistics.DownloadSpeedKilobytesPerSecond = _Adapters.Sum((NetworkAdapterMonitor a) => a.DownloadSpeedKilobytesPerSecond);
		serverStatistics.RccServiceProcesses = Process.GetProcessesByName("RCCService").Length;
		serverStatistics.CpuUsage = _CpuUsage;
		serverStatistics.GamesRelayVersion = _AssemblyVersion;
		return serverStatistics;
	}

	private void TimerTick(object state)
	{
		_Adapters.ForEach(delegate(NetworkAdapterMonitor a)
		{
			a.Refresh();
		});
		_CpuUsage = _ProcessorTimeTotalCounter.NextValue();
	}

	public void Dispose()
	{
		if (_Timer != null)
		{
			_Timer.Dispose();
		}
		if (_ProcessorTimeTotalCounter != null)
		{
			_ProcessorTimeTotalCounter.Dispose();
		}
		_Adapters.ForEach(delegate(NetworkAdapterMonitor a)
		{
			a.Dispose();
		});
		_Adapters.Clear();
	}
}
