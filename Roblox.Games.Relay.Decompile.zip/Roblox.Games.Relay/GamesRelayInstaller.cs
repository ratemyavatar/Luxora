using System.ComponentModel;
using Roblox.Wcf;

namespace Roblox.Games.Relay;
/*
[RunInstaller(true)]
public class GamesRelayInstaller : ServiceHostInstaller
{
	public override string Description => "Manages games on an RCC node.";

	public override string DisplayName => "Roblox Games Relay";

	public override string ServiceName => "Roblox.Games.Relay";
}*/
