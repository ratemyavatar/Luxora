using System;
using System.IO;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Roblox.EventLog;
using Roblox.Games.Relay.Properties;
using Roblox.Grid.Rcc;
using Roblox.Wcf;

namespace Roblox.Games.Relay;

[ServiceContract(SessionMode = SessionMode.NotAllowed)]
[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
public class GamesRelay
{
	private static readonly byte[] _EmptyGif = Convert.FromBase64String("R0lGODlhAQABAHAAACH5BAUAAAAALAAAAAABAAEAAAICRAEAOw==");

	private static readonly ILogger _Logger = new Logger("RGR1.Roblox.Games.Relay", () => Settings.Default.LogLevel)
	{
		LogToConsole = true,
		LogThreadID = true
	};

	private static readonly RCCServiceSoap _RccService = new RCCServiceSoap
	{
		Url = Settings.Default.ArbiterEndpoint
	};

	private static readonly PerfStatsMonitor _Monitor = new PerfStatsMonitor();

	private static string _RccVersion;

	private static bool _IsRunning;

    public static void Main(string[] args)
	{
		ServiceHostApp<GamesRelay> serviceHostApp = new ServiceHostApp<GamesRelay>();
		serviceHostApp.HostOpening += HostApplicationOpening;
		serviceHostApp.HostClosing += HostApplicationClosing;
		serviceHostApp.Process(args);
	}
    /*public static void Main(string[] args)
    {
        HostApplicationOpening(null, EventArgs.Empty);

        Console.ReadLine();

        HostApplicationClosing(null, EventArgs.Empty);
    }*/

    [OperationContract]
	[WebGet(ResponseFormat = WebMessageFormat.Json)]
	public bool IsAlive()
	{
		return true;
	}

	[OperationContract]
	[WebGet]
	public Stream Ping()
	{
		if (WebOperationContext.Current != null)
		{
			WebOperationContext.Current.OutgoingResponse.ContentType = "image/gif";
		}
		return new MemoryStream(_EmptyGif);
	}

	[WebGet(ResponseFormat = WebMessageFormat.Json)]
	[OperationContract]
	public ServerStatistics GetStats()
	{
		return GetServerStatistics();
	}

	private static void HostApplicationClosing(object sender, EventArgs e)
	{
		_Logger.LifecycleEvent("Stopping GamesRelay.");
		_IsRunning = false;
		_Monitor.Dispose();
	}

	private static void HostApplicationOpening(object sender, EventArgs e)
	{
		_Logger.LifecycleEvent("Starting GamesRelay.");
		_IsRunning = true;
		RunInBackground(_Monitor.Start);
		RunInBackground(CheckRccVersion);
		if (!string.IsNullOrEmpty(Settings.Default.GameServiceUrl))
		{
			RunInBackground(PostStats);
		}
	}

	private static void CheckRccVersion()
	{
		while (_IsRunning)
		{
			Thread.Sleep(10000);
			ReadRccVersion();
		}
	}

	private static void ReadRccVersion()
	{
		try
		{
			_RccVersion = _RccService.GetVersion();
		}
		catch (Exception ex)
		{
			_Logger.Error("Error in fetching Rcc Version: {0}", ex);
			_RccVersion = null;
		}
	}

	private static void PostStats()
	{
		ReadRccVersion();
		_Logger.LifecycleEvent("RequestDispatches. Game Service Url = {0}, RccVersion = {1}", Settings.Default.GameServiceUrl, _RccVersion);
		string address = Settings.Default.GameServiceUrl + "/v1.0/GetDispatch?apiKey=" + Settings.Default.GamesRelayApiKey;
		while (_IsRunning)
		{
			try
			{
				if (_RccVersion == null)
				{
					throw new Exception("Unable to request dispatch since RCC version is not detected");
				}
				ServerStatistics serverStatistics = GetServerStatistics();
				string data = JsonConvert.SerializeObject(serverStatistics);
				using WebClient webClient = new WebClient();
				webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
				webClient.UploadString(address, data);
				_Logger.Verbose("PostStats complete");
			}
			catch (Exception ex)
			{
				_Logger.Error("Error in PostStats: {0}", ex);
			}
			Thread.Sleep(Settings.Default.RequestDispatchInterval);
		}
	}

	private static ServerStatistics GetServerStatistics()
	{
		ServerStatistics serverStatistics = _Monitor.GetServerStatistics();
		serverStatistics.RccVersion = _RccVersion;
		return serverStatistics;
	}

	private static void RunInBackground(Action action)
	{
		Task.Factory.StartNew(delegate
		{
			try
			{
				action();
			}
			catch (Exception ex)
			{
				_Logger.Error(ex);
			}
		});
	}
}
