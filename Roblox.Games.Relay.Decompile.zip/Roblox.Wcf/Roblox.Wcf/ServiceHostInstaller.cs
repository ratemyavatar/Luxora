using System;
using System.Configuration.Install;
using System.ServiceProcess;

namespace Roblox.Wcf;

public abstract class ServiceHostInstaller : Installer
{
	public abstract string ServiceName { get; }

	public abstract string DisplayName { get; }

	public abstract string Description { get; }

	protected ServiceHostInstaller()
	{
		ServiceProcessInstaller value = new ServiceProcessInstaller
		{
			Account = ServiceAccount.LocalSystem
		};
		base.Installers.Add(value);
		ServiceInstaller serviceInstaller = new ServiceInstaller
		{
			ServiceName = ServiceName,
			DisplayName = DisplayName,
			Description = Description,
			StartType = ServiceStartMode.Automatic
		};
		serviceInstaller.Committed += Service_Committed;
		base.Installers.Add(serviceInstaller);
	}

	private void Service_Committed(object sender, InstallEventArgs e)
	{
		using ServiceController serviceController = new ServiceController(ServiceName);
		serviceController.Start();
		serviceController.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(10.0));
	}
}
