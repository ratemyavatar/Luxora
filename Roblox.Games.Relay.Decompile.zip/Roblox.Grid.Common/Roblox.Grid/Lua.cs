using System;
using Roblox.Grid.Rcc;

namespace Roblox.Grid;

public static class Lua
{
	public static ScriptExecution EmptyScript = NewScript("EmptyScript", "return");

	public static ScriptExecution NewScript(string name, string script)
	{
		return NewScript(name, script, NewArgs());
	}

	public static ScriptExecution NewScript(string name, string script, params object[] args)
	{
		return NewScript(name, script, NewArgs(args));
	}

	public static ScriptExecution NewScript(string name, string script, LuaValue[] args)
	{
		ScriptExecution scriptExecution = new ScriptExecution();
		scriptExecution.name = name;
		scriptExecution.script = script;
		scriptExecution.arguments = args ?? NewArgs();
		return scriptExecution;
	}

	public static string ToString(LuaValue[] result)
	{
		string text = null;
		foreach (LuaValue luaValue in result)
		{
			text = ((!string.IsNullOrEmpty(text)) ? (text + ", " + luaValue.value) : luaValue.value);
		}
		return text;
	}

	public static void SetArg(LuaValue[] args, int index, object value)
	{
		LuaValue luaValue = new LuaValue();
		if (value is int || value is float || value is double || value is long || value is decimal || value is short || value is ushort || value is uint || value is ulong)
		{
			luaValue.type = LuaType.LUA_TNUMBER;
			luaValue.value = value.ToString();
		}
		else if (value is string || value is Guid)
		{
			luaValue.type = LuaType.LUA_TSTRING;
			luaValue.value = value.ToString();
		}
		else if (value is bool)
		{
			luaValue.type = LuaType.LUA_TBOOLEAN;
			luaValue.value = (((bool)value) ? "true" : "false");
		}
		else if (value == null)
		{
			luaValue.type = LuaType.LUA_TNIL;
			luaValue.value = string.Empty;
		}
		else
		{
			if (!(value is LuaValue[]))
			{
				throw new ArgumentException(string.Concat("Unsupported Lua argument type ", value.GetType(), ", value = '", value, "'"));
			}
			luaValue.type = LuaType.LUA_TTABLE;
			luaValue.table = value as LuaValue[];
		}
		args[index] = luaValue;
	}

	private static object ConvertLua(LuaValue luaValue)
	{
		return luaValue.type switch
		{
			LuaType.LUA_TBOOLEAN => Convert.ToBoolean(luaValue.value), 
			LuaType.LUA_TNUMBER => Convert.ToDouble(luaValue.value), 
			LuaType.LUA_TSTRING => luaValue.value, 
			LuaType.LUA_TTABLE => GetValues(luaValue.table), 
			_ => null, 
		};
	}

	public static LuaValue[] NewArgs(params object[] args)
	{
		LuaValue[] array = new LuaValue[args.Length];
		for (int i = 0; i < args.Length; i++)
		{
			SetArg(array, i, args[i]);
		}
		return array;
	}

	public static object[] GetValues(LuaValue[] args)
	{
		object[] array = new object[args.Length];
		for (int i = 0; i < args.Length; i++)
		{
			array[i] = ConvertLua(args[i]);
		}
		return array;
	}
}
