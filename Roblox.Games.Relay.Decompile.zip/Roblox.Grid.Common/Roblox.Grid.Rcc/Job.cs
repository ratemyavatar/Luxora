using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Roblox.Grid.Rcc;

[Serializable]
[XmlType(Namespace = "http://roblox.com/")]
[GeneratedCode("wsdl", "2.0.50727.3038")]
[DebuggerStepThrough]
[DesignerCategory("code")]
public class Job : INotifyPropertyChanged
{
	private string idField;

	private double expirationInSecondsField;

	private int categoryField;

	private double coresField;

	public string id
	{
		get
		{
			return idField;
		}
		set
		{
			idField = value;
			RaisePropertyChanged("id");
		}
	}

	public double expirationInSeconds
	{
		get
		{
			return expirationInSecondsField;
		}
		set
		{
			expirationInSecondsField = value;
			RaisePropertyChanged("expirationInSeconds");
		}
	}

	public int category
	{
		get
		{
			return categoryField;
		}
		set
		{
			categoryField = value;
			RaisePropertyChanged("category");
		}
	}

	public double cores
	{
		get
		{
			return coresField;
		}
		set
		{
			coresField = value;
			RaisePropertyChanged("cores");
		}
	}

	public event PropertyChangedEventHandler PropertyChanged;

	protected void RaisePropertyChanged(string propertyName)
	{
		this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
	}
}
