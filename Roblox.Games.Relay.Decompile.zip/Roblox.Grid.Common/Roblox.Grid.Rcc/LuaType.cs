using System;
using System.CodeDom.Compiler;
using System.Xml.Serialization;

namespace Roblox.Grid.Rcc;

[Serializable]
[XmlType(Namespace = "http://roblox.com/")]
[GeneratedCode("wsdl", "2.0.50727.3038")]
public enum LuaType
{
	LUA_TNIL,
	LUA_TBOOLEAN,
	LUA_TNUMBER,
	LUA_TSTRING,
	LUA_TTABLE
}
