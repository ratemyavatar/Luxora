using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.ServiceModel;
using System.Web.Services;
using System.Web.Services.Description;
using System.Web.Services.Protocols;
using System.Xml.Serialization;

namespace Roblox.Grid.Rcc;

[DebuggerStepThrough]
[DesignerCategory("code")]
[WebServiceBinding(Name = "RCCServiceSoap", Namespace = "http://roblox.com/")]
[GeneratedCode("wsdl", "2.0.50727.3038")]
public class RCCServiceSoap : SoapHttpClientProtocol
{
	[SoapDocumentMethod("http://roblox.com/HelloWorld", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public string HelloWorld()
	{
		object[] array = Invoke("HelloWorld", new object[0]);
		return (string)array[0];
	}

	public IAsyncResult BeginHelloWorld(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("HelloWorld", new object[0], callback, asyncState);
	}

	public string EndHelloWorld(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (string)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/GetVersion", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public string GetVersion()
	{
		object[] array = Invoke("GetVersion", new object[0]);
		return (string)array[0];
	}

	public IAsyncResult BeginGetVersion(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("GetVersion", new object[0], callback, asyncState);
	}

	public string EndGetVersion(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (string)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/GetStatus", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public Status GetStatus()
	{
		object[] array = Invoke("GetStatus", new object[0]);
		return (Status)array[0];
	}

	public IAsyncResult BeginGetStatus(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("GetStatus", new object[0], callback, asyncState);
	}

	public Status EndGetStatus(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (Status)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/OpenJob", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	[return: XmlElement("OpenJobResult")]
	public LuaValue[] OpenJob(Job job, ScriptExecution script)
	{
		object[] array = Invoke("OpenJob", new object[2] { job, script });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginOpenJob(Job job, ScriptExecution script, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("OpenJob", new object[2] { job, script }, callback, asyncState);
	}

	public LuaValue[] EndOpenJob(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/OpenJobEx", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public LuaValue[] OpenJobEx(Job job, ScriptExecution script)
	{
		object[] array = Invoke("OpenJobEx", new object[2] { job, script });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginOpenJobEx(Job job, ScriptExecution script, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("OpenJobEx", new object[2] { job, script }, callback, asyncState);
	}

	public LuaValue[] EndOpenJobEx(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/RenewLease", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public double RenewLease(string jobID, double expirationInSeconds)
	{
		object[] array = Invoke("RenewLease", new object[2] { jobID, expirationInSeconds });
		return (double)array[0];
	}

	public IAsyncResult BeginRenewLease(string jobID, double expirationInSeconds, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("RenewLease", new object[2] { jobID, expirationInSeconds }, callback, asyncState);
	}

	public double EndRenewLease(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (double)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/Execute", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	[return: XmlElement("ExecuteResult", IsNullable = true)]
	public LuaValue[] Execute(string jobID, ScriptExecution script)
	{
		object[] array = Invoke("Execute", new object[2] { jobID, script });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginExecute(string jobID, ScriptExecution script, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("Execute", new object[2] { jobID, script }, callback, asyncState);
	}

	public LuaValue[] EndExecute(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/ExecuteEx", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public LuaValue[] ExecuteEx(string jobID, ScriptExecution script)
	{
		object[] array = Invoke("ExecuteEx", new object[2] { jobID, script });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginExecuteEx(string jobID, ScriptExecution script, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("ExecuteEx", new object[2] { jobID, script }, callback, asyncState);
	}

	public LuaValue[] EndExecuteEx(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/CloseJob", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public void CloseJob(string jobID)
	{
		Invoke("CloseJob", new object[1] { jobID });
	}

	public IAsyncResult BeginCloseJob(string jobID, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("CloseJob", new object[1] { jobID }, callback, asyncState);
	}

	public void EndCloseJob(IAsyncResult asyncResult)
	{
		EndInvoke(asyncResult);
	}

	[SoapDocumentMethod("http://roblox.com/BatchJob", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	[return: XmlElement("BatchJobResult", IsNullable = true)]
	public LuaValue[] BatchJob(Job job, ScriptExecution script)
	{
		object[] array = Invoke("BatchJob", new object[2] { job, script });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginBatchJob(Job job, ScriptExecution script, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("BatchJob", new object[2] { job, script }, callback, asyncState);
	}

	public LuaValue[] EndBatchJob(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/BatchJobEx", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public LuaValue[] BatchJobEx(Job job, ScriptExecution script)
	{
		object[] array = Invoke("BatchJobEx", new object[2] { job, script });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginBatchJobEx(Job job, ScriptExecution script, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("BatchJobEx", new object[2] { job, script }, callback, asyncState);
	}

	public LuaValue[] EndBatchJobEx(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/GetExpiration", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public double GetExpiration(string jobID)
	{
		object[] array = Invoke("GetExpiration", new object[1] { jobID });
		return (double)array[0];
	}

	public IAsyncResult BeginGetExpiration(string jobID, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("GetExpiration", new object[1] { jobID }, callback, asyncState);
	}

	public double EndGetExpiration(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (double)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/GetAllJobs", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	[return: XmlElement("GetAllJobsResult", IsNullable = true)]
	public Job[] GetAllJobs()
	{
		object[] array = Invoke("GetAllJobs", new object[0]);
		return (Job[])array[0];
	}

	public IAsyncResult BeginGetAllJobs(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("GetAllJobs", new object[0], callback, asyncState);
	}

	public Job[] EndGetAllJobs(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (Job[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/GetAllJobsEx", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public Job[] GetAllJobsEx()
	{
		object[] array = Invoke("GetAllJobsEx", new object[0]);
		return (Job[])array[0];
	}

	public IAsyncResult BeginGetAllJobsEx(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("GetAllJobsEx", new object[0], callback, asyncState);
	}

	public Job[] EndGetAllJobsEx(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (Job[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/CloseExpiredJobs", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public int CloseExpiredJobs()
	{
		object[] array = Invoke("CloseExpiredJobs", new object[0]);
		return (int)array[0];
	}

	public IAsyncResult BeginCloseExpiredJobs(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("CloseExpiredJobs", new object[0], callback, asyncState);
	}

	public int EndCloseExpiredJobs(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (int)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/CloseAllJobs", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public int CloseAllJobs()
	{
		object[] array = Invoke("CloseAllJobs", new object[0]);
		return (int)array[0];
	}

	public IAsyncResult BeginCloseAllJobs(AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("CloseAllJobs", new object[0], callback, asyncState);
	}

	public int EndCloseAllJobs(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (int)array[0];
	}

	[SoapDocumentMethod("http://roblox.com/Diag", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	[return: XmlElement("DiagResult", IsNullable = true)]
	public LuaValue[] Diag(int type, string jobID)
	{
		object[] array = Invoke("Diag", new object[2] { type, jobID });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginDiag(int type, string jobID, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("Diag", new object[2] { type, jobID }, callback, asyncState);
	}

	public LuaValue[] EndDiag(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	[SoapDocumentMethod("http://roblox.com/DiagEx", RequestNamespace = "http://roblox.com/", ResponseNamespace = "http://roblox.com/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
	public LuaValue[] DiagEx(int type, string jobID)
	{
		object[] array = Invoke("DiagEx", new object[2] { type, jobID });
		return (LuaValue[])array[0];
	}

	public IAsyncResult BeginDiagEx(int type, string jobID, AsyncCallback callback, object asyncState)
	{
		return BeginInvoke("DiagEx", new object[2] { type, jobID }, callback, asyncState);
	}

	public LuaValue[] EndDiagEx(IAsyncResult asyncResult)
	{
		object[] array = EndInvoke(asyncResult);
		return (LuaValue[])array[0];
	}

	protected override void Dispose(bool disposing)
	{
		try
		{
			base.Dispose(disposing);
		}
		catch (TimeoutException)
		{
			Abort();
		}
		catch (CommunicationException)
		{
			Abort();
		}
		catch (Exception)
		{
			Abort();
		}
	}
}
