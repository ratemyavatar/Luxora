using Roblox.Grid.Rcc;

namespace Roblox.Grid.Common;

public class GridServiceUtils
{
	public static RCCServiceSoap GetService(string address)
	{
		return GetService(address, 64989);
	}

	public static RCCServiceSoap GetService(string address, int port)
	{
		if (address == null)
		{
			return null;
		}
		RCCServiceSoap rCCServiceSoap = new RCCServiceSoap();
		rCCServiceSoap.Url = "http://" + address + ":" + port;
		return rCCServiceSoap;
	}
}
