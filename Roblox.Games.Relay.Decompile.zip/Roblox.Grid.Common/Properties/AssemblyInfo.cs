using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: Guid("641e3ab9-0ef1-439d-8f4f-e9ef662eda4e")]
[assembly: AssemblyProduct("Roblox.Grid.Common")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCompany("ROBLOX Corporation")]
[assembly: AssemblyCopyright("Copyright © ROBLOX Corporation")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyTitle("Roblox.Grid.Common")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyVersion("1.0.0.0")]
