var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (n) {
    var r = {};
    function o(e) {
      if (r[e]) return r[e].exports;
      var t = (r[e] = { i: e, l: !1, exports: {} });
      return (n[e].call(t.exports, t, t.exports, o), (t.l = !0), t.exports);
    }
    ((o.m = n),
      (o.c = r),
      (o.d = function (e, t, n) {
        o.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: n });
      }),
      (o.r = function (e) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 }));
      }),
      (o.t = function (t, e) {
        if ((1 & e && (t = o(t)), 8 & e)) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (
          (o.r(n),
          Object.defineProperty(n, "default", { enumerable: !0, value: t }),
          2 & e && "string" != typeof t)
        )
          for (var r in t)
            o.d(
              n,
              r,
              function (e) {
                return t[e];
              }.bind(null, r),
            );
        return n;
      }),
      (o.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return (o.d(t, "a", t), t);
      }),
      (o.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (o.p = ""),
      o((o.s = 2)));
  })([
    function (e, t) {
      e.exports = Roblox;
    },
    function (e, t) {
      e.exports = CoreUtilities;
    },
    function (e, t, n) {
      "use strict";
      n.r(t);
      var r,
        o,
        i,
        a,
        u = n(0),
        c = {
          currentPageName:
            null === u.MetaDataValues || void 0 === u.MetaDataValues
              ? void 0
              : u.MetaDataValues.getPageName(),
          defaultIntervalTime: 5e3,
          activeEvents: [
            "focus",
            "click",
            "hover",
            "scroll",
            "mouseover",
            "mouseenter",
            "mousedown",
            "dblclick",
            "keypress",
            "touchstart",
            "touchmove",
          ],
          inactiveEvents: ["blur"],
        },
        l = n(1),
        s = function (e) {
          var t = u.EnvironmentUrls.presenceApi,
            n = {
              url: "".concat(t, "/v1/presence/register-app-presence"),
              withCredentials: !0,
            },
            r = { location: e };
          return l.httpService.post(n, r);
        },
        d = c.activeEvents,
        f = c.inactiveEvents,
        v = c.currentPageName;
      ((r = c.defaultIntervalTime),
      (i = o = !1),
      (a = null),
      {
        init: function () {
          (!(function () {
            var e = document.getElementById(
              "presence-registration-bootstrap-data",
            );
            ((r = Number.isNaN(null == e ? void 0 : e.dataset.interval)
              ? 3e3
              : parseInt(null == e ? void 0 : e.dataset.interval, 10)),
              (o = "True" === (null == e ? void 0 : e.dataset.isEnabled)));
          })(),
            o &&
              (d.forEach(function (e) {
                window.addEventListener(e, function () {
                  ((a = e), (i = !0));
                });
              }),
              f.forEach(function (e) {
                return (
                  window.addEventListener(e, function () {
                    ((i = !1),
                      (a = null),
                      console.debug("-------------Inactive -------------"));
                  }),
                  i
                );
              }),
              setInterval(function () {
                (i &&
                  (console.debug("-----------".concat(a, "------------")),
                  console.debug("-------------Active -------------"),
                  s(v)),
                  (i = !1));
              }, r)));
        },
      }).init();
    },
  ]);
  //# sourceMappingURL=https://js.rbxcdn.com/2f1ca43bd86d00aa167f-presenceRegistration.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("PresenceRegistration");
}
