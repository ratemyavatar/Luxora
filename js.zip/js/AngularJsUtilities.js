var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (r) {
    var n = {};
    function i(e) {
      if (n[e]) return n[e].exports;
      var t = (n[e] = { i: e, l: !1, exports: {} });
      return (r[e].call(t.exports, t, t.exports, i), (t.l = !0), t.exports);
    }
    ((i.m = r),
      (i.c = n),
      (i.d = function (e, t, r) {
        i.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
      }),
      (i.r = function (e) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 }));
      }),
      (i.t = function (t, e) {
        if ((1 & e && (t = i(t)), 8 & e)) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (
          (i.r(r),
          Object.defineProperty(r, "default", { enumerable: !0, value: t }),
          2 & e && "string" != typeof t)
        )
          for (var n in t)
            i.d(
              r,
              n,
              function (e) {
                return t[e];
              }.bind(null, n),
            );
        return r;
      }),
      (i.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return (i.d(t, "a", t), t);
      }),
      (i.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (i.p = ""),
      i((i.s = 64)));
  })([
    ,
    ,
    function (e, t, r) {
      "use strict";
      var n = r(15),
        i = r.n(n),
        s = r(3),
        a = i.a
          .module("angularJsUtilities", [])
          .config([
            "$httpProvider",
            function (e) {
              var o,
                u = "X-CSRF-TOKEN",
                t = i.a.element("#http-retry-data"),
                c =
                  t && t.data("http-retry-base-timeout")
                    ? t.data("http-retry-base-timeout")
                    : 1e3,
                l =
                  t && t.data("http-retry-max-timeout")
                    ? t.data("http-retry-max-timeout")
                    : 8e3,
                f =
                  t && t.data("http-retry-max-times")
                    ? t.data("http-retry-max-times")
                    : 3;
              (e.interceptors.push([
                "$q",
                "$injector",
                function (i, a) {
                  return {
                    request: function (e) {
                      return (
                        ("post" !== e.method.toLowerCase() &&
                          "delete" !== e.method.toLowerCase() &&
                          "patch" !== e.method.toLowerCase()) ||
                          !s.XsrfToken.getToken() ||
                          ((o = o || s.XsrfToken.getToken()),
                          (e.headers[u] = o)),
                        e
                      );
                    },
                    responseError: function (e) {
                      var t = e.status,
                        r = a.get("$http");
                      if (403 === t && e.headers(u)) {
                        var n = e.headers(u);
                        if (n) return ((o = n), r(e.config));
                      }
                      return i.reject(e);
                    },
                  };
                },
              ]),
                e.interceptors.push([
                  "$q",
                  "$injector",
                  "$log",
                  "retryService",
                  function (a, o, u, s) {
                    return {
                      response: function (e) {
                        var t = e.config;
                        if (t.retryable && t.exponentialBackOff) {
                          u.debug(" exponential back off -- response success ");
                          var r = t.exponentialBackOff.GetAttemptCount();
                          (u.debug(
                            " exponential back off -- response success -- retryAttemptCount".concat(
                              r,
                            ),
                          ),
                            0 < r && t.exponentialBackOff.Reset());
                        }
                        return e;
                      },
                      responseError: function (e) {
                        return 403 !== e.status &&
                          i.a.isDefined(e.config) &&
                          e.config.retryable
                          ? (function (e) {
                              var t = o.get("$timeout"),
                                r = e.config;
                              if (s.isExponentialBackOffEnabled) {
                                r.exponentialBackOff ||
                                  (r.exponentialBackOff =
                                    s.exponentialBackOff());
                                var n = r.exponentialBackOff,
                                  i = n.StartNewAttempt();
                                return (
                                  u.debug(
                                    " exponential back off -- GetAttemptCount ".concat(
                                      n.GetAttemptCount(),
                                    ),
                                  ),
                                  n.GetAttemptCount() < f
                                    ? (u.debug(
                                        " exponential back off -- delay ".concat(
                                          i,
                                        ),
                                      ),
                                      t(function () {
                                        return o.get("$http")(r);
                                      }, i))
                                    : (n.Reset(), a.reject(e))
                                );
                              }
                              return (
                                r.incrementalTimeout ||
                                  (r.incrementalTimeout = c),
                                u.debug(
                                  "---- rejection.config.url ------".concat(
                                    r.url,
                                  ),
                                ),
                                u.debug(
                                  "---- incrementalTimeout ------".concat(
                                    r.incrementalTimeout,
                                  ),
                                ),
                                r.incrementalTimeout <= l
                                  ? (u.debug("---- retry ------"),
                                    t(function () {
                                      return (
                                        (r.incrementalTimeout *= 2),
                                        o.get("$http")(r)
                                      );
                                    }, r.incrementalTimeout))
                                  : ((r.incrementalTimeout = c),
                                    u.debug("---- failure promise ------"),
                                    a.reject(e))
                              );
                            })(e)
                          : a.reject(e);
                      },
                    };
                  },
                ]),
                e.interceptors.push([
                  "$q",
                  "$injector",
                  function (e, t) {
                    return {
                      request: function (e) {
                        if (i.a.isDefined(s.Endpoints)) {
                          var t = s.Endpoints.generateAbsoluteUrl(
                            e.url,
                            e.data,
                            e.withCredentials,
                          );
                          ((e.url = t),
                            s.Endpoints.addCrossDomainOptionsToAllRequests &&
                              e.url.indexOf("rbxcdn.com") < 0 &&
                              e.url.indexOf("s3.amazonaws.com") < 0 &&
                              (e.withCredentials = !0));
                        }
                        return e;
                      },
                    };
                  },
                ]));
            },
          ])
          .config([
            "$logProvider",
            function (e) {
              var t = !!i.a.isDefined(s.jsConsoleEnabled) && s.jsConsoleEnabled;
              e.debugEnabled(t);
            },
          ])
          .constant("_", window._ || {});
      t.a = a;
    },
    function (e, t) {
      e.exports = Roblox;
    },
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    function (e, t) {
      function a(e) {
        return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
      }
      function o(e) {
        return e.split("/").pop().replace(".html", "");
      }
      var r = {
        importFilesUnderPath: function (e) {
          e.keys().forEach(e);
        },
        templateCacheGenerator: function (e, t, n, i) {
          return e.module(t, []).run([
            "$templateCache",
            function (r) {
              (n &&
                n.keys().forEach(function (e) {
                  var t = a(o(e));
                  r.put(t, n(e));
                }),
                i &&
                  i.keys().forEach(function (e) {
                    var t = a(o(e));
                    r.put(
                      t,
                      (function (e) {
                        return e.replace(/<\/?script[^>]*>/gi, "");
                      })(i(e)),
                    );
                  }));
            },
          ]);
        },
      };
      e.exports = r;
    },
    ,
    function (e, t) {
      e.exports = angular;
    },
    ,
    ,
    ,
    ,
    ,
    ,
    function (e, t, r) {
      "use strict";
      t.a = {
        quoteText: function (e) {
          return '"' + e + '"';
        },
      };
    },
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(13);
      r(2);
      (Object(n.importFilesUnderPath)(r(65)),
        Object(n.importFilesUnderPath)(r(80)),
        Object(n.importFilesUnderPath)(r(102)),
        Object(n.importFilesUnderPath)(r(121)));
    },
    function (e, t, r) {
      var n = {
        "./abTestConstants.js": 66,
        "./batchRequestsConstants.js": 67,
        "./callBackTypes.js": 68,
        "./deviceTypes.js": 69,
        "./httpStatusCodes.js": 70,
        "./keyCode.js": 71,
        "./keys.js": 72,
        "./localStorageNames.js": 73,
        "./performanceMarkLabels.js": 74,
        "./presenceTypes.js": 75,
        "./thumbnailResponseStatuses.js": 76,
        "./thumbnailStatusStyleMap.js": 77,
        "./thumbnailStyleConstants.js": 78,
        "./urlConstants.js": 79,
      };
      function i(e) {
        var t = a(e);
        return r(t);
      }
      function a(e) {
        var t = n[e];
        if (t + 1) return t;
        var r = new Error("Cannot find module '" + e + "'");
        throw ((r.code = "MODULE_NOT_FOUND"), r);
      }
      ((i.keys = function () {
        return Object.keys(n);
      }),
        (i.resolve = a),
        ((e.exports = i).id = 65));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        subjectType: { user: "User", browserTracker: "BrowserTracker" },
        urls: {
          checkEnrollment: "/v1/get-enrollments",
          enroll: "/v1/enrollments",
        },
        response: {
          status: {
            enrolled: "Enrolled",
            inactive: "Inactive",
            noExperiment: "NoExperiment",
          },
        },
        errorCode: { noResultForExperiment: 0 },
      };
      (r(2).a.constant("abTestConstants", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        defaultCooldown: 1e3,
        defaultProcessBatchWaitTime: 50,
        errors: {
          processFailure: "processFailure",
          unretriableFailure: "unretriableFailure",
          maxAttemptsReached: "maxAttemptsReached",
        },
      };
      (r(2).a.constant("batchRequestsConstants", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = { SUCCESS: "Success", MODERATED: "Moderated" };
      (r(2).a.constant("callBackTypes", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = { COMPUTER: "Computer", PHONE: "Phone", TABLET: "Tablet" };
      (r(2).a.constant("deviceTypes", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = { tooManyAttempts: 429 };
      (r(2).a.constant("httpStatusCodes", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = { tab: 9, enter: 13, esc: 27, arrowUp: 38, arrowDown: 40 };
      (r(2).a.constant("keyCode", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i() {
        return (
          -1 !== navigator.userAgent.indexOf("MSIE") ||
          -1 < navigator.appVersion.indexOf("Trident/")
        );
      }
      var a = {
        backspace: "Backspace",
        tab: "Tab",
        enter: "Enter",
        escape: i() ? "Esc" : "Escape",
        delete: i() ? "Del" : "Delete",
        alt: "Alt",
        capsLock: "CapsLock",
        control: "Control",
        numLock: "NumLock",
        scrollLock: "ScrollLock",
        shift: "Shift",
        space: i() ? "Spacebar" : " ",
        arrowDown: i() ? "Down" : "ArrowDown",
        arrowLeft: i() ? "Left" : "ArrowLeft",
        arrowRight: i() ? "Right" : "ArrowRight",
        arrowUp: i() ? "Up" : "ArrowUp",
        end: "End",
        home: "Home",
        pageDown: "PageDown",
        pageUp: "PageUp",
        insert: "Insert",
        f1: "F1",
        f2: "F2",
        f3: "F3",
        f4: "F4",
        f5: "F5",
        f6: "F6",
        f7: "F7",
        f8: "F8",
        f9: "F9",
        f10: "F10",
        f11: "F11",
        f12: "F12",
      };
      (!(function () {
        for (var e = "A".charCodeAt(0); e <= "Z".charCodeAt(0); e++)
          ((a[String.fromCharCode(e)] = String.fromCharCode(e)),
            (a[String.fromCharCode(e).toLowerCase()] =
              String.fromCharCode(e).toLowerCase()));
      })(),
        n.a.constant("keys", a),
        (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3),
        a = {
          friendsDict: i.CurrentUser
            ? "Roblox.FriendsDict.UserId" + i.CurrentUser.userId
            : "Roblox.FriendsDict.UserId0",
        };
      (n.a.constant("localStorageNames", a), (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        chat: {
          chatPageDataLoaded: "chat_pageData_loaded",
          chatConversationsLoading: "chat_conversations_loading",
          chatConversationsLoaded: "chat_conversations_loaded",
          chatSignalRInitializing: "chat_signalR_initializing",
          chatSignalRSucceeded: "chat_signalR_succeeded",
        },
      };
      (r(2).a.constant("performanceMarkLabels", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        offline: { status: 0, className: "" },
        online: { status: 1, className: "icon-online" },
        ingame: { status: 2, className: "icon-game" },
        instudio: { status: 3, className: "icon-studio" },
      };
      (r(2).a.constant("presenceTypes", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        completed: "Completed",
        inReview: "InReview",
        pending: "Pending",
        blocked: "Blocked",
        error: "Error",
      };
      (r(2).a.constant("thumbnailResponseStatuses", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        Error: "icon-error",
        InReview: "icon-in-review",
        Blocked: "icon-blocked",
        Pending: "icon-pending",
      };
      (r(2).a.constant("thumbnailStatusStyleMap", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        sm: "sm",
        md: "md",
        lg: "lg",
        group: {
          sm: "thumbnail-status-placeholder-sm",
          md: "thumbnail-status-placeholder-md",
          lg: "thumbnail-status-placeholder-lg",
        },
      };
      (r(2).a.constant("thumbnailStyleConstants", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = {
        urlQueryStringPrefix: "?",
        urlQueryParameterSeparator: "&",
        hashSign: "#",
      };
      (r(2).a.constant("urlConstants", n), (t.default = n));
    },
    function (e, t, r) {
      var n = {
        "./alphanumericInputDirective.js": 81,
        "./autoResizeDirective.js": 82,
        "./blurDirective.js": 83,
        "./clickOutsideDirective.js": 84,
        "./contextMenuDirective.js": 85,
        "./copyToClipboard.js": 86,
        "./enterEscapeShiftDirective.js": 87,
        "./focusDirective.js": 88,
        "./focusMeDirective.js": 89,
        "./formValidationDirective.js": 90,
        "./hoverPopoverDirective.js": 91,
        "./imageRetryDirective.js": 92,
        "./inputMaxLength.js": 93,
        "./keyPressEnterDirective.js": 94,
        "./keyPressEscapeDirective.js": 95,
        "./matchFieldDirective.js": 96,
        "./numbersOnlyDirective.js": 97,
        "./onFinishRenderDirective.js": 98,
        "./phoneDirective.js": 99,
        "./stickToTopDirective.js": 100,
        "./switcherDirective.js": 101,
      };
      function i(e) {
        var t = a(e);
        return r(t);
      }
      function a(e) {
        var t = n[e];
        if (t + 1) return t;
        var r = new Error("Cannot find module '" + e + "'");
        throw ((r.code = "MODULE_NOT_FOUND"), r);
      }
      ((i.keys = function () {
        return Object.keys(n);
      }),
        (i.resolve = a),
        ((e.exports = i).id = 80));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          require: "ngModel",
          restrict: "A",
          link: function (e, t, r, n) {
            n.$parsers.push(function (e) {
              if (null == e) return "";
              var t = e.replace(/[^0-9a-zA-Z]/g, "");
              return (t !== e && (n.$setViewValue(t), n.$render()), t);
            });
          },
        };
      }
      (r.r(t), r(2).a.directive("alphanumericInput", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(a) {
        return {
          restrict: "A",
          link: function (r, i, e) {
            for (var t in ((r.attrs = { rows: 1, maxLines: 999 }), r.attrs))
              e[t] && (r.attrs[t] = parseInt(e[t]));
            ((r.getOffset = function () {
              for (
                var e = a.getComputedStyle(i[0], null),
                  t = ["paddingTop", "paddingBottom"],
                  r = 0,
                  n = 0;
                n < t.length;
                n++
              )
                r += parseInt(e[t[n]]);
              return r;
            }),
              (r.autoResize = function () {
                var e = 0,
                  t = !1;
                return (
                  i[0].scrollHeight - r.offset > r.maxAllowedHeight
                    ? ((i[0].style.overflowY = "scroll"),
                      (e = r.maxAllowedHeight))
                    : ((i[0].style.overflowY = "hidden"),
                      (i[0].style.height = "auto"),
                      (e = i[0].scrollHeight),
                      (t = !0)),
                  (i[0].style.height = e + "px"),
                  t
                );
              }),
              (r.offset = r.getOffset()),
              (r.lineHeight = parseInt(i.css("line-height").replace("px", ""))),
              (r.maxAllowedHeight = r.lineHeight * r.attrs.maxLines - r.offset),
              r.$watch(
                e.ngModel,
                function () {
                  r.autoResize();
                },
                !0,
              ));
          },
        };
      }
      ((i.$inject = ["$window"]),
        n.a.directive("autoResize", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t, r) {
          t[0].addEventListener(
            "blur",
            function () {
              e.$evalAsync(function () {
                e.$eval(r.blurModel);
              });
            },
            !0,
          );
        };
      }
      (r.r(t), r(2).a.directive("blurModel", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(a, o) {
        return {
          restrict: "A",
          link: function (t, r, e) {
            function n(e) {
              r[0] !== e.target &&
                0 === r.find(e.target).length &&
                t.$apply(function () {
                  i(t, {});
                });
            }
            var i = o(e.clickOutside);
            (a.on("click", n),
              t.$on("$destroy", function () {
                a.off("click", n);
              }));
          },
        };
      }
      ((i.$inject = ["$document", "$parse"]),
        n.a.directive("clickOutside", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(i) {
        return function (t, e, r) {
          var n = i(r.contextMenu);
          e.bind("contextmenu", function (e) {
            t.$apply(function () {
              n(t, { $event: e });
            });
          });
        };
      }
      ((i.$inject = ["$parse"]),
        n.a.directive("contextMenu", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          restrict: "A",
          link: function (e, t, r) {
            t.click(function () {
              var e = r.copyTarget;
              (angular.element(e).select(), document.execCommand("Copy"));
            });
          },
        };
      }
      (r.r(t), r(2).a.directive("copyToClipboard", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(n) {
        return {
          restrict: "A",
          link: function (t, e, r) {
            e.bind("keydown keypress", function (e) {
              (e.keyCode || e.which) !== n.enter ||
                e.shiftKey ||
                (e.preventDefault(),
                t.$apply(function () {
                  t.$eval(r.enterEscapeShift);
                }));
            });
          },
        };
      }
      ((i.$inject = ["keyCode"]),
        n.a.directive("enterEscapeShift", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t, r) {
          t[0].addEventListener(
            "focus",
            function () {
              e.$evalAsync(function () {
                e.$eval(r.focusModel);
              });
            },
            !0,
          );
        };
      }
      (r.r(t), r(2).a.directive("focusModel", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(n) {
        return {
          scope: { trigger: "@focusMe" },
          link: function (e, t, r) {
            e.$watch(
              function () {
                return r.focusMe;
              },
              function (e) {
                e &&
                  n(function () {
                    "true" === e && t[0].focus();
                  }, 0);
              },
            );
          },
        };
      }
      ((i.$inject = ["$timeout"]),
        n.a.directive("focusMe", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        o = r(3);
      function i() {
        return {
          require: ["^form", "ngModel"],
          restrict: "A",
          link: function (e, t, r, a) {
            e.$watch(
              function () {
                return a[1].$viewValue;
              },
              function (e) {
                if (void 0 !== o.FormEvents) {
                  var t = a[0],
                    r = a[1];
                  if (r.$dirty && r.$invalid) {
                    var n = [];
                    angular.forEach(r.$error, function (e, t) {
                      !0 === e && n.push(t);
                    });
                    var i = r.redactedInput ? "[Redacted]" : e;
                    o.FormEvents.SendValidationFailed(
                      t.$name,
                      r.$name,
                      i,
                      n.join(","),
                    );
                  }
                }
              },
            );
          },
        };
      }
      (n.a.directive("formValidation", i), (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(e, o) {
        return {
          restrict: "A",
          replace: !0,
          scope: { hoverPopoverParams: "=" },
          link: function (r, e, t) {
            var n = r.hoverPopoverParams.hoverPopoverSelector,
              i = r.hoverPopoverParams.triggerSelector;
            function a(e) {
              var t = angular.element(i);
              return t.find(e) && 0 < t.find(e).length;
            }
            r.hoverPopoverParams.isDisabled ||
              (e.on("hover", function () {
                r.$apply(function () {
                  ((r.hoverPopoverParams.isOpen = !0),
                    angular.element(n).on("mouseleave", function (e) {
                      r.hoverPopoverParams.isOpen &&
                        (a(angular.element(e.relatedTarget)) ||
                          r.$apply(function () {
                            r.hoverPopoverParams.isOpen = !1;
                          }));
                    }));
                });
              }),
              angular.element(i).on("mouseleave", function (e) {
                if (r.hoverPopoverParams.isOpen) {
                  var t = angular.element(e.relatedTarget);
                  (function (e) {
                    var t = !1,
                      r = angular.element(n);
                    r.find(e) && 0 < r.find(e).length && (t = !0);
                    return t;
                  })(t) ||
                    a(t) ||
                    r.$apply(function () {
                      r.hoverPopoverParams.isOpen = !1;
                    });
                }
              }),
              o.on("HoverPopover.EnableClose", function () {
                r.hoverPopoverParams.isOpen &&
                  r.$apply(function () {
                    r.hoverPopoverParams.isOpen = !1;
                  });
              }));
          },
        };
      }
      ((i.$inject = ["$log", "$document"]),
        n.a.directive("hoverPopover", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        s = r(3);
      function i(o, u) {
        return {
          restrict: "A",
          scope: { thumbnail: "=" },
          link: function (e, t, a) {
            function r(n) {
              if (n && !n.Final) {
                var i = new Date().getTime();
                o.getImageUrl(
                  n,
                  function (e, t) {
                    if (t) {
                      var r = new Date().getTime();
                      s.ThumbnailMetrics.logFinalThumbnailTime(r - i);
                    } else
                      s.ThumbnailMetrics.ThumbnailMetrics.logThumbnailTimeout();
                    a.resetSrc
                      ? e && (n.Url = e)
                      : (a.src && 0 < a.src.length) || a.disablePlaceholder
                        ? (a.$set("src", e), u.debug("got final, setting src"))
                        : a.lazyImg &&
                          (a.$set("lazyImg", e),
                          u.debug("got final, setting lazyimg"));
                  },
                  0,
                );
              }
            }
            r(e.thumbnail);
            var n = e.$watch(
              function () {
                return e.thumbnail;
              },
              function (e) {
                e && r(e);
              },
            );
            e.$on("$destroy", function () {
              n && n();
            });
          },
        };
      }
      ((i.$inject = ["robloxImagesService", "$log"]),
        n.a.directive("imageRetry", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          require: "ngModel",
          link: function (e, t, r, n) {
            var i = Number(r.inputMaxLength);
            n.$parsers.push(function (e) {
              if (e.length > i) {
                var t = e.substring(0, i);
                return (n.$setViewValue(t), n.$render(), t);
              }
              return e;
            });
          },
        };
      }
      (r.r(t), r(2).a.directive("inputMaxLength", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (t, e, r) {
          e.bind("keydown keypress", function (e) {
            13 === e.which &&
              (t.$apply(function () {
                t.$eval(r.keyPressEnter);
              }),
              e.preventDefault());
          });
        };
      }
      (r.r(t), r(2).a.directive("keyPressEnter", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (t, e, r) {
          e.bind("keydown keypress", function (e) {
            27 === e.which &&
              (t.$apply(function () {
                t.$eval(r.keyPressEscape);
              }),
              e.preventDefault());
          });
        };
      }
      (r.r(t), r(2).a.directive("keyPressEscape", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          require: "ngModel",
          link: function (t, e, r, n) {
            (t.$watch(r.matchField, function (e) {
              void 0 !== n.$viewValue &&
                "" !== n.$viewValue &&
                n.$setValidity("matchField", e === n.$viewValue);
            }),
              (n.$validators.matchField = function (e) {
                return e === t.$eval(r.matchField);
              }));
          },
        };
      }
      (r.r(t), r(2).a.directive("matchField", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          require: "ngModel",
          link: function (e, t, r, n) {
            n.$parsers.push(function (e) {
              if (null == e) return "";
              var t = e.replace(/[^0-9]/g, "");
              return (t !== e && (n.$setViewValue(t), n.$render()), t);
            });
          },
        };
      }
      (r.r(t), r(2).a.directive("numbersOnly", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(n) {
        return {
          restrict: "A",
          link: function (e, t, r) {
            !0 === e.$last &&
              n(function () {
                e.$emit(r.onFinishRender);
              });
          },
        };
      }
      ((i.$inject = ["$timeout"]),
        n.a.directive("onFinishRender", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          require: "ngModel",
          link: function (e, t, r, n) {
            n.$parsers.push(function (e) {
              if (null == e) return "";
              var t = e.replace(/[^0-9-+()]/g, "");
              return (t !== e && (n.$setViewValue(t), n.$render()), t);
            });
          },
        };
      }
      (r.r(t), r(2).a.directive("phone", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(n) {
        return {
          restrict: "A",
          scope: { isElementAtTop: "=" },
          link: function (t, e) {
            var r = e[0].getBoundingClientRect().top;
            angular.element(n).bind("scroll", function () {
              var e = n.pageYOffset;
              !t.isElementAtTop && r <= e
                ? ((t.isElementAtTop = !0), t.$apply())
                : t.isElementAtTop &&
                  e <= r &&
                  ((t.isElementAtTop = !1), t.$apply());
            });
          },
        };
      }
      ((i.$inject = ["$window"]),
        n.a.directive("stickToTop", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(e) {
        return {
          restrict: "A",
          controller: [
            "$scope",
            function (e) {
              ((e.switcher = {}),
                (e.switcher.games = { currPage: 0, itemsCount: 0 }),
                (e.switcher.groups = { currPage: 0, itemsCount: 0 }));
            },
          ],
          scope: { currpage: "=", itemscount: "=" },
          link: function (t, r, e) {
            var n = null;
            ((t.currpage = 0),
              r.find(".switcher-item") &&
                0 < r.find(".switcher-item").length &&
                (t.itemscount = r.find(".switcher-item").length),
              r.find(".carousel-control").on("click", function (e) {
                (t.$apply(function () {
                  "next" == angular.element(e.currentTarget).attr("data-switch")
                    ? t.currpage + 1 <= t.itemscount - 1
                      ? (t.currpage += 1)
                      : (t.currpage = 0)
                    : 0 <= t.currpage - 1
                      ? (t.currpage -= 1)
                      : (t.currpage = t.itemscount - 1);
                }),
                  (n = r.find(
                    ".switcher-item[data-index=" + t.currpage + "] img",
                  )).attr("src") || n.attr("src", n.attr("data-src")));
              }));
          },
        };
      }
      ((i.$inject = ["$log"]), n.a.directive("switcher", i), (t.default = i));
    },
    function (e, t, r) {
      var n = {
        "./abbreviate.js": 103,
        "./camelCase.js": 104,
        "./capitalize.js": 105,
        "./escapeHtml.js": 106,
        "./firstLetter.js": 107,
        "./formatCharacterCount.js": 108,
        "./formatString.js": 109,
        "./getPercentage.js": 110,
        "./htmlToPlainText.js": 111,
        "./isEmpty.js": 112,
        "./orderList.js": 113,
        "./parseInt.js": 114,
        "./parseTimeStamp.js": 115,
        "./positive.js": 116,
        "./quoteText.js": 117,
        "./reverse.js": 118,
        "./seoUrl.js": 119,
        "./startsWith.js": 120,
      };
      function i(e) {
        var t = a(e);
        return r(t);
      }
      function a(e) {
        var t = n[e];
        if (t + 1) return t;
        var r = new Error("Cannot find module '" + e + "'");
        throw ((r.code = "MODULE_NOT_FOUND"), r);
      }
      ((i.keys = function () {
        return Object.keys(n);
      }),
        (i.resolve = a),
        ((e.exports = i).id = 102));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      function n(e) {
        if ("number" != typeof e) throw "'number' is not a number";
        var t;
        return e <= 0
          ? "0"
          : e < 1e3
            ? e
            : e < 1e6
              ? 1e3 <= (t = Math.round((e / 1e3) * 10) / 10)
                ? Math.round((t / 1e3) * 10) / 10 + "M"
                : t + "K"
              : e < 1e9
                ? 1e3 <= (t = Math.round((e / 1e6) * 10) / 10)
                  ? Math.round((t / 1e3) * 10) / 10 + "B"
                  : t + "M"
                : Math.round((e / 1e9) * 10) / 10 + "B";
      }
      var i = r(2);
      (i.a.filter("abbreviate", function () {
        return function (e, t) {
          return "number" == typeof e
            ? 1 === t
              ? n(e)
              : (function (e) {
                  if ("number" != typeof e) throw "'number' is not a number";
                  if (0 == e) return "0";
                  if (e < 1e4)
                    return (function (e) {
                      if ("number" != typeof e)
                        throw "'number' is not a number";
                      return e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    })(e);
                  var t = "B+",
                    r = 9;
                  e < 1e6
                    ? ((t = "K+"), (r = 3))
                    : e < 1e9 && ((t = "M+"), (r = 6));
                  var n = e.toString();
                  return n.substring(0, n.length - r) + t;
                })(e)
            : e;
        };
      }),
        (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(e) {
        return function (e) {
          return e.replace(/^([A-Z])|[\s-_]+(\w)/g, function (e, t, r, n) {
            return r ? r.toUpperCase() : t.toLowerCase();
          });
        };
      }
      ((i.$inject = ["$filter"]), n.a.filter("camelCase", i), (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          if (null != e) {
            for (var t = e.split(" "), r = [], n = 0; n < t.length; n++) {
              var i = t[n].toLowerCase();
              r.push(i.substring(0, 1).toUpperCase() + i.substring(1));
            }
            return r.join(" ");
          }
        };
      }
      (r.r(t), r(2).a.filter("capitalize", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        var t = {
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
          "/": "&#x2F;",
        };
        return function (e) {
          return String(e).replace(/[&<>"'\\/]/g, function (e) {
            return t[e];
          });
        };
      }
      (r.r(t), r(2).a.filter("escapeHtml", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          return null != e ? e.substring(0, 1).toLowerCase() : "";
        };
      }
      (r.r(t), r(2).a.filter("firstLetter", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t) {
          return e + "/" + t;
        };
      }
      (r.r(t), r(2).a.filter("formatCharacterCount", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          if (arguments && 1 < arguments.length) {
            var t = e,
              r = arguments[1];
            for (var n in r) {
              var i = r[n],
                a = new RegExp("{" + n + "(:.*?)?\\??}");
              t = t.replace(a, i);
            }
            return t;
          }
          return e;
        };
      }
      (r.r(t), r(2).a.filter("formatString", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t) {
          var r = 0;
          return (
            isNaN(e) ||
              isNaN(t) ||
              (100 <
                (r =
                  0 === e
                    ? 0
                    : 0 === t
                      ? 100
                      : Math.floor((e / (e + t)) * 100)) &&
                (r = 100)),
            r + "%"
          );
        };
      }
      (r.r(t), r(2).a.filter("getPercentage", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          return String(e).replace(/<[^>]+>/gm, "");
        };
      }
      (r.r(t), r(2).a.filter("htmlToPlaintext", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t, r) {
          return "" === r || null == r ? t : e;
        };
      }
      (r.r(t), r(2).a.filter("isEmpty", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t) {
          var r = [];
          for (var n in t) r.push(e[t[n]]);
          return r;
        };
      }
      (r.r(t), r(2).a.filter("orderList", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      (r.r(t),
        r(2).a.filter("parseInt", function () {
          return function (e, t) {
            var r = parseInt(e, t || 10);
            return Number.isNaN(r) ? e : r;
          };
        }),
        (t.default = parseInt));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          return e
            ? "string" == typeof e && -1 < e.search("Date")
              ? parseInt(e.slice(6, -2))
              : new Date(e)
            : null;
        };
      }
      (r.r(t), r(2).a.filter("parseTimeStamp", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          return e ? Math.abs(e) : 0;
        };
      }
      (r.r(t), r(2).a.filter("positive", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(22);
      function a() {
        return function (e) {
          return i.a.quoteText(e);
        };
      }
      (n.a.filter("quoteText", a), (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e) {
          if (e && 0 < e.length) return e.slice().reverse();
        };
      }
      (r.r(t), r(2).a.filter("reverse", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a() {
        return function (e, t, r) {
          "string" != typeof r && (r = "");
          var n =
            "/" +
            e +
            "/" +
            t +
            "/" +
            (r
              .replace(/'/g, "")
              .replace(/[^a-zA-Z0-9]+/g, "-")
              .replace(/^-+|-+$/g, "")
              .replace(/^(COM\d|LPT\d|AUX|PRT|NUL|CON|BIN)$/i, "") ||
              "unnamed");
          return i.Endpoints ? i.Endpoints.getAbsoluteUrl(n) : n;
        };
      }
      (n.a.filter("seoUrl", a), (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return function (e, t, r) {
          var n = [];
          if (e)
            for (var i = 0; i < e.length; i++) {
              var a = r ? e[i][r].toLowerCase() : e[i].toLowerCase();
              0 === a.indexOf(t.toLowerCase()) &&
                t.length < a.length &&
                n.push(e[i]);
            }
          return (0 === n.length && (n = e), n);
        };
      }
      (r.r(t), r(2).a.filter("startsWith", n), (t.default = n));
    },
    function (e, t, r) {
      var n = {
        "./abTestService.js": 122,
        "./abpService.js": 123,
        "./batchRequestsService.js": 124,
        "./cacheService.js": 125,
        "./chatDispatchService.js": 126,
        "./errorMessageService.js": 127,
        "./eventStreamService.js": 128,
        "./eventTrackerService.js": 129,
        "./friendsInfoService.js": 130,
        "./googleAnalyticsEventsService.js": 131,
        "./httpService.js": 132,
        "./hybridService.js": 133,
        "./imagesService.js": 134,
        "./localStorageService.js": 135,
        "./numericCodeService.js": 136,
        "./performanceService.js": 137,
        "./playGameService.js": 138,
        "./realtimeService.js": 139,
        "./regexService.js": 140,
        "./retryService.js": 141,
        "./urlService.js": 142,
        "./userService.js": 143,
      };
      function i(e) {
        var t = a(e);
        return r(t);
      }
      function a(e) {
        var t = n[e];
        if (t + 1) return t;
        var r = new Error("Cannot find module '" + e + "'");
        throw ((r.code = "MODULE_NOT_FOUND"), r);
      }
      ((i.keys = function () {
        return Object.keys(n);
      }),
        (i.resolve = a),
        ((e.exports = i).id = 121));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a(u, r) {
        function s(e) {
          var t = {
            url: i.EnvironmentUrls.abtestingApiSite + u.urls.checkEnrollment,
            retryable: !1,
            withCredentials: !0,
          };
          return r.httpPost(t, e);
        }
        function o(e) {
          var t = {
            url: i.EnvironmentUrls.abtestingApiSite + u.urls.enroll,
            retryable: !1,
            withCredentials: !0,
          };
          return r.httpPost(t, e);
        }
        return {
          checkAbTestEnrollments: s,
          enrollInAbTests: o,
          checkAbTestEnrollment: function (e, t, n, i) {
            var a = [{ SubjectType: t, SubjectTargetId: e, ExperimentName: n }],
              o = { enrolled: !1, success: !1, variation: null };
            return $q(function (t, r) {
              s(a).then(
                function (e) {
                  (e.data &&
                    e.data.forEach(function (e) {
                      if (e.ExperimentName === n)
                        return (
                          (o.success = !!e),
                          (o.variation = e.Variation),
                          (o.enrolled = e.Variation === i),
                          void t(o)
                        );
                    }),
                    r({
                      code: u.errorCode.noResultForExperiment,
                      message: "No result for the specified experiment name.",
                    }));
                },
                function (e) {
                  r(e);
                },
              );
            });
          },
          enrollInAbTest: function (e, t, n) {
            var i = [{ SubjectType: t, SubjectTargetId: e, ExperimentName: n }],
              a = { enrolled: !1, success: !1, variation: null };
            return $q(function (t, r) {
              o(i).then(
                function (e) {
                  (e.data &&
                    e.data.forEach(function (e) {
                      if (e.ExperimentName === n)
                        return (
                          (a.success = !!e),
                          (a.variation = e.Variation),
                          (a.enrolled =
                            e.Status === u.response.status.enrolled),
                          void t(a)
                        );
                    }),
                    r({
                      code: u.errorCode.noResultForExperiment,
                      message: "No result for the specified experiment name.",
                    }));
                },
                function (e) {
                  r(e);
                },
              );
            });
          },
        };
      }
      ((a.$inject = ["abTestConstants", "httpService"]),
        n.a.factory("abTestService", a),
        (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a() {
        return {
          registerAd: function (e) {
            i.AdsHelper &&
              i.AdsHelper.AdRefresher &&
              i.AdsHelper.AdRefresher.registerAd(e);
          },
          refreshAllAds: function () {
            i.AdsHelper &&
              i.AdsHelper.AdRefresher &&
              i.AdsHelper.AdRefresher.refreshAds();
          },
          adIds: {
            leaderboardAbp: "Leaderboard-Abp",
            skyscraperAdpRight: "Skyscraper-Abp-Right",
          },
        };
      }
      (n.a.factory("abpService", a), (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(e, v) {
        return {
          cooldowns: {
            createExponentialBackoffCooldown: function (r, n) {
              return function (e) {
                var t = Math.pow(2, e - 1) * r;
                return Math.min(n, t);
              };
            },
          },
          createRequestProcessor: function (o, n, u) {
            var s = {},
              c = [],
              l = !1;
            u.hasOwnProperty("processBatchWaitTime") ||
              (u.processBatchWaitTime = v.defaultProcessBatchWaitTime);
            function f(e, t, r) {
              var n = 0,
                i = new Date().getTime();
              (e.forEach(function (e) {
                if (s.hasOwnProperty(e.key)) e.resolve(s[e.key]);
                else if (
                  u.maxRetryAttempts &&
                  0 < u.maxRetryAttempts &&
                  r !== v.errors.unretriableFailure
                ) {
                  var t = (function (e) {
                    return u.getFailureCooldown
                      ? u.getFailureCooldown(e)
                      : v.defaultCooldown;
                  })(e.retryAttempts);
                  ((n = 0 < n ? Math.min(n, t) : t),
                    ++e.retryAttempts <= u.maxRetryAttempts
                      ? ((e.queueAfter = i + t), c.unshift(e))
                      : e.reject(v.errors.maxAttemptsReached));
                } else e.reject(r);
              }),
                0 < n && setTimeout(t, n + u.processBatchWaitTime),
                (l = !1),
                t());
            }
            function d(e, t) {
              ((s[e] = t),
                u.getItemExpiration &&
                  setTimeout(function () {
                    delete s[e];
                  }, u.getItemExpiration(e)));
            }
            function p() {
              if (!l) {
                for (
                  var r = [], e = {}, t = [], n = new Date().getTime();
                  r.length < u.batchSize && 0 < c.length;
                ) {
                  var i = c.shift();
                  i.queueAfter > n
                    ? ((e[i.key] = i), t.push(i))
                    : s.hasOwnProperty(i.key)
                      ? i.resolve(s[i.key])
                      : e.hasOwnProperty(i.key)
                        ? t.push(i)
                        : ((e[i.key] = i), r.push(i));
                }
                if (
                  (t.forEach(function (e) {
                    c.push(e);
                  }),
                  !(r.length <= 0))
                ) {
                  l = !0;
                  var a = [];
                  (r.forEach(function (e) {
                    a.push(e.item);
                  }),
                    o(a).then(
                      function (e) {
                        for (var t in e) e.hasOwnProperty(t) && d(t, e[t]);
                        f(r, p, v.errors.processFailure);
                      },
                      function (e) {
                        f(r, p, e);
                      },
                    ));
                }
              }
            }
            return {
              invalidateItem: function (e) {
                delete s[n(e)];
              },
              queueItem: function (r) {
                return e(function (e, t) {
                  (c.push({
                    key: n(r),
                    item: r,
                    retryAttempts: 0,
                    queueAfter: 0,
                    resolve: e,
                    reject: t,
                  }),
                    setTimeout(p, u.processBatchWaitTime));
                });
              },
            };
          },
        };
      }
      ((i.$inject = ["$q", "batchRequestsConstants"]),
        n.a.factory("batchRequestsService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          createPaginationCache: function (n) {
            var i = {};
            return {
              getPage: function (e, t) {
                return i[e] ? i[e].slice((t - 1) * n, t * n) : [];
              },
              getLength: function (e) {
                return i[e] ? i[e].length : 0;
              },
              append: function (e, t) {
                (i[e] || (i[e] = []), (i[e] = i[e].concat(t)));
              },
              removePage: function (e, t) {
                i[e] && i[e].splice((t - 1) * n, n);
              },
              removeAtIndex: function (e, t, r) {
                i[e] && i[e].splice((t - 1) * n + r, 1);
              },
              clear: function (e) {
                i[e] = [];
              },
            };
          },
          buildKey: function (e) {
            var t = "";
            for (var r in e) e.hasOwnProperty(r) && (t += "&" + r + "=" + e[r]);
            return t;
          },
        };
      }
      (r.r(t), r(2).a.factory("cacheService", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        o = r(3);
      function i(i, a, e) {
        return {
          startChat: function (e, t) {
            var r = o.DeviceMeta && new o.DeviceMeta();
            if (r && r.isAndroidApp && t.androidApp.hybridRequired) {
              var n = { userIds: [] };
              (n.userIds.push(e), i.startChatConversation(n));
            } else
              r && r.isIosApp && t.iOSApp.hybridRequired
                ? i.startWebChatConversation(e)
                : r && r.isUWPApp && t.uwpApp.hybridRequired
                  ? i.startWebChatConversation(e)
                  : r && r.isWin32App && t.win32App.hybridRequired
                    ? i.startWebChatConversation(e)
                    : a.triggerHandler("Roblox.Chat.StartChat", { userId: e });
          },
          buildPermissionVerifier: function (e) {
            return {
              androidApp: { isEnabled: e.inAndroidApp, hybridRequired: !0 },
              iOSApp: { isEnabled: e.iniOSApp, hybridRequired: !0 },
              uwpApp: { isEnabled: e.inUWPApp, hybridRequired: !1 },
              win32App: { isEnabled: e.inWin32App, hybridRequired: !0 },
            };
          },
        };
      }
      ((i.$inject = ["hybridService", "$document", "$log"]),
        n.a.factory("chatDispatchService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return (
          (this.createErrorMapper = function (e, t) {
            var r = { defaultError: t };
            return (
              angular.extend(r, e),
              (r.getErrorMessage = function (e) {
                return this[e] || this.defaultError;
              }),
              (r.getErrorMessageFromResponse = function (e) {
                var t = "defaultError";
                return (
                  e &&
                    e.errors &&
                    e.errors[0] &&
                    e.errors[0].hasOwnProperty("code") &&
                    (t = e.errors[0].code),
                  r.getErrorMessage(t)
                );
              }),
              r
            );
          }),
          this
        );
      }
      (r.r(t), r(2).a.factory("errorMessageService", n), (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        a = r(3);
      function i(e) {
        function i() {
          return a.EventStream;
        }
        return {
          targetTypes: i()
            ? {
                DEFAULT: a.EventStream.TargetTypes.DEFAULT,
                WWW: a.EventStream.TargetTypes.WWW,
                STUDIO: a.EventStream.TargetTypes.STUDIO,
                DIAGNOSTIC: a.EventStream.TargetTypes.DIAGNOSTIC,
              }
            : { DEFAULT: 0, WWW: 1, STUDIO: 2, DIAGNOSTIC: 3 },
          eventNames: {
            global: {
              ajaxPageLoad: "ajaxPageLoad",
              modalAction: "modalAction",
              buttonAction: "buttonAction",
            },
            notificationStream: {
              openFromNewIntro: "nsOpenFromNewIntro",
              openContent: "nsOpenContent",
              acceptFriendRequest: "nsAcceptFriendRequest",
              ignoreFriendRequest: "nsIgnoreFriendRequest",
              viewAllFriendRequests: "nsViewAllFriendRequests",
              chat: "nsChat",
              goToProfilePage: "nsGoToProfilePage",
              goToSettingPage: "nsGoToSettingPage",
            },
            account: {
              sendVerificationEmail: "sendVerificationEmail",
              addEmail: "addEmail",
              addPhone: "addPhone",
              verifyPhone: "verifyPhone",
              updateTheme: "updateTheme",
            },
          },
          modalActions: {
            shown: "shown",
            dismissed: "dismissed",
            buttonClicked: "buttonClicked",
          },
          sendEventWithTarget: function (e, t, r, n) {
            i() &&
              a.EventStream.SendEventWithTarget &&
              ((n = n || this.targetTypes.WWW),
              a.EventStream.SendEventWithTarget(e, t, r, n));
          },
          sendGamePlayEvent: function (e, t, r) {
            a.GamePlayEvents &&
              a.GamePlayEvents.SendGamePlayIntent &&
              a.GamePlayEvents.SendGamePlayIntent(e, t, r);
          },
          sendModalShownEvent: function (e, t) {
            var r = { aType: this.modalActions.shown };
            (t && (r = angular.extend(r, t)),
              this.sendEventWithTarget(
                this.eventNames.global.modalAction,
                e,
                r,
              ));
          },
          sendModalDismissedEvent: function (e, t) {
            var r = { aType: this.modalActions.dismissed };
            (t && (r = angular.extend(r, t)),
              this.sendEventWithTarget(
                this.eventNames.global.modalAction,
                e,
                r,
              ));
          },
          sendModalEvent: function (e, t, r) {
            var n = { aType: t };
            (r && (n = angular.extend(n, r)),
              this.sendEventWithTarget(
                this.eventNames.global.modalAction,
                e,
                n,
              ));
          },
        };
      }
      ((i.$inject = ["$log"]),
        n.a.factory("eventStreamService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(e) {
        return {
          fireEvent: function (e) {
            void 0 !== EventTracker &&
              null !== EventTracker &&
              EventTracker.fireEvent &&
              EventTracker.fireEvent(e);
          },
        };
      }
      ((i.$inject = ["$log"]),
        n.a.factory("eventTrackerService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        y = r(3);
      function i(u, n, s, c, l, f, d) {
        var i,
          p,
          v,
          h,
          e =
            ((i = []),
            (p = {}),
            (h = !(v = 100)),
            (t.prototype.register = function (e, t, r) {
              ("function" == typeof e && i.push(e),
                this.isInitialized
                  ? h && e(p)
                  : ((this.isInitialized = !0),
                    !r && y.CurrentUser && (r = y.CurrentUser.userId),
                    a(0, t, { userId: r }).then(function (t) {
                      i.forEach(function (e) {
                        e(t);
                      });
                    })));
            }),
            t);
        function t() {
          this.isInitialized = !1;
        }
        function m(r) {
          r &&
            u.on("Roblox.Presence.Update", function (e, t) {
              t &&
                n(function () {
                  (t.forEach(function (e) {
                    var t = e.userId;
                    r[t] && (r[t].presence = e);
                  }),
                    f.saveDataByTimeStamp(d.friendsDict, r));
                });
            });
        }
        function g(e, t) {
          return (
            e &&
            e.isEnabled &&
            y.CurrentUser &&
            t.userId === y.CurrentUser.userId
          );
        }
        function a(e, n, i) {
          if (g(n, i)) {
            var t = f.fetchNonExpiredCachedData(d.friendsDict, n.expirationMS);
            if (t) {
              var r = t.data;
              ((h = !0), m((p = r)));
              var a = l.defer();
              return (a.resolve(r), a.promise);
            }
          }
          var o = {
            url:
              Roblox.EnvironmentUrls.friendsApi + "/v1/users/{userId}/friends",
            retryable: !0,
            withCredentials: !0,
          };
          return (
            (o.url = c("formatString")(o.url, { userId: i.userId })),
            s.httpGet(o).then(function (e) {
              var t = e.data ? e.data : e,
                r = [];
              return (
                angular.forEach(t, function (e) {
                  var t = e.id;
                  (r.push(t),
                    (e.profileUrl = c("formatString")(
                      "/users/{userId}/profile",
                      { userId: t },
                    )),
                    (p[t] = e));
                }),
                (function (e) {
                  for (
                    var t = [],
                      r = 0,
                      n = {
                        url:
                          y.EnvironmentUrls.presenceApi + "/v1/presence/users",
                        retryable: !0,
                        withCredentials: !0,
                      },
                      i = e.slice(r, v);
                    0 < i.length;
                  ) {
                    var a = { userIds: i };
                    (t.push(s.httpPost(n, a)),
                      r++,
                      (i = e.slice(r * v, r * v + v)));
                  }
                  return l.all(t);
                })(r).then(function (e) {
                  if (e && 0 < e.length) {
                    var r = [];
                    (angular.forEach(e, function (e) {
                      var t = e.userPresences;
                      r = r.concat(t);
                    }),
                      r.forEach(function (e) {
                        p[e.userId].presence = e;
                      }));
                  }
                  return (
                    g(n, i) &&
                      (f.saveDataByTimeStamp(d.friendsDict, p),
                      m(p),
                      u.on("Roblox.Logout", function () {
                        f.removeLocalStorage(d.friendsDict);
                      })),
                    (h = !0),
                    p
                  );
                })
              );
            })
          );
        }
        return (
          Roblox.sharedFriendsService ||
            (Roblox.sharedFriendsService = new e()),
          Roblox.sharedFriendsService
        );
      }
      ((i.$inject = [
        "$document",
        "$timeout",
        "httpService",
        "$filter",
        "$q",
        "localStorageService",
        "localStorageNames",
      ]),
        n.a.factory("friendsInfoService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      function n() {
        return {
          eventCategories: { JSErrors: "JSErrors" },
          eventActions: { Chat: "Chat", ChatEmbedded: "ChatEmbedded" },
          getUserAgent: function () {
            return navigator && navigator.userAgent ? navigator.userAgent : "";
          },
          fireEvent: function (e, t, r, n) {
            var i = (function (e, t, r, n) {
              var i = [];
              return (
                i.push(e),
                i.push(t),
                i.push(r),
                isNaN(n) || ((n = Math.floor(n)), i.push(n)),
                i
              );
            })(e, t, r, n);
            GoogleAnalyticsEvents && GoogleAnalyticsEvents.FireEvent(i);
          },
          viewVirtual: function (e) {
            GoogleAnalyticsEvents && GoogleAnalyticsEvents.ViewVirtual(e);
          },
        };
      }
      (r.r(t),
        r(2).a.factory("googleAnalyticsEventsService", n),
        (t.default = n));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(i, c, a, o) {
        var u = { get: "GET", post: "POST", delete: "DELETE", patch: "PATCH" },
          s = { default: 0, subdomain: 1 };
        function l(e, t) {
          return (
            (function (e, t) {
              e.withCredentials && (t.withCredentials = e.withCredentials);
            })(t, e),
            (function (e, t) {
              e.retryable && (t.retryable = e.retryable);
            })(t, e),
            (function (e, t) {
              e.noCache &&
                (t.headers = {
                  "Cache-Control": "no-cache, no-store, must-revalidate",
                  Pragma: "no-cache",
                  Expires: 0,
                });
            })(t, e),
            (function (e, t) {
              e.headers &&
                (t.headers = angular.extend(t.headers || {}, e.headers || {}));
            })(t, e),
            (function (e, t) {
              e.withFile &&
                ((t.transformRequest = function (e) {
                  var r = new FormData();
                  return (
                    angular.forEach(e, function (e, t) {
                      r.append(t, e);
                    }),
                    r
                  );
                }),
                (t.headers = angular.extend(t.headers || {}, {
                  "Content-Type": void 0,
                })));
            })(t, e),
            (function (e, t) {
              if (e.cacheBusting)
                switch (e.cacheBusting.type) {
                  case s.subdomain:
                  default:
                    var r =
                        a && a.location
                          ? a.location.host
                          : window.location.host,
                      n = "";
                    (0 <= r.indexOf(".") &&
                      (n = "?subdomain=" + r.split(".")[0]),
                      (t.url += n));
                }
            })(t, e),
            (function (e, t) {
              e.timeout && (t.timeout = e.timeout);
            })(t, e),
            e
          );
        }
        function f(r) {
          var n = c.defer();
          return (
            i(r).then(
              function (e) {
                var t = e.data;
                ("null" === t && (t = null), n.resolve(t));
              },
              function (e) {
                var t = e.data;
                (o.debug("Error: unable to send " + r.url + " request."),
                  n.reject(t));
              },
            ),
            n.promise
          );
        }
        function n(e) {
          var t = [];
          return (
            e &&
              e.errors &&
              e.errors.forEach(function (e) {
                e.code && t.push(e.code);
              }),
            t
          );
        }
        function d(e, t) {
          var r = n(e)[0] || 0;
          return t ? t[r] || 0 : r;
        }
        return {
          methods: u,
          cacheBustingType: s,
          httpGet: function (e, t, r) {
            if (!e) return !1;
            var n = (function (e, t) {
              var r = { method: u.get, url: e.url, params: t };
              return (r = l(r, e));
            })(e, t);
            return r ? i(n) : f(n);
          },
          httpPost: function (e, t, r) {
            if (!e) return !1;
            var n = (function (e, t) {
              var r = { method: u.post, url: e.url, data: t };
              return (r = l(r, e));
            })(e, t);
            return r ? i(n) : f(n);
          },
          httpDelete: function (e, t) {
            return (
              !!e &&
              f(
                (function (e, t) {
                  var r = { method: u.delete, url: e.url, data: t };
                  return (r = l(r, e));
                })(e, t),
              )
            );
          },
          httpPatch: function (e, t) {
            return (
              !!e &&
              f(
                (function (e, t) {
                  var r = { method: u.patch, url: e.url, data: t };
                  return (r = l(r, e));
                })(e, t),
              )
            );
          },
          getApiErrorCodes: n,
          getPrimaryApiErrorCode: d,
          getApiErrorCodeHandler: function (t, r) {
            return function (e) {
              t(d(e, r));
            };
          },
          buildBatchPromises: function (e, t, r, n, i) {
            r = r || 50;
            for (var a = [], o = 0, u = t.slice(o, r); 0 < u.length; ) {
              var s = {};
              switch (((s[n] = u), i)) {
                case "POST":
                  a.push(this.httpPost(e, s));
                  break;
                case "GET":
                default:
                  a.push(this.httpGet(e, s));
              }
              (o++, (u = t.slice(o * r, o * r + r)));
            }
            return c.all(a);
          },
        };
      }
      ((i.$inject = ["$http", "$q", "$window", "$log"]),
        n.a.factory("httpService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a(e) {
        function r() {
          return i.Hybrid;
        }
        return {
          startChatConversation: function (e, t) {
            r() &&
              i.Hybrid.Chat &&
              (angular.isUndefined(t) && (t = function () {}),
              i.Hybrid.Chat.startChatConversation(e, t));
          },
          startWebChatConversation: function (e, t) {
            r() &&
              i.Hybrid.Navigation &&
              (angular.isUndefined(t) && (t = function () {}),
              i.Hybrid.Navigation.startWebChatConversation(e, t));
          },
          navigateToFeature: function (e, t) {
            r() &&
              i.Hybrid.Navigation &&
              (angular.isUndefined(t) && (t = function () {}),
              i.Hybrid.Navigation.navigateToFeature(e, t));
          },
          openUserProfile: function (e, t) {
            r() &&
              i.Hybrid.Navigation &&
              (angular.isUndefined(t) && (t = function () {}),
              i.Hybrid.Navigation.openUserProfile(e, t));
          },
          close: function (e) {
            r() &&
              i.Hybrid.Overlay &&
              (angular.isUndefined(e) && (e = function () {}),
              i.Hybrid.Overlay.close(e));
          },
          launchGame: function (e, t) {
            r() &&
              i.Hybrid.Game &&
              (angular.isUndefined(t) && (t = function () {}),
              i.Hybrid.Game.launchGame(e, t));
          },
        };
      }
      ((a.$inject = ["$log"]),
        n.a.factory("hybridService", a),
        (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(o, u, a, s) {
        var e = angular.element("#image-retry-data"),
          c = (0 < e.length && Number(e.data("image-retry-timer"))) || 1500,
          l = "Errors from http call: ",
          f = (0 < e.length && Number(e.data("image-retry-max-times"))) || 10;
        function d(t, r, n, i) {
          if (!t.RetryUrl) return !1;
          var e = { url: t.RetryUrl, withCredentials: !0 };
          a.httpGet(e, null).then(
            function (e) {
              return (function (e, t, r, n, i) {
                if (s.isExponentialBackOffEnabled) {
                  var a = (i = i || s.exponentialBackOff()).StartNewAttempt();
                  if (((n = i.GetAttemptCount()), f <= n || e.Final))
                    return (i.Reset(), r(e.Url, e.Final));
                  ((e.RetryUrl = t.RetryUrl),
                    o(function () {
                      d(e, r, n, i);
                    }, a));
                } else {
                  if (
                    (u.log(" --- old image retry logic count ---" + n),
                    f <= n || e.Final)
                  )
                    return ((n = 0), r(e.Url, e.Final));
                  (n++,
                    (e.RetryUrl = t.RetryUrl),
                    o(function () {
                      d(e, r, n);
                    }, c));
                }
                return !1;
              })(e, t, r, n, i);
            },
            function (e, t) {
              return (u.debug(l + t), !1);
            },
          );
        }
        return {
          setRetryTimer: function (e) {
            c = e;
          },
          setMaxTry: function (e) {
            f = e;
          },
          getImageUrl: d,
        };
      }
      ((i.$inject = ["$timeout", "$log", "httpService", "retryService"]),
        n.a.factory("robloxImagesService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(e) {
        return {
          getUserKey: function (e) {
            return "user_" + e;
          },
          storage: function () {
            return Roblox && Roblox.LocalStorage
              ? Roblox.LocalStorage.isAvailable()
              : localStorage;
          },
          getLength: function () {
            return this.storage() ? localStorage.length : 0;
          },
          getKey: function (e) {
            return this.storage() ? localStorage.key(e) : "";
          },
          setLocalStorage: function (e, t) {
            this.storage() && localStorage.setItem(e, JSON.stringify(t));
          },
          getLocalStorage: function (e) {
            if (this.storage()) return JSON.parse(localStorage.getItem(e));
          },
          listenLocalStorage: function (e) {
            this.storage() &&
              angular.isDefined(e) &&
              (window.addEventListener
                ? window.addEventListener("storage", e, !1)
                : window.attachEvent("onstorage", e));
          },
          removeLocalStorage: function (e) {
            this.storage() && localStorage.removeItem(e);
          },
          saveDataByTimeStamp: function (e, t) {
            var r = new Date().getTime(),
              n = this.getLocalStorage(e);
            (((n = n || {}).data = t),
              (n.timeStamp = r),
              this.setLocalStorage(e, n));
          },
          fetchNonExpiredCachedData: function (e, t) {
            var r = new Date().getTime(),
              n = this.getLocalStorage(e);
            if (n && n.timeStamp && r - n.timeStamp < (t = t || 3e4)) return n;
            return null;
          },
        };
      }
      ((i.$inject = ["$log"]),
        n.a.factory("localStorageService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(r) {
        return {
          checkCode: function (e, t) {
            return (r.debug(e, t), e && e.length === t && /^\d+$/.test(e));
          },
        };
      }
      ((i.$inject = ["$log"]),
        n.a.factory("numericCodeService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a(e) {
        return {
          logSinglePerformanceMark: function (e) {
            i.Performance && i.Performance.logSinglePerformanceMark(e);
          },
        };
      }
      ((a.$inject = ["$log"]),
        n.a.factory("performanceService", a),
        (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        s = r(3);
      function i(e, i) {
        function o(e) {
          var t = e.eventName,
            r = e.ctx,
            n = e.properties;
          i.sendEventWithTarget(t, r, n);
        }
        function u(e, t) {
          i.sendGamePlayEvent(e, t);
        }
        return {
          launchGame: function (e, t) {
            if (s.GameLauncher) {
              var r = e.rootPlaceId,
                n = e.placeId,
                i = e.gameInstanceId,
                a = e.playerId;
              n === r && i
                ? ((t.properties.gameInstanceId = i),
                  o(t),
                  u(t.gamePlayIntentEventCtx, r),
                  (function (e, t) {
                    s.GameLauncher.joinGameInstance(e, t, !0, !0);
                  })(n, i))
                : r && a
                  ? ((t.properties.playerId = a),
                    o(t),
                    u(t.gamePlayIntentEventCtx, r),
                    (function (e) {
                      s.GameLauncher.followPlayerIntoGame(e);
                    })(a))
                  : (o(t),
                    u(t.gamePlayIntentEventCtx, n),
                    (function (e) {
                      s.GameLauncher.joinMultiplayerGame(e);
                    })(n));
            }
          },
          buildPlayGameProperties: function (e, t, r, n) {
            return {
              rootPlaceId: e,
              placeId: t,
              gameInstanceId: r,
              playerId: n,
            };
          },
        };
      }
      ((i.$inject = ["$log", "eventStreamService"]),
        n.a.factory("playGameService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a(n) {
        function e() {
          return i.RealTime;
        }
        return {
          realTimeTypes: {
            friendshipNotifications: "FriendshipNotifications",
            presenceNotifications: "PresenceNotifications",
            gameCloseNotifications: "GameCloseNotifications",
            userThemeTypeChangeNotification: "UserThemeTypeChangeNotification",
          },
          notificationTypes: {
            friendshipNotifications: {
              friendshipDestroyed: "FriendshipDestroyed",
              friendshipCreated: "FriendshipCreated",
              friendshipDeclined: "FriendshipDeclined",
              friendshipRequested: "FriendshipRequested",
            },
            presenceNotifications: {
              presenceOffline: "UserOffline",
              presenceOnline: "UserOnline",
            },
            gameCloseNotifications: { close: "Close" },
            userThemeTypeChangeNotification: { themeUpdate: "ThemeUpdate" },
          },
          isRealTimeValid: e,
          getRealTimeClient: function () {
            return e() ? i.RealTime.Factory.GetClient() : null;
          },
          listenToNotification: function (t, r) {
            e() &&
              angular.isDefined(r) &&
              this.getRealTimeClient().Subscribe(t, function (e) {
                (n.debug(
                  "--------- this is " +
                    t +
                    " subscription -----------" +
                    e.Type,
                ),
                  e && e.Type && r[e.Type] && r[e.Type](e));
              });
          },
        };
      }
      ((a.$inject = ["$log"]),
        n.a.factory("realtimeService", a),
        (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2);
      function i(t, r) {
        return {
          getEmailRegex: function () {
            var e = { url: r.getAbsoluteUrl("/regex/email") };
            return t.httpGet(e, null);
          },
        };
      }
      ((i.$inject = ["httpService", "urlService"]),
        n.a.factory("regexService", i),
        (t.default = i));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a(e) {
        function t() {
          return !!(
            i.Utilities &&
            i.Utilities.ExponentialBackoff &&
            i.Utilities.ExponentialBackoffSpecification
          );
        }
        return {
          isExponentialBackOffEnabled: t(),
          exponentialBackOff: function () {
            if (t()) {
              var e = new i.Utilities.ExponentialBackoffSpecification({
                firstAttemptDelay: 2e3,
                firstAttemptRandomnessFactor: 3,
                subsequentDelayBase: 1e4,
                subsequentDelayRandomnessFactor: 0.5,
                maximumDelayBase: 3e5,
              });
              return new i.Utilities.ExponentialBackoff(e);
            }
            return null;
          },
        };
      }
      ((a.$inject = ["$log"]), n.a.factory("retryService", a), (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        i = r(3);
      function a() {
        var t;
        function e(e) {
          return i.Endpoints ? i.Endpoints.getAbsoluteUrl(e) : e;
        }
        function r(e) {
          var r = {};
          (void 0 === e && (e = window.location.search),
            e &&
              -1 < e.indexOf("?") &&
              (e
                .substr(1)
                .split("&")
                .forEach(function (e) {
                  var t = e.split("=");
                  r[t[0].toLowerCase()] = t[1]
                    ? decodeURIComponent(t[1])
                    : null;
                }),
              (t = r)));
          return r;
        }
        return {
          getAbsoluteUrl: e,
          getJsonFromQueryString: r,
          getParam: function (e) {
            return (t || r(), (e = e.toLowerCase()), t && t[e] ? t[e] : void 0);
          },
          getGameDetailReferralUrls: function () {
            return {
              home: e(
                "/games/refer?SortName={sortName}&PlaceId={placeId}&Position={position}&PageType=Home&LocalTimestamp={localTimestamp}&TotalInSort={totalInSort}&SortPosition={sortPosition}&PageId={pageId}",
              ),
              groupDetail: e(
                "/games/refer?PlaceId={placeId}&PageType=GroupDetail&LocalTimestamp={localTimestamp}",
              ),
              chat: e(
                "/games/refer?SortName={sortName}&PlaceId={placeId}&PageType=Chat",
              ),
            };
          },
        };
      }
      (n.a.factory("urlService", a), (t.default = a));
    },
    function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r(2),
        u = r(3);
      function i(i, a) {
        var o = u.EnvironmentUrls.presenceApi + "/v1/presence/users";
        return {
          getUserAvatar: function (e) {
            var t = {
                url: a.getAbsoluteUrl("/thumbnail/avatar-headshots"),
                withCredentials: !0,
                retryable: !0,
              },
              r = { userIds: e };
            return i.httpGet(t, r);
          },
          getUserPresence: function (e) {
            var t = o,
              r = {
                url: a.getAbsoluteUrl(t),
                withCredentials: !0,
                retryable: !0,
              },
              n = { userIds: e };
            return i.httpPost(r, n);
          },
        };
      }
      ((i.$inject = ["httpService", "urlService"]),
        n.a.factory("userService", i),
        (t.default = i));
    },
  ]);
  //# sourceMappingURL=https://js.rbxcdn.com/833715350611d1c28d50-angularJsUtilities.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("AngularJsUtilities");
}

