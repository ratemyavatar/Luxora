var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (r) {
    var n = {};
    function o(t) {
      if (n[t]) return n[t].exports;
      var e = (n[t] = { i: t, l: !1, exports: {} });
      return (r[t].call(e.exports, e, e.exports, o), (e.l = !0), e.exports);
    }
    ((o.m = r),
      (o.c = n),
      (o.d = function (t, e, r) {
        o.o(t, e) || Object.defineProperty(t, e, { enumerable: !0, get: r });
      }),
      (o.r = function (t) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(t, "__esModule", { value: !0 }));
      }),
      (o.t = function (e, t) {
        if ((1 & t && (e = o(e)), 8 & t)) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
        if (
          (o.r(r),
          Object.defineProperty(r, "default", { enumerable: !0, value: e }),
          2 & t && "string" != typeof e)
        )
          for (var n in e)
            o.d(
              r,
              n,
              function (t) {
                return e[t];
              }.bind(null, n),
            );
        return r;
      }),
      (o.n = function (t) {
        var e =
          t && t.__esModule
            ? function () {
                return t.default;
              }
            : function () {
                return t;
              };
        return (o.d(e, "a", e), e);
      }),
      (o.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
      }),
      (o.p = ""),
      o((o.s = 13)));
  })({
    0: function (t, e) {
      t.exports = Roblox;
    },
    13: function (t, e, r) {
      "use strict";
      r.r(e);
      var n = r(2),
        o = window.Roblox || {};
      ((o.Intl = n.a), (window.Roblox = o), (e.default = n.a));
    },
    2: function (t, e, r) {
      "use strict";
      var n,
        o,
        u = r(0),
        i = a;
      function a(t, e, r) {
        ((this.locales = t), (this.formats = e), (this.pluralFn = r));
      }
      function l(t) {
        this.id = t;
      }
      function s(t, e, r, n, o) {
        ((this.id = t),
          (this.useOrdinal = e),
          (this.offset = r),
          (this.options = n),
          (this.pluralFn = o));
      }
      function c(t, e, r, n) {
        ((this.id = t),
          (this.offset = e),
          (this.numberFormat = r),
          (this.string = n));
      }
      function f(t, e) {
        ((this.id = t), (this.options = e));
      }
      function Zt(t, e, r, n) {
        ((this.message = t),
          (this.expected = e),
          (this.found = r),
          (this.location = n),
          (this.name = "SyntaxError"),
          "function" == typeof Error.captureStackTrace &&
            Error.captureStackTrace(this, Zt));
      }
      function p() {
        this.constructor = n;
      }
      ((a.prototype.compile = function (t) {
        return (
          (this.pluralStack = []),
          (this.currentPlural = null),
          (this.pluralNumberFormat = null),
          this.compileMessage(t)
        );
      }),
        (a.prototype.compileMessage = function (t) {
          if (!t || "messageFormatPattern" !== t.type)
            throw new Error(
              'Message AST is not of type: "messageFormatPattern"',
            );
          var e,
            r,
            n,
            o = t.elements,
            i = [];
          for (e = 0, r = o.length; e < r; e += 1)
            switch ((n = o[e]).type) {
              case "messageTextElement":
                i.push(this.compileMessageText(n));
                break;
              case "argumentElement":
                i.push(this.compileArgument(n));
                break;
              default:
                throw new Error("Message element does not have a valid type");
            }
          return i;
        }),
        (a.prototype.compileMessageText = function (t) {
          return this.currentPlural && /(^|[^\\])#/g.test(t.value)
            ? (this.pluralNumberFormat ||
                (this.pluralNumberFormat = new Intl.NumberFormat(this.locales)),
              new c(
                this.currentPlural.id,
                this.currentPlural.format.offset,
                this.pluralNumberFormat,
                t.value,
              ))
            : t.value.replace(/\\#/g, "#");
        }),
        (a.prototype.compileArgument = function (t) {
          var e = t.format;
          if (!e) return new l(t.id);
          var r,
            n = this.formats,
            o = this.locales,
            i = this.pluralFn;
          switch (e.type) {
            case "numberFormat":
              return (
                (r = n.number[e.style]),
                { id: t.id, format: new Intl.NumberFormat(o, r).format }
              );
            case "dateFormat":
              return (
                (r = n.date[e.style]),
                { id: t.id, format: new Intl.DateTimeFormat(o, r).format }
              );
            case "timeFormat":
              return (
                (r = n.time[e.style]),
                { id: t.id, format: new Intl.DateTimeFormat(o, r).format }
              );
            case "pluralFormat":
              return (
                (r = this.compileOptions(t)),
                new s(t.id, e.ordinal, e.offset, r, i)
              );
            case "selectFormat":
              return ((r = this.compileOptions(t)), new f(t.id, r));
            default:
              throw new Error(
                "Message element does not have a valid format type",
              );
          }
        }),
        (a.prototype.compileOptions = function (t) {
          var e,
            r,
            n,
            o = t.format,
            i = o.options,
            a = {};
          for (
            this.pluralStack.push(this.currentPlural),
              this.currentPlural = "pluralFormat" === o.type ? t : null,
              e = 0,
              r = i.length;
            e < r;
            e += 1
          )
            a[(n = i[e]).selector] = this.compileMessage(n.value);
          return ((this.currentPlural = this.pluralStack.pop()), a);
        }),
        (l.prototype.format = function (t) {
          return t || "number" == typeof t
            ? "string" == typeof t
              ? t
              : String(t)
            : "";
        }),
        (s.prototype.getOption = function (t) {
          var e = this.options;
          return (
            e["=" + t] ||
            e[this.pluralFn(t - this.offset, this.useOrdinal)] ||
            e.other
          );
        }),
        (c.prototype.format = function (t) {
          var e = this.numberFormat.format(t - this.offset);
          return this.string
            .replace(/(^|[^\\])#/g, "$1" + e)
            .replace(/\\#/g, "#");
        }),
        (f.prototype.getOption = function (t) {
          var e = this.options;
          return e[t] || e.other;
        }));
      var m =
          ((n = Zt),
          (o = Error),
          (p.prototype = o.prototype),
          (n.prototype = new p()),
          {
            SyntaxError: Zt,
            parse: function (l) {
              var t,
                e = 1 < arguments.length ? arguments[1] : {},
                s = {},
                r = { start: St },
                n = St,
                o = function (t) {
                  return {
                    type: "messageFormatPattern",
                    elements: t,
                    location: Dt(),
                  };
                },
                a = function (t) {
                  var e,
                    r,
                    n,
                    o,
                    i,
                    a = "";
                  for (e = 0, n = t.length; e < n; e += 1)
                    for (r = 0, i = (o = t[e]).length; r < i; r += 1) a += o[r];
                  return a;
                },
                i = function (t) {
                  return {
                    type: "messageTextElement",
                    value: t,
                    location: Dt(),
                  };
                },
                u = /^[^ \t\n\r,.+={}#]/,
                c = {
                  type: "class",
                  value: "[^ \\t\\n\\r,.+={}#]",
                  description: "[^ \\t\\n\\r,.+={}#]",
                },
                f = "{",
                p = { type: "literal", value: "{", description: '"{"' },
                m = ",",
                h = { type: "literal", value: ",", description: '","' },
                d = "}",
                y = { type: "literal", value: "}", description: '"}"' },
                g = function (t, e) {
                  return {
                    type: "argumentElement",
                    id: t,
                    format: e && e[2],
                    location: Dt(),
                  };
                },
                v = "number",
                b = {
                  type: "literal",
                  value: "number",
                  description: '"number"',
                },
                w = "date",
                F = { type: "literal", value: "date", description: '"date"' },
                O = "time",
                x = { type: "literal", value: "time", description: '"time"' },
                D = function (t, e) {
                  return {
                    type: t + "Format",
                    style: e && e[2],
                    location: Dt(),
                  };
                },
                _ = "plural",
                A = {
                  type: "literal",
                  value: "plural",
                  description: '"plural"',
                },
                L = function (t) {
                  return {
                    type: t.type,
                    ordinal: !1,
                    offset: t.offset || 0,
                    options: t.options,
                    location: Dt(),
                  };
                },
                C = "selectordinal",
                S = {
                  type: "literal",
                  value: "selectordinal",
                  description: '"selectordinal"',
                },
                P = function (t) {
                  return {
                    type: t.type,
                    ordinal: !0,
                    offset: t.offset || 0,
                    options: t.options,
                    location: Dt(),
                  };
                },
                T = "select",
                j = {
                  type: "literal",
                  value: "select",
                  description: '"select"',
                },
                k = function (t) {
                  return { type: "selectFormat", options: t, location: Dt() };
                },
                E = "=",
                I = { type: "literal", value: "=", description: '"="' },
                R = function (t, e) {
                  return {
                    type: "optionalFormatPattern",
                    selector: t,
                    value: e,
                    location: Dt(),
                  };
                },
                M = "offset:",
                N = {
                  type: "literal",
                  value: "offset:",
                  description: '"offset:"',
                },
                U = function (t) {
                  return t;
                },
                z = function (t, e) {
                  return {
                    type: "pluralFormat",
                    offset: t,
                    options: e,
                    location: Dt(),
                  };
                },
                Z = { type: "other", description: "whitespace" },
                W = /^[ \t\n\r]/,
                Y = {
                  type: "class",
                  value: "[ \\t\\n\\r]",
                  description: "[ \\t\\n\\r]",
                },
                q = { type: "other", description: "optionalWhitespace" },
                B = /^[0-9]/,
                J = { type: "class", value: "[0-9]", description: "[0-9]" },
                $ = /^[0-9a-f]/i,
                G = {
                  type: "class",
                  value: "[0-9a-f]i",
                  description: "[0-9a-f]i",
                },
                H = "0",
                K = { type: "literal", value: "0", description: '"0"' },
                Q = /^[1-9]/,
                V = { type: "class", value: "[1-9]", description: "[1-9]" },
                X = function (t) {
                  return parseInt(t, 10);
                },
                tt = /^[^{}\\\0-\x1F \t\n\r]/,
                et = {
                  type: "class",
                  value: "[^{}\\\\\\0-\\x1F\\x7f \\t\\n\\r]",
                  description: "[^{}\\\\\\0-\\x1F\\x7f \\t\\n\\r]",
                },
                rt = "\\\\",
                nt = {
                  type: "literal",
                  value: "\\\\",
                  description: '"\\\\\\\\"',
                },
                ot = function () {
                  return "\\";
                },
                it = "\\#",
                at = { type: "literal", value: "\\#", description: '"\\\\#"' },
                ut = function () {
                  return "\\#";
                },
                lt = "\\{",
                st = { type: "literal", value: "\\{", description: '"\\\\{"' },
                ct = function () {
                  return "{";
                },
                ft = "\\}",
                pt = { type: "literal", value: "\\}", description: '"\\\\}"' },
                mt = function () {
                  return "}";
                },
                ht = "\\u",
                dt = { type: "literal", value: "\\u", description: '"\\\\u"' },
                yt = function (t) {
                  return String.fromCharCode(parseInt(t, 16));
                },
                gt = function (t) {
                  return t.join("");
                },
                vt = 0,
                bt = 0,
                wt = [{ line: 1, column: 1, seenCR: !1 }],
                Ft = 0,
                Ot = [],
                xt = 0;
              if ("startRule" in e) {
                if (!(e.startRule in r))
                  throw new Error(
                    "Can't start parsing from rule \"" + e.startRule + '".',
                  );
                n = r[e.startRule];
              }
              function Dt() {
                return At(bt, vt);
              }
              function _t(t) {
                var e,
                  r,
                  n = wt[t];
                if (n) return n;
                for (e = t - 1; !wt[e]; ) e--;
                for (
                  n = {
                    line: (n = wt[e]).line,
                    column: n.column,
                    seenCR: n.seenCR,
                  };
                  e < t;
                )
                  ("\n" === (r = l.charAt(e))
                    ? (n.seenCR || n.line++, (n.column = 1), (n.seenCR = !1))
                    : "\r" === r || "\u2028" === r || "\u2029" === r
                      ? (n.line++, (n.column = 1), (n.seenCR = !0))
                      : (n.column++, (n.seenCR = !1)),
                    e++);
                return (wt[t] = n);
              }
              function At(t, e) {
                var r = _t(t),
                  n = _t(e);
                return {
                  start: { offset: t, line: r.line, column: r.column },
                  end: { offset: e, line: n.line, column: n.column },
                };
              }
              function Lt(t) {
                vt < Ft || (Ft < vt && ((Ft = vt), (Ot = [])), Ot.push(t));
              }
              function Ct(t, e, r, n) {
                return (
                  null !== e &&
                    (function (t) {
                      var e = 1;
                      for (
                        t.sort(function (t, e) {
                          return t.description < e.description
                            ? -1
                            : t.description > e.description
                              ? 1
                              : 0;
                        });
                        e < t.length;
                      )
                        t[e - 1] === t[e] ? t.splice(e, 1) : e++;
                    })(e),
                  new Zt(
                    null !== t
                      ? t
                      : (function (t, e) {
                          var r,
                            n = new Array(t.length);
                          for (r = 0; r < t.length; r++)
                            n[r] = t[r].description;
                          function o(t) {
                            return t.charCodeAt(0).toString(16).toUpperCase();
                          }
                          return (
                            "Expected " +
                            (1 < t.length
                              ? n.slice(0, -1).join(", ") +
                                " or " +
                                n[t.length - 1]
                              : n[0]) +
                            " but " +
                            (e
                              ? '"' +
                                e
                                  .replace(/\\/g, "\\\\")
                                  .replace(/"/g, '\\"')
                                  .replace(/\x08/g, "\\b")
                                  .replace(/\t/g, "\\t")
                                  .replace(/\n/g, "\\n")
                                  .replace(/\f/g, "\\f")
                                  .replace(/\r/g, "\\r")
                                  .replace(
                                    /[\x00-\x07\x0B\x0E\x0F]/g,
                                    function (t) {
                                      return "\\x0" + o(t);
                                    },
                                  )
                                  .replace(
                                    /[\x10-\x1F\x80-\xFF]/g,
                                    function (t) {
                                      return "\\x" + o(t);
                                    },
                                  )
                                  .replace(/[\u0100-\u0FFF]/g, function (t) {
                                    return "\\u0" + o(t);
                                  })
                                  .replace(/[\u1000-\uFFFF]/g, function (t) {
                                    return "\\u" + o(t);
                                  }) +
                                '"'
                              : "end of input") +
                            " found."
                          );
                        })(e, r),
                    e,
                    r,
                    n,
                  )
                );
              }
              function St() {
                return Pt();
              }
              function Pt() {
                var t, e, r;
                for (t = vt, e = [], r = Tt(); r !== s; )
                  (e.push(r), (r = Tt()));
                return (e !== s && ((bt = t), (e = o(e))), (t = e));
              }
              function Tt() {
                var t;
                return (
                  (t = (function () {
                    var t, e;
                    return (
                      (t = vt),
                      (e = (function () {
                        var t, e, r, n, o, i;
                        if (
                          ((e = []),
                          (r = t = vt),
                          (r =
                            (n = It()) !== s
                              ? (o = zt()) !== s && (i = It()) !== s
                                ? (n = [n, o, i])
                                : ((vt = r), s)
                              : ((vt = r), s)) !== s)
                        )
                          for (; r !== s; )
                            (e.push(r),
                              (r = vt),
                              (n = It()),
                              (r =
                                n !== s && (o = zt()) !== s && (i = It()) !== s
                                  ? (n = [n, o, i])
                                  : ((vt = r), s)));
                        else e = s;
                        return (
                          e !== s && ((bt = t), (e = a(e))),
                          (t = e) === s &&
                            ((t = vt),
                            (e = Et()),
                            (t = e !== s ? l.substring(t, vt) : e)),
                          t
                        );
                      })()) !== s && ((bt = t), (e = i(e))),
                      (t = e)
                    );
                  })()) === s &&
                    (t = (function () {
                      var t, e, r, n, o, i, a;
                      return (
                        (t = vt),
                        123 === l.charCodeAt(vt)
                          ? ((e = f), vt++)
                          : ((e = s), 0 === xt && Lt(p)),
                        (t =
                          e !== s
                            ? It() !== s &&
                              (r = (function () {
                                var t, e, r;
                                if ((t = Nt()) === s) {
                                  if (
                                    ((t = vt),
                                    (e = []),
                                    u.test(l.charAt(vt))
                                      ? ((r = l.charAt(vt)), vt++)
                                      : ((r = s), 0 === xt && Lt(c)),
                                    r !== s)
                                  )
                                    for (; r !== s; )
                                      (e.push(r),
                                        u.test(l.charAt(vt))
                                          ? ((r = l.charAt(vt)), vt++)
                                          : ((r = s), 0 === xt && Lt(c)));
                                  else e = s;
                                  t = e !== s ? l.substring(t, vt) : e;
                                }
                                return t;
                              })()) !== s &&
                              It() !== s
                              ? ((n = vt),
                                44 === l.charCodeAt(vt)
                                  ? ((o = m), vt++)
                                  : ((o = s), 0 === xt && Lt(h)),
                                (n =
                                  o !== s &&
                                  (i = It()) !== s &&
                                  (a = (function () {
                                    var t;
                                    return (
                                      (t = (function () {
                                        var t, e, r, n, o, i;
                                        return (
                                          (t = vt),
                                          l.substr(vt, 6) === v
                                            ? ((e = v), (vt += 6))
                                            : ((e = s), 0 === xt && Lt(b)),
                                          e === s &&
                                            (l.substr(vt, 4) === w
                                              ? ((e = w), (vt += 4))
                                              : ((e = s), 0 === xt && Lt(F)),
                                            e === s &&
                                              (l.substr(vt, 4) === O
                                                ? ((e = O), (vt += 4))
                                                : ((e = s),
                                                  0 === xt && Lt(x)))),
                                          (t =
                                            e !== s
                                              ? It() !== s
                                                ? ((r = vt),
                                                  44 === l.charCodeAt(vt)
                                                    ? ((n = m), vt++)
                                                    : ((n = s),
                                                      0 === xt && Lt(h)),
                                                  (r =
                                                    n !== s &&
                                                    (o = It()) !== s &&
                                                    (i = zt()) !== s
                                                      ? (n = [n, o, i])
                                                      : ((vt = r), s)) === s &&
                                                    (r = null),
                                                  r !== s
                                                    ? ((bt = t), (e = D(e, r)))
                                                    : ((vt = t), s))
                                                : ((vt = t), s)
                                              : ((vt = t), s))
                                        );
                                      })()) === s &&
                                        (t = (function () {
                                          var t, e, r, n;
                                          return (
                                            (t = vt),
                                            l.substr(vt, 6) === _
                                              ? ((e = _), (vt += 6))
                                              : ((e = s), 0 === xt && Lt(A)),
                                            (t =
                                              e !== s
                                                ? It() !== s
                                                  ? (44 === l.charCodeAt(vt)
                                                      ? ((r = m), vt++)
                                                      : ((r = s),
                                                        0 === xt && Lt(h)),
                                                    r !== s &&
                                                    It() !== s &&
                                                    (n = kt()) !== s
                                                      ? ((bt = t), (e = L(n)))
                                                      : ((vt = t), s))
                                                  : ((vt = t), s)
                                                : ((vt = t), s))
                                          );
                                        })()) === s &&
                                        (t = (function () {
                                          var t, e, r, n;
                                          return (
                                            (t = vt),
                                            l.substr(vt, 13) === C
                                              ? ((e = C), (vt += 13))
                                              : ((e = s), 0 === xt && Lt(S)),
                                            (t =
                                              e !== s
                                                ? It() !== s
                                                  ? (44 === l.charCodeAt(vt)
                                                      ? ((r = m), vt++)
                                                      : ((r = s),
                                                        0 === xt && Lt(h)),
                                                    r !== s &&
                                                    It() !== s &&
                                                    (n = kt()) !== s
                                                      ? ((bt = t), (e = P(n)))
                                                      : ((vt = t), s))
                                                  : ((vt = t), s)
                                                : ((vt = t), s))
                                          );
                                        })()) === s &&
                                        (t = (function () {
                                          var t, e, r, n, o;
                                          if (
                                            ((t = vt),
                                            l.substr(vt, 6) === T
                                              ? ((e = T), (vt += 6))
                                              : ((e = s), 0 === xt && Lt(j)),
                                            e !== s)
                                          )
                                            if (It() !== s)
                                              if (
                                                (44 === l.charCodeAt(vt)
                                                  ? ((r = m), vt++)
                                                  : ((r = s),
                                                    0 === xt && Lt(h)),
                                                r !== s)
                                              )
                                                if (It() !== s) {
                                                  if (
                                                    ((n = []), (o = jt()) !== s)
                                                  )
                                                    for (; o !== s; )
                                                      (n.push(o), (o = jt()));
                                                  else n = s;
                                                  t =
                                                    n !== s
                                                      ? ((bt = t), (e = k(n)))
                                                      : ((vt = t), s);
                                                } else ((vt = t), (t = s));
                                              else ((vt = t), (t = s));
                                            else ((vt = t), (t = s));
                                          else ((vt = t), (t = s));
                                          return t;
                                        })()),
                                      t
                                    );
                                  })()) !== s
                                    ? (o = [o, i, a])
                                    : ((vt = n), s)) === s && (n = null),
                                n !== s && (o = It()) !== s
                                  ? (125 === l.charCodeAt(vt)
                                      ? ((i = d), vt++)
                                      : ((i = s), 0 === xt && Lt(y)),
                                    i !== s
                                      ? ((bt = t), (e = g(r, n)))
                                      : ((vt = t), s))
                                  : ((vt = t), s))
                              : ((vt = t), s)
                            : ((vt = t), s))
                      );
                    })()),
                  t
                );
              }
              function jt() {
                var t, e, r, n, o;
                return (
                  (t = vt),
                  (t =
                    It() !== s &&
                    (e = (function () {
                      var t, e, r, n;
                      return (
                        (e = t = vt),
                        61 === l.charCodeAt(vt)
                          ? ((r = E), vt++)
                          : ((r = s), 0 === xt && Lt(I)),
                        (t =
                          (e =
                            r !== s && (n = Nt()) !== s
                              ? (r = [r, n])
                              : ((vt = e), s)) !== s
                            ? l.substring(t, vt)
                            : e) === s && (t = zt()),
                        t
                      );
                    })()) !== s &&
                    It() !== s
                      ? (123 === l.charCodeAt(vt)
                          ? ((r = f), vt++)
                          : ((r = s), 0 === xt && Lt(p)),
                        r !== s && It() !== s && (n = Pt()) !== s && It() !== s
                          ? (125 === l.charCodeAt(vt)
                              ? ((o = d), vt++)
                              : ((o = s), 0 === xt && Lt(y)),
                            o !== s ? ((bt = t), R(e, n)) : ((vt = t), s))
                          : ((vt = t), s))
                      : ((vt = t), s))
                );
              }
              function kt() {
                var t, e, r, n;
                if (
                  ((t = vt),
                  (e = (function () {
                    var t, e, r;
                    return (
                      (t = vt),
                      l.substr(vt, 7) === M
                        ? ((e = M), (vt += 7))
                        : ((e = s), 0 === xt && Lt(N)),
                      (t =
                        e !== s && It() !== s && (r = Nt()) !== s
                          ? ((bt = t), (e = U(r)))
                          : ((vt = t), s))
                    );
                  })()) === s && (e = null),
                  e !== s)
                )
                  if (It() !== s) {
                    if (((r = []), (n = jt()) !== s))
                      for (; n !== s; ) (r.push(n), (n = jt()));
                    else r = s;
                    t = r !== s ? ((bt = t), (e = z(e, r))) : ((vt = t), s);
                  } else ((vt = t), (t = s));
                else ((vt = t), (t = s));
                return t;
              }
              function Et() {
                var t, e;
                if (
                  (xt++,
                  (t = []),
                  W.test(l.charAt(vt))
                    ? ((e = l.charAt(vt)), vt++)
                    : ((e = s), 0 === xt && Lt(Y)),
                  e !== s)
                )
                  for (; e !== s; )
                    (t.push(e),
                      W.test(l.charAt(vt))
                        ? ((e = l.charAt(vt)), vt++)
                        : ((e = s), 0 === xt && Lt(Y)));
                else t = s;
                return (xt--, t === s && ((e = s), 0 === xt && Lt(Z)), t);
              }
              function It() {
                var t, e, r;
                for (xt++, t = vt, e = [], r = Et(); r !== s; )
                  (e.push(r), (r = Et()));
                return (
                  (t = e !== s ? l.substring(t, vt) : e),
                  xt--,
                  t === s && ((e = s), 0 === xt && Lt(q)),
                  t
                );
              }
              function Rt() {
                var t;
                return (
                  B.test(l.charAt(vt))
                    ? ((t = l.charAt(vt)), vt++)
                    : ((t = s), 0 === xt && Lt(J)),
                  t
                );
              }
              function Mt() {
                var t;
                return (
                  $.test(l.charAt(vt))
                    ? ((t = l.charAt(vt)), vt++)
                    : ((t = s), 0 === xt && Lt(G)),
                  t
                );
              }
              function Nt() {
                var t, e, r, n, o, i;
                if (
                  ((t = vt),
                  48 === l.charCodeAt(vt)
                    ? ((e = H), vt++)
                    : ((e = s), 0 === xt && Lt(K)),
                  e === s)
                ) {
                  if (
                    ((r = e = vt),
                    Q.test(l.charAt(vt))
                      ? ((n = l.charAt(vt)), vt++)
                      : ((n = s), 0 === xt && Lt(V)),
                    n !== s)
                  ) {
                    for (o = [], i = Rt(); i !== s; ) (o.push(i), (i = Rt()));
                    r = o !== s ? (n = [n, o]) : ((vt = r), s);
                  } else ((vt = r), (r = s));
                  e = r !== s ? l.substring(e, vt) : r;
                }
                return (e !== s && ((bt = t), (e = X(e))), (t = e));
              }
              function Ut() {
                var t, e, r, n, o, i, a, u;
                return (
                  tt.test(l.charAt(vt))
                    ? ((t = l.charAt(vt)), vt++)
                    : ((t = s), 0 === xt && Lt(et)),
                  t === s &&
                    ((t = vt),
                    l.substr(vt, 2) === rt
                      ? ((e = rt), (vt += 2))
                      : ((e = s), 0 === xt && Lt(nt)),
                    e !== s && ((bt = t), (e = ot())),
                    (t = e) === s &&
                      ((t = vt),
                      l.substr(vt, 2) === it
                        ? ((e = it), (vt += 2))
                        : ((e = s), 0 === xt && Lt(at)),
                      e !== s && ((bt = t), (e = ut())),
                      (t = e) === s &&
                        ((t = vt),
                        l.substr(vt, 2) === lt
                          ? ((e = lt), (vt += 2))
                          : ((e = s), 0 === xt && Lt(st)),
                        e !== s && ((bt = t), (e = ct())),
                        (t = e) === s &&
                          ((t = vt),
                          l.substr(vt, 2) === ft
                            ? ((e = ft), (vt += 2))
                            : ((e = s), 0 === xt && Lt(pt)),
                          e !== s && ((bt = t), (e = mt())),
                          (t = e) === s &&
                            ((t = vt),
                            l.substr(vt, 2) === ht
                              ? ((e = ht), (vt += 2))
                              : ((e = s), 0 === xt && Lt(dt)),
                            (t =
                              e !== s
                                ? ((n = r = vt),
                                  (r =
                                    (n =
                                      (o = Mt()) !== s &&
                                      (i = Mt()) !== s &&
                                      (a = Mt()) !== s &&
                                      (u = Mt()) !== s
                                        ? (o = [o, i, a, u])
                                        : ((vt = n), s)) !== s
                                      ? l.substring(r, vt)
                                      : n) !== s
                                    ? ((bt = t), (e = yt(r)))
                                    : ((vt = t), s))
                                : ((vt = t), s))))))),
                  t
                );
              }
              function zt() {
                var t, e, r;
                if (((t = vt), (e = []), (r = Ut()) !== s))
                  for (; r !== s; ) (e.push(r), (r = Ut()));
                else e = s;
                return (e !== s && ((bt = t), (e = gt(e))), (t = e));
              }
              if ((t = n()) !== s && vt === l.length) return t;
              throw (
                t !== s &&
                  vt < l.length &&
                  Lt({ type: "end", description: "end of input" }),
                Ct(
                  null,
                  Ot,
                  Ft < l.length ? l.charAt(Ft) : null,
                  Ft < l.length ? At(Ft, Ft + 1) : At(Ft, Ft),
                )
              );
            },
          }),
        h = d;
      function d(t, e, r) {
        var n = "string" == typeof t ? d.__parse(t) : t;
        if (!n || "messageFormatPattern" !== n.type)
          throw new TypeError("A message must be provided as a String or AST.");
        ((r = this._mergeFormats(d.formats, r)),
          Object.defineProperty(this, "_locale", {
            value: this._resolveLocale(e),
          }));
        var o = this._findPluralRuleFunction(this._locale),
          i = this._compilePattern(n, e, r, o),
          a = this;
        this.format = function (t) {
          return a._format(i, t);
        };
      }
      (Object.defineProperty(d, "formats", {
        enumerable: !0,
        value: {
          number: {
            currency: { style: "currency" },
            percent: { style: "percent" },
          },
          date: {
            short: { month: "numeric", day: "numeric", year: "2-digit" },
            medium: { month: "short", day: "numeric", year: "numeric" },
            long: { month: "long", day: "numeric", year: "numeric" },
            full: {
              weekday: "long",
              month: "long",
              day: "numeric",
              year: "numeric",
            },
          },
          time: {
            short: { hour: "numeric", minute: "numeric" },
            medium: { hour: "numeric", minute: "numeric", second: "numeric" },
            long: {
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
              timeZoneName: "short",
            },
            full: {
              hour: "numeric",
              minute: "numeric",
              second: "numeric",
              timeZoneName: "short",
            },
          },
        },
      }),
        Object.defineProperty(d, "__localeData__", {
          value: Object.create(null),
        }),
        Object.defineProperty(d, "__addLocaleData", {
          value: function (t) {
            if (!t || !t.locale)
              throw new Error(
                "Locale data provided to IntlMessageFormat is missing a `locale` property",
              );
            d.__localeData__[t.locale.toLowerCase()] = t;
          },
        }),
        Object.defineProperty(d, "__parse", { value: m.parse }),
        Object.defineProperty(d, "defaultLocale", {
          enumerable: !0,
          writable: !0,
          value: void 0,
        }),
        (d.prototype.resolvedOptions = function () {
          return { locale: this._locale };
        }),
        (d.prototype._compilePattern = function (t, e, r, n) {
          return new i(e, r, n).compile(t);
        }),
        (d.prototype._findPluralRuleFunction = function (t) {
          for (var e = d.__localeData__, r = e[t.toLowerCase()]; r; ) {
            if (r.pluralRuleFunction) return r.pluralRuleFunction;
            r = r.parentLocale && e[r.parentLocale.toLowerCase()];
          }
          throw new Error(
            "Locale data added to IntlMessageFormat is missing a `pluralRuleFunction` for :" +
              t,
          );
        }),
        (d.prototype._format = function (t, e) {
          var r,
            n,
            o,
            i,
            a,
            u = "";
          for (r = 0, n = t.length; r < n; r += 1)
            if ("string" != typeof (o = t[r])) {
              if (
                ((i = o.id), !e || !Object.prototype.hasOwnProperty.call(e, i))
              )
                throw new Error("A value must be provided for: " + i);
              ((a = e[i]),
                o.options
                  ? (u += this._format(o.getOption(a), e))
                  : (u += o.format(a)));
            } else u += o;
          return u;
        }),
        (d.prototype._mergeFormats = function (t, e) {
          var r,
            n,
            o = {};
          for (r in t)
            Object.prototype.hasOwnProperty.call(t, r) &&
              ((o[r] = n = Object.create(t[r])),
              e &&
                Object.prototype.hasOwnProperty.call(e, r) &&
                Object.assign(n, e[r]));
          return o;
        }),
        (d.prototype._resolveLocale = function (t) {
          ("string" == typeof t && (t = [t]),
            (t = (t || []).concat(d.defaultLocale)));
          var e,
            r,
            n,
            o,
            i = d.__localeData__;
          for (e = 0, r = t.length; e < r; e += 1)
            for (n = t[e].toLowerCase().split("-"); n.length; ) {
              if ((o = i[n.join("-")])) return o.locale;
              n.pop();
            }
          var a = t.pop();
          throw new Error(
            "No locale data has been added to IntlMessageFormat for: " +
              t.join(", ") +
              ", or the default locale: " +
              a,
          );
        }));
      var y = {
        locale: "en",
        pluralRuleFunction: function (t, e) {
          var r = String(t).split("."),
            n = !r[1],
            o = Number(r[0]) == t,
            i = o && r[0].slice(-1),
            a = o && r[0].slice(-2);
          return e
            ? 1 == i && 11 != a
              ? "one"
              : 2 == i && 12 != a
                ? "two"
                : 3 == i && 13 != a
                  ? "few"
                  : "other"
            : 1 == t && n
              ? "one"
              : "other";
        },
      };
      function g(t, e) {
        return t < e ? -1 : e < t ? 1 : 0;
      }
      function v(r) {
        return void 0 !== Intl.Collator
          ? new Intl.Collator(r).compare
          : (function () {
                if (void 0 !== String.prototype.localeCompare)
                  try {
                    "foo".localeCompare("bar", "i");
                  } catch (t) {
                    return "RangeError" === t.name;
                  }
                return !1;
              })()
            ? function (t, e) {
                return t.localeCompare(e, r);
              }
            : g;
      }
      function b(t) {
        var e = F.indexOf(t) + 1;
        return !(!t || !e);
      }
      function w(t, e, r) {
        return b(t.locale) && r
          ? 0 <= O.indexOf(t.locale)
            ? e + " " + r
            : e + r
          : e;
      }
      var F = ["zh-cn", "zh-tw", "ko-kr", "ja-jp"],
        O = ["zh-tw"];
      function x() {
        return b(this.locale);
      }
      function D(t, e) {
        return w(this, t, e);
      }
      function _(t, e) {
        return (function (r, t, n) {
          var o =
            -1 < ["numeric", "2-digit", "narrow", "short", "long"].indexOf(t)
              ? t
              : "short";
          if (r.monthsList[o] && 0 < r.monthsList[o].length)
            return r.monthsList[o];
          var e = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(function (t) {
            return new Date(2017, t - 1);
          });
          return (
            (r.monthsList[o] = e.map(function (t, e) {
              return b(r.locale)
                ? { value: e + 1, name: w(r, e + 1, n) }
                : {
                    value: e + 1,
                    name: Intl.DateTimeFormat(r.locale, { month: o }).format(t),
                  };
            })),
            r.monthsList[o]
          );
        })(this, t, e);
      }
      function A(t, e) {
        for (var r = 0; r < e.length; r++) {
          var n = e[r];
          ((n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
            Object.defineProperty(t, n.key, n));
        }
      }
      var L = [
          { year: "numeric", month: "short", day: "numeric" },
          { hour: "numeric", minute: "numeric", hour12: !0 },
        ],
        C = {
          filteredOutPartType: "literal",
          defaultDelimiter: " | ",
          defaultDateOrder: { month: 0, day: 1, year: 2 },
          mockMonth: "8",
          mockDay: "17",
          mockYear: "2003",
          mockDate: new Date("Aug 17 2003"),
        },
        S = (function () {
          function e(t) {
            (!(function (t, e) {
              if (!(t instanceof e))
                throw new TypeError("Cannot call a class as a function");
            })(this, e),
              (this.locale = t),
              (this.dateOrdering = {}));
          }
          return (
            (function (t, e, r) {
              (e && A(t.prototype, e), r && A(t, r));
            })(e, [
              {
                key: "getShortDate",
                value: function (t) {
                  return this.getCustomDateTime(t);
                },
              },
              {
                key: "getFullDate",
                value: function (t, e) {
                  var r =
                    1 < arguments.length && void 0 !== e
                      ? e
                      : C.defaultDelimiter;
                  return (
                    this.getCustomDateTime(t, L[0]) +
                    r +
                    this.getCustomDateTime(t, L[1])
                  );
                },
              },
              {
                key: "getCustomDateTime",
                value: function (t, e) {
                  var r = 0 < arguments.length && void 0 !== t ? t : new Date(),
                    n = 1 < arguments.length ? e : void 0;
                  ("string" != typeof r && "number" != typeof r) ||
                    (r = new Date(r));
                  var o = new Intl.DateTimeFormat(this.locale, n);
                  try {
                    return o.format(r);
                  } catch (t) {
                    return "";
                  }
                },
              },
              {
                key: "getOrderedDateParts",
                value: function (t) {
                  var r = this;
                  if (0 === Object.keys(this.dateOrdering).length) {
                    var e = new Intl.DateTimeFormat(this.locale, t);
                    if (
                      ((this.dateOrdering = this.getDefaultDateOrdering()),
                      e.formatToParts)
                    ) {
                      var n = e.formatToParts(new Date()).filter(function (t) {
                        return t.type !== C.filteredOutPartType;
                      });
                      3 === n.length &&
                        n.forEach(function (t, e) {
                          r.dateOrdering[t.type] = e;
                        });
                    }
                  }
                  return this.dateOrdering;
                },
              },
              {
                key: "getDefaultDateOrdering",
                value: function () {
                  var r = C.defaultDateOrder,
                    t = this.getShortDate(C.mockDate),
                    e = [
                      { type: "year", index: t.indexOf(C.mockYear) },
                      { type: "month", index: t.indexOf(C.mockMonth) },
                      { type: "day", index: t.indexOf(C.mockDay) },
                    ];
                  return e.some(function (t) {
                    return -1 === t.index;
                  })
                    ? C.defaultDateOrder
                    : ((e = e.sort(function (t, e) {
                        return t.index - e.index;
                      })).forEach(function (t, e) {
                        r[t.type] = e;
                      }),
                      r);
                },
              },
            ]),
            e
          );
        })();
      function P(t) {
        return (P =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      (h.__addLocaleData(y), (h.defaultLocale = "en"));
      function T(t, e, r) {
        var n = "RobloxLocaleCode",
          o = !1;
        if (
          ("undefined" != typeof localStorage &&
            (o = u.LocalStorage
              ? u.LocalStorage.isAvailable()
              : localStorage && localStorage.getItem && localStorage.setItem),
          !t)
        ) {
          var i = document.querySelector('meta[name="locale-data"]');
          if (i && i.dataset && i.dataset.languageCode)
            t = i.dataset.languageCode;
          else if (i) {
            var a = i.getAttribute("data-language-code");
            a && (t = a);
          }
          (o && !t && (t = localStorage.getItem(n)),
            "zh_cjv" === t && (t = "zh_cn"),
            (t = (t = t || "en-us").replace(/_/g, "-")));
        }
        ((this.locale = t),
          (this.defaultLocale = [t]),
          (this.localeApiUrl = i && i.dataset && i.dataset.localeApiUrl),
          (this.timeZone = e || "America/Los_Angeles"),
          (this.currency = r || "USD"),
          (this.monthsList = {}),
          (this.weekdaysList = {}),
          o && localStorage.setItem(n, this.locale),
          (this.langSensitiveCompare = v(this.locale)),
          (this.isAsianLanguage = x),
          (this.getFormattedDateString = D),
          (this.getMonthsI18n = _),
          (this.getDateTimeFormatter = function () {
            return (function (t) {
              return new S(t);
            })(this.locale);
          }));
      }
      ((T.prototype.getLocale = function () {
        return this.locale;
      }),
        (T.prototype.getRobloxLocale = function () {
          return this.locale.replace(/-/g, "_");
        }),
        (T.prototype.getLocaleApiUrl = function () {
          return this.localeApiUrl;
        }),
        (T.prototype.getTimeZone = function () {
          return this.timeZone;
        }),
        (T.prototype.getCurrency = function () {
          return this.currency;
        }),
        (T.prototype.f = function (t, e, r) {
          if ("string" != typeof t)
            throw new TypeError("'message' must be a string");
          return new h(t, this.locale, r).format(e);
        }),
        (T.prototype.d = function (e, t) {
          if ("object" !== P(e) || !Date.prototype.isPrototypeOf(e))
            throw new TypeError("'dateObj' must be a JavaScript date object");
          var r,
            n = {
              short: { year: "numeric", month: "2-digit", day: "2-digit" },
              full: {
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
                hour: "2-digit",
                minute: "2-digit",
              },
              time: { hour: "2-digit", minute: "2-digit" },
            };
          if ("string" == typeof t || void 0 === t) r = n[t] || n.short;
          else {
            if ("object" !== P(t))
              throw new TypeError(
                "'options' must be either of type string or object based on Intl.DateTimeFormat",
              );
            r = t;
          }
          try {
            return new Intl.DateTimeFormat(this.defaultLocale, r).format(e);
          } catch (t) {
            return e.toLocaleString(this.defaultLocale);
          }
        }),
        (T.prototype.n = function (e, t) {
          if (isNaN(e))
            throw new TypeError("The argument 'number' must be of type number");
          var r,
            n = {
              currency: { style: "currency", currency: this.currency },
              percent: { style: "percent", maximumFractionDigits: 2 },
              decimal: { style: "decimal", maximumFractionDigits: 2 },
            };
          if ("string" == typeof t || void 0 === t) r = n[t] || n.decimal;
          else {
            if ("object" !== P(t))
              throw new TypeError(
                "'options' must be of type string or object based on Intl.NumberFormat",
              );
            r = t;
          }
          try {
            return new Intl.NumberFormat(this.defaultLocale, r).format(e);
          } catch (t) {
            return e;
          }
        }),
        (T.prototype.getMonthsList = function (t) {
          var r =
              -1 < ["numeric", "2-digit", "narrow", "short", "long"].indexOf(t)
                ? t
                : "short",
            n = this;
          if (this.monthsList[r] && 0 < this.monthsList[r].length)
            return this.monthsList[r];
          var e = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(function (t) {
            return new Date(2017, t - 1);
          });
          return (
            (this.monthsList[r] = e.map(function (t, e) {
              return {
                value: e + 1,
                name: Intl.DateTimeFormat(n.locale, { month: r }).format(t),
              };
            })),
            this.monthsList[r]
          );
        }),
        (T.prototype.getWeekdaysList = function (t) {
          var r = -1 < ["narrow", "short", "long"].indexOf(t) ? t : "short",
            n = this;
          if (this.weekdaysList[r] && 0 < this.weekdaysList[r].length)
            return this.weekdaysList[r];
          var e = [1, 2, 3, 4, 5, 6, 7].map(function (t) {
            return new Date(2017, 4, t);
          });
          return (
            (this.weekdaysList[r] = e.map(function (t, e) {
              return {
                value: e + 1,
                name: Intl.DateTimeFormat(n.locale, { weekday: r }).format(t),
              };
            })),
            this.weekdaysList[r]
          );
        }));
      e.a = T;
    },
  });
  //# sourceMappingURL=https://jsak.rbxcdn.com/81c6a2c891ea94a96d0b-internationalCore.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("InternationalCore");
}
