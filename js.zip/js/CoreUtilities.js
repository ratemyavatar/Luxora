var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (r) {
    var n = {};
    function o(e) {
      if (n[e]) return n[e].exports;
      var t = (n[e] = { i: e, l: !1, exports: {} });
      return (r[e].call(t.exports, t, t.exports, o), (t.l = !0), t.exports);
    }
    ((o.m = r),
      (o.c = n),
      (o.d = function (e, t, r) {
        o.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
      }),
      (o.r = function (e) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 }));
      }),
      (o.t = function (t, e) {
        if ((1 & e && (t = o(t)), 8 & e)) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (
          (o.r(r),
          Object.defineProperty(r, "default", { enumerable: !0, value: t }),
          2 & e && "string" != typeof t)
        )
          for (var n in t)
            o.d(
              r,
              n,
              function (e) {
                return t[e];
              }.bind(null, n),
            );
        return r;
      }),
      (o.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return (o.d(t, "a", t), t);
      }),
      (o.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (o.p = ""),
      o((o.s = 155)));
  })([
    function (e, t, r) {
      "use strict";
      function I(e) {
        return (I =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var R = r(44),
        q = r(46);
      function T() {
        ((this.protocol = null),
          (this.slashes = null),
          (this.auth = null),
          (this.host = null),
          (this.port = null),
          (this.hostname = null),
          (this.hash = null),
          (this.search = null),
          (this.query = null),
          (this.pathname = null),
          (this.path = null),
          (this.href = null));
      }
      ((t.parse = i),
        (t.resolve = function (e, t) {
          return i(e, !1, !0).resolve(t);
        }),
        (t.resolveObject = function (e, t) {
          return e ? i(e, !1, !0).resolveObject(t) : t;
        }),
        (t.format = function (e) {
          q.isString(e) && (e = i(e));
          return e instanceof T ? e.format() : T.prototype.format.call(e);
        }),
        (t.Url = T));
      var U = /^([a-z0-9.+-]+:)/i,
        n = /:[0-9]*$/,
        L = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,
        o = ["{", "}", "|", "\\", "^", "`"].concat([
          "<",
          ">",
          '"',
          "`",
          " ",
          "\r",
          "\n",
          "\t",
        ]),
        F = ["'"].concat(o),
        B = ["%", "/", "?", ";", "#"].concat(F),
        M = ["/", "?", "#"],
        D = /^[+a-z0-9A-Z_-]{0,63}$/,
        z = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
        Q = { javascript: !0, "javascript:": !0 },
        H = { javascript: !0, "javascript:": !0 },
        K = {
          http: !0,
          https: !0,
          ftp: !0,
          gopher: !0,
          file: !0,
          "http:": !0,
          "https:": !0,
          "ftp:": !0,
          "gopher:": !0,
          "file:": !0,
        },
        $ = r(47);
      function i(e, t, r) {
        if (e && q.isObject(e) && e instanceof T) return e;
        var n = new T();
        return (n.parse(e, t, r), n);
      }
      ((T.prototype.parse = function (e, t, r) {
        if (!q.isString(e))
          throw new TypeError("Parameter 'url' must be a string, not " + I(e));
        var n = e.indexOf("?"),
          o = -1 !== n && n < e.indexOf("#") ? "?" : "#",
          i = e.split(o);
        i[0] = i[0].replace(/\\/g, "/");
        var a = (e = i.join(o));
        if (((a = a.trim()), !r && 1 === e.split("#").length)) {
          var s = L.exec(a);
          if (s)
            return (
              (this.path = a),
              (this.href = a),
              (this.pathname = s[1]),
              s[2]
                ? ((this.search = s[2]),
                  (this.query = t
                    ? $.parse(this.search.substr(1))
                    : this.search.substr(1)))
                : t && ((this.search = ""), (this.query = {})),
              this
            );
        }
        var u = U.exec(a);
        if (u) {
          var c = (u = u[0]).toLowerCase();
          ((this.protocol = c), (a = a.substr(u.length)));
        }
        if (r || u || a.match(/^\/\/[^@\/]+@[^@\/]+/)) {
          var f = "//" === a.substr(0, 2);
          !f || (u && H[u]) || ((a = a.substr(2)), (this.slashes = !0));
        }
        if (!H[u] && (f || (u && !K[u]))) {
          for (var h, l, p = -1, d = 0; d < M.length; d++) {
            -1 !== (m = a.indexOf(M[d])) && (-1 === p || m < p) && (p = m);
          }
          (-1 !== (l = -1 === p ? a.lastIndexOf("@") : a.lastIndexOf("@", p)) &&
            ((h = a.slice(0, l)),
            (a = a.slice(l + 1)),
            (this.auth = decodeURIComponent(h))),
            (p = -1));
          for (d = 0; d < B.length; d++) {
            var m;
            -1 !== (m = a.indexOf(B[d])) && (-1 === p || m < p) && (p = m);
          }
          (-1 === p && (p = a.length),
            (this.host = a.slice(0, p)),
            (a = a.slice(p)),
            this.parseHost(),
            (this.hostname = this.hostname || ""));
          var y =
            "[" === this.hostname[0] &&
            "]" === this.hostname[this.hostname.length - 1];
          if (!y)
            for (
              var g = this.hostname.split(/\./), v = ((d = 0), g.length);
              d < v;
              d++
            ) {
              var b = g[d];
              if (b && !b.match(D)) {
                for (var w = "", P = 0, x = b.length; P < x; P++)
                  127 < b.charCodeAt(P) ? (w += "x") : (w += b[P]);
                if (!w.match(D)) {
                  var C = g.slice(0, d),
                    S = g.slice(d + 1),
                    j = b.match(z);
                  (j && (C.push(j[1]), S.unshift(j[2])),
                    S.length && (a = "/" + S.join(".") + a),
                    (this.hostname = C.join(".")));
                  break;
                }
              }
            }
          (255 < this.hostname.length
            ? (this.hostname = "")
            : (this.hostname = this.hostname.toLowerCase()),
            y || (this.hostname = R.toASCII(this.hostname)));
          var O = this.port ? ":" + this.port : "",
            T = this.hostname || "";
          ((this.host = T + O),
            (this.href += this.host),
            y &&
              ((this.hostname = this.hostname.substr(
                1,
                this.hostname.length - 2,
              )),
              "/" !== a[0] && (a = "/" + a)));
        }
        if (!Q[c])
          for (d = 0, v = F.length; d < v; d++) {
            var A = F[d];
            if (-1 !== a.indexOf(A)) {
              var E = encodeURIComponent(A);
              (E === A && (E = escape(A)), (a = a.split(A).join(E)));
            }
          }
        var _ = a.indexOf("#");
        -1 !== _ && ((this.hash = a.substr(_)), (a = a.slice(0, _)));
        var N = a.indexOf("?");
        if (
          (-1 !== N
            ? ((this.search = a.substr(N)),
              (this.query = a.substr(N + 1)),
              t && (this.query = $.parse(this.query)),
              (a = a.slice(0, N)))
            : t && ((this.search = ""), (this.query = {})),
          a && (this.pathname = a),
          K[c] && this.hostname && !this.pathname && (this.pathname = "/"),
          this.pathname || this.search)
        ) {
          O = this.pathname || "";
          var k = this.search || "";
          this.path = O + k;
        }
        return ((this.href = this.format()), this);
      }),
        (T.prototype.format = function () {
          var e = this.auth || "";
          e &&
            ((e = (e = encodeURIComponent(e)).replace(/%3A/i, ":")),
            (e += "@"));
          var t = this.protocol || "",
            r = this.pathname || "",
            n = this.hash || "",
            o = !1,
            i = "";
          (this.host
            ? (o = e + this.host)
            : this.hostname &&
              ((o =
                e +
                (-1 === this.hostname.indexOf(":")
                  ? this.hostname
                  : "[" + this.hostname + "]")),
              this.port && (o += ":" + this.port)),
            this.query &&
              q.isObject(this.query) &&
              Object.keys(this.query).length &&
              (i = $.stringify(this.query)));
          var a = this.search || (i && "?" + i) || "";
          return (
            t && ":" !== t.substr(-1) && (t += ":"),
            this.slashes || ((!t || K[t]) && !1 !== o)
              ? ((o = "//" + (o || "")),
                r && "/" !== r.charAt(0) && (r = "/" + r))
              : (o = o || ""),
            n && "#" !== n.charAt(0) && (n = "#" + n),
            a && "?" !== a.charAt(0) && (a = "?" + a),
            t +
              o +
              (r = r.replace(/[?#]/g, function (e) {
                return encodeURIComponent(e);
              })) +
              (a = a.replace("#", "%23")) +
              n
          );
        }),
        (T.prototype.resolve = function (e) {
          return this.resolveObject(i(e, !1, !0)).format();
        }),
        (T.prototype.resolveObject = function (e) {
          if (q.isString(e)) {
            var t = new T();
            (t.parse(e, !1, !0), (e = t));
          }
          for (
            var r = new T(), n = Object.keys(this), o = 0;
            o < n.length;
            o++
          ) {
            var i = n[o];
            r[i] = this[i];
          }
          if (((r.hash = e.hash), "" === e.href))
            return ((r.href = r.format()), r);
          if (e.slashes && !e.protocol) {
            for (var a = Object.keys(e), s = 0; s < a.length; s++) {
              var u = a[s];
              "protocol" !== u && (r[u] = e[u]);
            }
            return (
              K[r.protocol] &&
                r.hostname &&
                !r.pathname &&
                (r.path = r.pathname = "/"),
              (r.href = r.format()),
              r
            );
          }
          if (e.protocol && e.protocol !== r.protocol) {
            if (!K[e.protocol]) {
              for (var c = Object.keys(e), f = 0; f < c.length; f++) {
                var h = c[f];
                r[h] = e[h];
              }
              return ((r.href = r.format()), r);
            }
            if (((r.protocol = e.protocol), e.host || H[e.protocol]))
              r.pathname = e.pathname;
            else {
              for (
                var l = (e.pathname || "").split("/");
                l.length && !(e.host = l.shift());
              );
              (e.host || (e.host = ""),
                e.hostname || (e.hostname = ""),
                "" !== l[0] && l.unshift(""),
                l.length < 2 && l.unshift(""),
                (r.pathname = l.join("/")));
            }
            if (
              ((r.search = e.search),
              (r.query = e.query),
              (r.host = e.host || ""),
              (r.auth = e.auth),
              (r.hostname = e.hostname || e.host),
              (r.port = e.port),
              r.pathname || r.search)
            ) {
              var p = r.pathname || "",
                d = r.search || "";
              r.path = p + d;
            }
            return (
              (r.slashes = r.slashes || e.slashes),
              (r.href = r.format()),
              r
            );
          }
          var m = r.pathname && "/" === r.pathname.charAt(0),
            y = e.host || (e.pathname && "/" === e.pathname.charAt(0)),
            g = y || m || (r.host && e.pathname),
            v = g,
            b = (r.pathname && r.pathname.split("/")) || [],
            w =
              ((l = (e.pathname && e.pathname.split("/")) || []),
              r.protocol && !K[r.protocol]);
          if (
            (w &&
              ((r.hostname = ""),
              (r.port = null),
              r.host && ("" === b[0] ? (b[0] = r.host) : b.unshift(r.host)),
              (r.host = ""),
              e.protocol &&
                ((e.hostname = null),
                (e.port = null),
                e.host && ("" === l[0] ? (l[0] = e.host) : l.unshift(e.host)),
                (e.host = null)),
              (g = g && ("" === l[0] || "" === b[0]))),
            y)
          )
            ((r.host = e.host || "" === e.host ? e.host : r.host),
              (r.hostname =
                e.hostname || "" === e.hostname ? e.hostname : r.hostname),
              (r.search = e.search),
              (r.query = e.query),
              (b = l));
          else if (l.length)
            ((b = b || []).pop(),
              (b = b.concat(l)),
              (r.search = e.search),
              (r.query = e.query));
          else if (!q.isNullOrUndefined(e.search)) {
            if (w)
              ((r.hostname = r.host = b.shift()),
                (j =
                  !!(r.host && 0 < r.host.indexOf("@")) && r.host.split("@")) &&
                  ((r.auth = j.shift()), (r.host = r.hostname = j.shift())));
            return (
              (r.search = e.search),
              (r.query = e.query),
              (q.isNull(r.pathname) && q.isNull(r.search)) ||
                (r.path =
                  (r.pathname ? r.pathname : "") + (r.search ? r.search : "")),
              (r.href = r.format()),
              r
            );
          }
          if (!b.length)
            return (
              (r.pathname = null),
              r.search ? (r.path = "/" + r.search) : (r.path = null),
              (r.href = r.format()),
              r
            );
          for (
            var P = b.slice(-1)[0],
              x =
                ((r.host || e.host || 1 < b.length) &&
                  ("." === P || ".." === P)) ||
                "" === P,
              C = 0,
              S = b.length;
            0 <= S;
            S--
          )
            "." === (P = b[S])
              ? b.splice(S, 1)
              : ".." === P
                ? (b.splice(S, 1), C++)
                : C && (b.splice(S, 1), C--);
          if (!g && !v) for (; C--; ) b.unshift("..");
          (!g ||
            "" === b[0] ||
            (b[0] && "/" === b[0].charAt(0)) ||
            b.unshift(""),
            x && "/" !== b.join("/").substr(-1) && b.push(""));
          var j,
            O = "" === b[0] || (b[0] && "/" === b[0].charAt(0));
          w &&
            ((r.hostname = r.host = O ? "" : b.length ? b.shift() : ""),
            (j = !!(r.host && 0 < r.host.indexOf("@")) && r.host.split("@")) &&
              ((r.auth = j.shift()), (r.host = r.hostname = j.shift())));
          return (
            (g = g || (r.host && b.length)) && !O && b.unshift(""),
            b.length
              ? (r.pathname = b.join("/"))
              : ((r.pathname = null), (r.path = null)),
            (q.isNull(r.pathname) && q.isNull(r.search)) ||
              (r.path =
                (r.pathname ? r.pathname : "") + (r.search ? r.search : "")),
            (r.auth = e.auth || r.auth),
            (r.slashes = r.slashes || e.slashes),
            (r.href = r.format()),
            r
          );
        }),
        (T.prototype.parseHost = function () {
          var e = this.host,
            t = n.exec(e);
          (t &&
            (":" !== (t = t[0]) && (this.port = t.substr(1)),
            (e = e.substr(0, e.length - t.length))),
            e && (this.hostname = e));
        }));
    },
    function (e, t, r) {
      "use strict";
      var n,
        o,
        i = r(8),
        a = r.n(i),
        s = r(3);
      (((o = n = n || {})[(o.ok = 200)] = "ok"),
        (o[(o.accepted = 202)] = "accepted"),
        (o[(o.movedPermanently = 301)] = "movedPermanently"),
        (o[(o.badRequest = 400)] = "badRequest"),
        (o[(o.unauthorized = 401)] = "unauthorized"),
        (o[(o.forbidden = 403)] = "forbidden"),
        (o[(o.notFound = 404)] = "notFound"),
        (o[(o.methodNotAllowed = 405)] = "methodNotAllowed"),
        (o[(o.conflict = 409)] = "conflict"),
        (o[(o.payloadTooLarge = 413)] = "payloadTooLarge"),
        (o[(o.tooManyAttempts = 429)] = "tooManyAttempts"),
        (o[(o.serverError = 500)] = "serverError"),
        (o[(o.serviceUnavailable = 503)] = "serviceUnavailable"));
      var u,
        c,
        f = Object.freeze(n);
      (((c = u = u || {}).GET = "get"),
        (c.HEAD = "head"),
        (c.POST = "post"),
        (c.PUT = "put"),
        (c.DELETE = "delete"),
        (c.OPTIONS = "options"),
        (c.PATCH = "patch"));
      var h = Object.freeze(u),
        l = function () {
          return (l =
            Object.assign ||
            function (e) {
              for (var t, r = 1, n = arguments.length; r < n; r++)
                for (var o in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
              return e;
            }).apply(this, arguments);
        },
        p = "x-csrf-token",
        d = f.forbidden,
        m = s.XsrfToken.getToken();
      (a.a.interceptors.request.use(function (e) {
        var t = e.method,
          r = e.noCache,
          n = e.headers,
          o = l({}, e);
        return (
          (t !== h.POST && t !== h.PATCH && t !== h.DELETE) ||
            ((m = m || s.XsrfToken.getToken()),
            r &&
              ((o.headers = n || {}),
              (o["Cache-Control"] = "no-cache, no-store, must-revalidate"),
              (o.Pragma = "no-cache"),
              (o.Expires = 0)),
            (o.headers[p] = m)),
          o
        );
      }, null),
        a.a.interceptors.response.use(null, function (e) {
          var t = e.response;
          if (t) {
            var r = t.status,
              n = t.headers,
              o = t.config,
              i = n[p];
            if (r === d && i)
              return (
                (o.headers[p] = i),
                (m = i),
                s.XsrfToken.setToken(i),
                a.a.request(o)
              );
          }
          return Promise.reject(t);
        }));
      var y = a.a,
        g = function () {
          return (g =
            Object.assign ||
            function (e) {
              for (var t, r = 1, n = arguments.length; r < n; r++)
                for (var o in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
              return e;
            }).apply(this, arguments);
        };
      function v(e, t) {
        return (
          t || Promise.reject(new Error("No config found")),
          y(
            (function (e, t) {
              var r = g({}, e);
              return (
                t.withCredentials && (r.withCredentials = t.withCredentials),
                t.retryable && (r.retryable = t.retryable),
                t.noCache &&
                  (r.headers = {
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    Pragma: "no-cache",
                    Expires: 0,
                  }),
                t.headers && (r.headers = g(g({}, r.headers), t.headers)),
                r
              );
            })(e, t),
          )
        );
      }
      function b(e, t) {
        return v({ method: h.GET, url: e.url, params: t }, e);
      }
      function w(e, t) {
        return v({ method: h.POST, url: e.url, data: t }, e);
      }
      var P = {
        methods: h,
        get: b,
        post: w,
        delete: function (e) {
          return v({ method: h.DELETE, url: e.url }, e);
        },
        patch: function (e, t) {
          return v({ method: h.PATCH, url: e.url, data: t }, e);
        },
        buildBatchPromises: function (e, t, r, n, o) {
          for (
            var i = [], a = 0, s = e.slice(a, t), u = o || "userIds";
            0 < s.length;
          ) {
            var c = {};
            ((c[u] = s),
              n ? i.push(w(r, c)) : i.push(b(r, c)),
              (a += 1),
              (s = e.slice(a * t, a * t + t)));
          }
          return Promise.all(i);
        },
      };
      (r.d(t, "a", function () {
        return y;
      }),
        r.d(t, "d", function () {
          return P;
        }),
        r.d(t, "c", function () {
          return f;
        }),
        r.d(t, "b", function () {
          return h;
        }));
    },
    ,
    function (e, t) {
      e.exports = Roblox;
    },
    ,
    function (e, t, r) {
      "use strict";
      function i(e) {
        return (i =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var o = r(17),
        n = r(27),
        a = Object.prototype.toString;
      function s(e) {
        return "[object Array]" === a.call(e);
      }
      function u(e) {
        return null !== e && "object" === i(e);
      }
      function c(e) {
        return "[object Function]" === a.call(e);
      }
      function f(e, t) {
        if (null != e)
          if (("object" !== i(e) && (e = [e]), s(e)))
            for (var r = 0, n = e.length; r < n; r++) t.call(null, e[r], r, e);
          else
            for (var o in e)
              Object.prototype.hasOwnProperty.call(e, o) &&
                t.call(null, e[o], o, e);
      }
      e.exports = {
        isArray: s,
        isArrayBuffer: function (e) {
          return "[object ArrayBuffer]" === a.call(e);
        },
        isBuffer: n,
        isFormData: function (e) {
          return "undefined" != typeof FormData && e instanceof FormData;
        },
        isArrayBufferView: function (e) {
          return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView
            ? ArrayBuffer.isView(e)
            : e && e.buffer && e.buffer instanceof ArrayBuffer;
        },
        isString: function (e) {
          return "string" == typeof e;
        },
        isNumber: function (e) {
          return "number" == typeof e;
        },
        isObject: u,
        isUndefined: function (e) {
          return void 0 === e;
        },
        isDate: function (e) {
          return "[object Date]" === a.call(e);
        },
        isFile: function (e) {
          return "[object File]" === a.call(e);
        },
        isBlob: function (e) {
          return "[object Blob]" === a.call(e);
        },
        isFunction: c,
        isStream: function (e) {
          return u(e) && c(e.pipe);
        },
        isURLSearchParams: function (e) {
          return (
            "undefined" != typeof URLSearchParams &&
            e instanceof URLSearchParams
          );
        },
        isStandardBrowserEnv: function () {
          return (
            ("undefined" == typeof navigator ||
              "ReactNative" !== navigator.product) &&
            "undefined" != typeof window &&
            "undefined" != typeof document
          );
        },
        forEach: f,
        merge: function r() {
          var n = {};
          function e(e, t) {
            "object" === i(n[t]) && "object" === i(e)
              ? (n[t] = r(n[t], e))
              : (n[t] = e);
          }
          for (var t = 0, o = arguments.length; t < o; t++) f(arguments[t], e);
          return n;
        },
        extend: function (r, e, n) {
          return (
            f(e, function (e, t) {
              r[t] = n && "function" == typeof e ? o(e, n) : e;
            }),
            r
          );
        },
        trim: function (e) {
          return e.replace(/^\s*/, "").replace(/\s*$/, "");
        },
      };
    },
    ,
    ,
    function (e, t, r) {
      e.exports = r(26);
    },
    function (e, t, r) {
      "use strict";
      function p(e, t) {
        return (
          (function (e) {
            if (Array.isArray(e)) return e;
          })(e) ||
          (function (e, t) {
            var r = [],
              n = !0,
              o = !1,
              i = void 0;
            try {
              for (
                var a, s = e[Symbol.iterator]();
                !(n = (a = s.next()).done) &&
                (r.push(a.value), !t || r.length !== t);
                n = !0
              );
            } catch (e) {
              ((o = !0), (i = e));
            } finally {
              try {
                n || null == s.return || s.return();
              } finally {
                if (o) throw i;
              }
            }
            return r;
          })(e, t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to destructure non-iterable instance",
            );
          })()
        );
      }
      function d(e) {
        return (d =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      function i(e) {
        return (
          (function (e) {
            if (Array.isArray(e)) {
              for (var t = 0, r = new Array(e.length); t < e.length; t++)
                r[t] = e[t];
              return r;
            }
          })(e) ||
          (function (e) {
            if (
              Symbol.iterator in Object(e) ||
              "[object Arguments]" === Object.prototype.toString.call(e)
            )
              return Array.from(e);
          })(e) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to spread non-iterable instance",
            );
          })()
        );
      }
      var n = r(50),
        o = r(51),
        m = r(52);
      function a(e, t) {
        return t.encode ? (t.strict ? n(e) : encodeURIComponent(e)) : e;
      }
      function y(e, t) {
        return t.decode ? o(e) : e;
      }
      function s(e) {
        var t = e.indexOf("#");
        return (-1 !== t && (e = e.slice(0, t)), e);
      }
      function u(e) {
        var t = (e = s(e)).indexOf("?");
        return -1 === t ? "" : e.slice(t + 1);
      }
      function c(e, t) {
        var r = (function (e) {
            var n;
            switch (e.arrayFormat) {
              case "index":
                return function (e, t, r) {
                  ((n = /\[(\d*)\]$/.exec(e)),
                    (e = e.replace(/\[\d*\]$/, "")),
                    n
                      ? (void 0 === r[e] && (r[e] = {}), (r[e][n[1]] = t))
                      : (r[e] = t));
                };
              case "bracket":
                return function (e, t, r) {
                  ((n = /(\[\])$/.exec(e)),
                    (e = e.replace(/\[\]$/, "")),
                    n
                      ? void 0 !== r[e]
                        ? (r[e] = [].concat(r[e], t))
                        : (r[e] = [t])
                      : (r[e] = t));
                };
              case "comma":
                return function (e, t, r) {
                  var n =
                    "string" == typeof t && -1 < t.split("").indexOf(",")
                      ? t.split(",")
                      : t;
                  r[e] = n;
                };
              default:
                return function (e, t, r) {
                  void 0 !== r[e] ? (r[e] = [].concat(r[e], t)) : (r[e] = t);
                };
            }
          })(
            (t = Object.assign(
              { decode: !0, sort: !0, arrayFormat: "none", parseNumbers: !1 },
              t,
            )),
          ),
          n = Object.create(null);
        if ("string" != typeof e) return n;
        if (!(e = e.trim().replace(/^[?#&]/, ""))) return n;
        var o = !0,
          i = !1,
          a = void 0;
        try {
          for (
            var s, u = e.split("&")[Symbol.iterator]();
            !(o = (s = u.next()).done);
            o = !0
          ) {
            var c = s.value,
              f = p(m(c.replace(/\+/g, " "), "="), 2),
              h = f[0],
              l = f[1];
            ((l = void 0 === l ? null : y(l, t)),
              t.parseNumbers && !Number.isNaN(Number(l)) && (l = Number(l)),
              r(y(h, t), l, n));
          }
        } catch (e) {
          ((i = !0), (a = e));
        } finally {
          try {
            o || null == u.return || u.return();
          } finally {
            if (i) throw a;
          }
        }
        return !1 === t.sort
          ? n
          : (!0 === t.sort
              ? Object.keys(n).sort()
              : Object.keys(n).sort(t.sort)
            ).reduce(function (e, t) {
              var r = n[t];
              return (
                Boolean(r) && "object" === d(r) && !Array.isArray(r)
                  ? (e[t] = (function e(t) {
                      return Array.isArray(t)
                        ? t.sort()
                        : "object" === d(t)
                          ? e(Object.keys(t))
                              .sort(function (e, t) {
                                return Number(e) - Number(t);
                              })
                              .map(function (e) {
                                return t[e];
                              })
                          : t;
                    })(r))
                  : (e[t] = r),
                e
              );
            }, Object.create(null));
      }
      ((t.extract = u),
        (t.parse = c),
        (t.stringify = function (r, n) {
          if (!r) return "";
          var o = (function (o) {
              switch (o.arrayFormat) {
                case "index":
                  return function (n) {
                    return function (e, t) {
                      var r = e.length;
                      return void 0 === t
                        ? e
                        : [].concat(
                            i(e),
                            null === t
                              ? [[a(n, o), "[", r, "]"].join("")]
                              : [
                                  [a(n, o), "[", a(r, o), "]=", a(t, o)].join(
                                    "",
                                  ),
                                ],
                          );
                    };
                  };
                case "bracket":
                  return function (r) {
                    return function (e, t) {
                      return void 0 === t
                        ? e
                        : [].concat(
                            i(e),
                            null === t
                              ? [[a(r, o), "[]"].join("")]
                              : [[a(r, o), "[]=", a(t, o)].join("")],
                          );
                    };
                  };
                case "comma":
                  return function (n) {
                    return function (e, t, r) {
                      return null == t || 0 === t.length
                        ? e
                        : 0 === r
                          ? [[a(n, o), "=", a(t, o)].join("")]
                          : [[e, a(t, o)].join(",")];
                    };
                  };
                default:
                  return function (r) {
                    return function (e, t) {
                      return void 0 === t
                        ? e
                        : [].concat(
                            i(e),
                            null === t
                              ? [a(r, o)]
                              : [[a(r, o), "=", a(t, o)].join("")],
                          );
                    };
                  };
              }
            })(
              (n = Object.assign(
                { encode: !0, strict: !0, arrayFormat: "none" },
                n,
              )),
            ),
            e = Object.keys(r);
          return (
            !1 !== n.sort && e.sort(n.sort),
            e
              .map(function (e) {
                var t = r[e];
                return void 0 === t
                  ? ""
                  : null === t
                    ? a(e, n)
                    : Array.isArray(t)
                      ? t.reduce(o(e), []).join("&")
                      : a(e, n) + "=" + a(t, n);
              })
              .filter(function (e) {
                return 0 < e.length;
              })
              .join("&")
          );
        }),
        (t.parseUrl = function (e, t) {
          return { url: s(e).split("?")[0] || "", query: c(u(e), t) };
        }));
    },
    function (e, t, r) {
      "use strict";
      function n(e) {
        var t =
          0 < arguments.length && void 0 !== e ? e : window.location.search;
        return c.a.parse(t);
      }
      function o(e) {
        var t = 0 < arguments.length && void 0 !== e ? e : {};
        return c.a.stringify(t);
      }
      function i(e) {
        return f.Endpoints ? f.Endpoints.getAbsoluteUrl(e) : e;
      }
      var a = r(0),
        s = r.n(a),
        u = r(9),
        c = r.n(u),
        f = r(3);
      t.a = {
        parseQueryString: n,
        composeQueryString: o,
        getQueryParam: function (e) {
          return n()[e];
        },
        formatUrl: s.a.format,
        resolveUrl: s.a.resolve,
        parseUrl: s.a.parse,
        parseUrlAndQueryString: c.a.parseUrl,
        extractQueryString: c.a.extract,
        getGameDetailReferralUrls: function (e) {
          return i("/games/refer?".concat(o(e)));
        },
        getUrlWithQueries: function (e, t) {
          return i("".concat(e, "?").concat(o(t)));
        },
      };
    },
    function (t, e) {
      (function (e) {
        t.exports = e;
      }).call(this, {});
    },
    function (s, e, u) {
      "use strict";
      (function (e) {
        var r = u(5),
          n = u(30),
          t = { "Content-Type": "application/x-www-form-urlencoded" };
        function o(e, t) {
          !r.isUndefined(e) &&
            r.isUndefined(e["Content-Type"]) &&
            (e["Content-Type"] = t);
        }
        var i,
          a = {
            adapter:
              ("undefined" != typeof XMLHttpRequest
                ? (i = u(18))
                : void 0 !== e && (i = u(18)),
              i),
            transformRequest: [
              function (e, t) {
                return (
                  n(t, "Content-Type"),
                  r.isFormData(e) ||
                  r.isArrayBuffer(e) ||
                  r.isBuffer(e) ||
                  r.isStream(e) ||
                  r.isFile(e) ||
                  r.isBlob(e)
                    ? e
                    : r.isArrayBufferView(e)
                      ? e.buffer
                      : r.isURLSearchParams(e)
                        ? (o(
                            t,
                            "application/x-www-form-urlencoded;charset=utf-8",
                          ),
                          e.toString())
                        : r.isObject(e)
                          ? (o(t, "application/json;charset=utf-8"),
                            JSON.stringify(e))
                          : e
                );
              },
            ],
            transformResponse: [
              function (e) {
                if ("string" == typeof e)
                  try {
                    e = JSON.parse(e);
                  } catch (e) {}
                return e;
              },
            ],
            timeout: 0,
            xsrfCookieName: "XSRF-TOKEN",
            xsrfHeaderName: "X-XSRF-TOKEN",
            maxContentLength: -1,
            validateStatus: function (e) {
              return 200 <= e && e < 300;
            },
          };
        ((a.headers = {
          common: { Accept: "application/json, text/plain, */*" },
        }),
          r.forEach(["delete", "get", "head"], function (e) {
            a.headers[e] = {};
          }),
          r.forEach(["post", "put", "patch"], function (e) {
            a.headers[e] = r.merge(t);
          }),
          (s.exports = a));
      }).call(this, u(29));
    },
    ,
    function (e, t) {
      function r(e) {
        return (r =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var n;
      n = (function () {
        return this;
      })();
      try {
        n = n || new Function("return this")();
      } catch (e) {
        "object" === ("undefined" == typeof window ? "undefined" : r(window)) &&
          (n = window);
      }
      e.exports = n;
    },
    ,
    ,
    function (e, t, r) {
      "use strict";
      e.exports = function (r, n) {
        return function () {
          for (var e = new Array(arguments.length), t = 0; t < e.length; t++)
            e[t] = arguments[t];
          return r.apply(n, e);
        };
      };
    },
    function (e, t, f) {
      "use strict";
      var h = f(5),
        l = f(31),
        p = f(33),
        d = f(34),
        m = f(35),
        y = f(19);
      e.exports = function (c) {
        return new Promise(function (r, n) {
          var o = c.data,
            i = c.headers;
          h.isFormData(o) && delete i["Content-Type"];
          var a = new XMLHttpRequest();
          if (c.auth) {
            var e = c.auth.username || "",
              t = c.auth.password || "";
            i.Authorization = "Basic " + btoa(e + ":" + t);
          }
          if (
            (a.open(
              c.method.toUpperCase(),
              p(c.url, c.params, c.paramsSerializer),
              !0,
            ),
            (a.timeout = c.timeout),
            (a.onreadystatechange = function () {
              if (
                a &&
                4 === a.readyState &&
                (0 !== a.status ||
                  (a.responseURL && 0 === a.responseURL.indexOf("file:")))
              ) {
                var e =
                    "getAllResponseHeaders" in a
                      ? d(a.getAllResponseHeaders())
                      : null,
                  t = {
                    data:
                      c.responseType && "text" !== c.responseType
                        ? a.response
                        : a.responseText,
                    status: a.status,
                    statusText: a.statusText,
                    headers: e,
                    config: c,
                    request: a,
                  };
                (l(r, n, t), (a = null));
              }
            }),
            (a.onerror = function () {
              (n(y("Network Error", c, null, a)), (a = null));
            }),
            (a.ontimeout = function () {
              (n(
                y(
                  "timeout of " + c.timeout + "ms exceeded",
                  c,
                  "ECONNABORTED",
                  a,
                ),
              ),
                (a = null));
            }),
            h.isStandardBrowserEnv())
          ) {
            var s = f(36),
              u =
                (c.withCredentials || m(c.url)) && c.xsrfCookieName
                  ? s.read(c.xsrfCookieName)
                  : void 0;
            u && (i[c.xsrfHeaderName] = u);
          }
          if (
            ("setRequestHeader" in a &&
              h.forEach(i, function (e, t) {
                void 0 === o && "content-type" === t.toLowerCase()
                  ? delete i[t]
                  : a.setRequestHeader(t, e);
              }),
            c.withCredentials && (a.withCredentials = !0),
            c.responseType)
          )
            try {
              a.responseType = c.responseType;
            } catch (e) {
              if ("json" !== c.responseType) throw e;
            }
          ("function" == typeof c.onDownloadProgress &&
            a.addEventListener("progress", c.onDownloadProgress),
            "function" == typeof c.onUploadProgress &&
              a.upload &&
              a.upload.addEventListener("progress", c.onUploadProgress),
            c.cancelToken &&
              c.cancelToken.promise.then(function (e) {
                a && (a.abort(), n(e), (a = null));
              }),
            void 0 === o && (o = null),
            a.send(o));
        });
      };
    },
    function (e, t, r) {
      "use strict";
      var a = r(32);
      e.exports = function (e, t, r, n, o) {
        var i = new Error(e);
        return a(i, t, r, n, o);
      };
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e) {
        return !(!e || !e.__CANCEL__);
      };
    },
    function (e, t, r) {
      "use strict";
      function n(e) {
        this.message = e;
      }
      ((n.prototype.toString = function () {
        return "Cancel" + (this.message ? ": " + this.message : "");
      }),
        (n.prototype.__CANCEL__ = !0),
        (e.exports = n));
    },
    function (e, t, r) {
      "use strict";
      t.a = {
        quoteText: function (e) {
          return '"' + e + '"';
        },
      };
    },
    ,
    ,
    ,
    function (e, t, r) {
      "use strict";
      var n = r(5),
        o = r(17),
        i = r(28),
        a = r(12);
      function s(e) {
        var t = new i(e),
          r = o(i.prototype.request, t);
        return (n.extend(r, i.prototype, t), n.extend(r, t), r);
      }
      var u = s(a);
      ((u.Axios = i),
        (u.create = function (e) {
          return s(n.merge(a, e));
        }),
        (u.Cancel = r(21)),
        (u.CancelToken = r(42)),
        (u.isCancel = r(20)),
        (u.all = function (e) {
          return Promise.all(e);
        }),
        (u.spread = r(43)),
        (e.exports = u),
        (e.exports.default = u));
    },
    function (e, t) {
      /*!
       * Determine if an object is a Buffer
       *
       * @author   Feross Aboukhadijeh <https://feross.org>
       * @license  MIT
       */
      e.exports = function (e) {
        return (
          null != e &&
          null != e.constructor &&
          "function" == typeof e.constructor.isBuffer &&
          e.constructor.isBuffer(e)
        );
      };
    },
    function (e, t, r) {
      "use strict";
      var o = r(12),
        i = r(5),
        n = r(37),
        a = r(38);
      function s(e) {
        ((this.defaults = e),
          (this.interceptors = { request: new n(), response: new n() }));
      }
      ((s.prototype.request = function (e, t) {
        ("string" == typeof e && (e = i.merge({ url: arguments[0] }, t)),
          ((e = i.merge(o, { method: "get" }, this.defaults, e)).method =
            e.method.toLowerCase()));
        var r = [a, void 0],
          n = Promise.resolve(e);
        for (
          this.interceptors.request.forEach(function (e) {
            r.unshift(e.fulfilled, e.rejected);
          }),
            this.interceptors.response.forEach(function (e) {
              r.push(e.fulfilled, e.rejected);
            });
          r.length;
        )
          n = n.then(r.shift(), r.shift());
        return n;
      }),
        i.forEach(["delete", "get", "head", "options"], function (r) {
          s.prototype[r] = function (e, t) {
            return this.request(i.merge(t || {}, { method: r, url: e }));
          };
        }),
        i.forEach(["post", "put", "patch"], function (n) {
          s.prototype[n] = function (e, t, r) {
            return this.request(
              i.merge(r || {}, { method: n, url: e, data: t }),
            );
          };
        }),
        (e.exports = s));
    },
    function (e, t) {
      var r,
        n,
        o = (e.exports = {});
      function i() {
        throw new Error("setTimeout has not been defined");
      }
      function a() {
        throw new Error("clearTimeout has not been defined");
      }
      function s(t) {
        if (r === setTimeout) return setTimeout(t, 0);
        if ((r === i || !r) && setTimeout)
          return ((r = setTimeout), setTimeout(t, 0));
        try {
          return r(t, 0);
        } catch (e) {
          try {
            return r.call(null, t, 0);
          } catch (e) {
            return r.call(this, t, 0);
          }
        }
      }
      !(function () {
        try {
          r = "function" == typeof setTimeout ? setTimeout : i;
        } catch (e) {
          r = i;
        }
        try {
          n = "function" == typeof clearTimeout ? clearTimeout : a;
        } catch (e) {
          n = a;
        }
      })();
      var u,
        c = [],
        f = !1,
        h = -1;
      function l() {
        f &&
          u &&
          ((f = !1), u.length ? (c = u.concat(c)) : (h = -1), c.length && p());
      }
      function p() {
        if (!f) {
          var e = s(l);
          f = !0;
          for (var t = c.length; t; ) {
            for (u = c, c = []; ++h < t; ) u && u[h].run();
            ((h = -1), (t = c.length));
          }
          ((u = null),
            (f = !1),
            (function (t) {
              if (n === clearTimeout) return clearTimeout(t);
              if ((n === a || !n) && clearTimeout)
                return ((n = clearTimeout), clearTimeout(t));
              try {
                n(t);
              } catch (e) {
                try {
                  return n.call(null, t);
                } catch (e) {
                  return n.call(this, t);
                }
              }
            })(e));
        }
      }
      function d(e, t) {
        ((this.fun = e), (this.array = t));
      }
      function m() {}
      ((o.nextTick = function (e) {
        var t = new Array(arguments.length - 1);
        if (1 < arguments.length)
          for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
        (c.push(new d(e, t)), 1 !== c.length || f || s(p));
      }),
        (d.prototype.run = function () {
          this.fun.apply(null, this.array);
        }),
        (o.title = "browser"),
        (o.browser = !0),
        (o.env = {}),
        (o.argv = []),
        (o.version = ""),
        (o.versions = {}),
        (o.on = m),
        (o.addListener = m),
        (o.once = m),
        (o.off = m),
        (o.removeListener = m),
        (o.removeAllListeners = m),
        (o.emit = m),
        (o.prependListener = m),
        (o.prependOnceListener = m),
        (o.listeners = function (e) {
          return [];
        }),
        (o.binding = function (e) {
          throw new Error("process.binding is not supported");
        }),
        (o.cwd = function () {
          return "/";
        }),
        (o.chdir = function (e) {
          throw new Error("process.chdir is not supported");
        }),
        (o.umask = function () {
          return 0;
        }));
    },
    function (e, t, r) {
      "use strict";
      var o = r(5);
      e.exports = function (r, n) {
        o.forEach(r, function (e, t) {
          t !== n &&
            t.toUpperCase() === n.toUpperCase() &&
            ((r[n] = e), delete r[t]);
        });
      };
    },
    function (e, t, r) {
      "use strict";
      var o = r(19);
      e.exports = function (e, t, r) {
        var n = r.config.validateStatus;
        r.status && n && !n(r.status)
          ? t(
              o(
                "Request failed with status code " + r.status,
                r.config,
                null,
                r.request,
                r,
              ),
            )
          : e(r);
      };
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e, t, r, n, o) {
        return (
          (e.config = t),
          r && (e.code = r),
          (e.request = n),
          (e.response = o),
          e
        );
      };
    },
    function (e, t, r) {
      "use strict";
      var i = r(5);
      function a(e) {
        return encodeURIComponent(e)
          .replace(/%40/gi, "@")
          .replace(/%3A/gi, ":")
          .replace(/%24/g, "$")
          .replace(/%2C/gi, ",")
          .replace(/%20/g, "+")
          .replace(/%5B/gi, "[")
          .replace(/%5D/gi, "]");
      }
      e.exports = function (e, t, r) {
        if (!t) return e;
        var n;
        if (r) n = r(t);
        else if (i.isURLSearchParams(t)) n = t.toString();
        else {
          var o = [];
          (i.forEach(t, function (e, t) {
            null != e &&
              (i.isArray(e) ? (t += "[]") : (e = [e]),
              i.forEach(e, function (e) {
                (i.isDate(e)
                  ? (e = e.toISOString())
                  : i.isObject(e) && (e = JSON.stringify(e)),
                  o.push(a(t) + "=" + a(e)));
              }));
          }),
            (n = o.join("&")));
        }
        return (n && (e += (-1 === e.indexOf("?") ? "?" : "&") + n), e);
      };
    },
    function (e, t, r) {
      "use strict";
      var i = r(5),
        a = [
          "age",
          "authorization",
          "content-length",
          "content-type",
          "etag",
          "expires",
          "from",
          "host",
          "if-modified-since",
          "if-unmodified-since",
          "last-modified",
          "location",
          "max-forwards",
          "proxy-authorization",
          "referer",
          "retry-after",
          "user-agent",
        ];
      e.exports = function (e) {
        var t,
          r,
          n,
          o = {};
        return (
          e &&
            i.forEach(e.split("\n"), function (e) {
              if (
                ((n = e.indexOf(":")),
                (t = i.trim(e.substr(0, n)).toLowerCase()),
                (r = i.trim(e.substr(n + 1))),
                t)
              ) {
                if (o[t] && 0 <= a.indexOf(t)) return;
                o[t] =
                  "set-cookie" === t
                    ? (o[t] ? o[t] : []).concat([r])
                    : o[t]
                      ? o[t] + ", " + r
                      : r;
              }
            }),
          o
        );
      };
    },
    function (e, t, r) {
      "use strict";
      var n,
        o,
        i,
        a = r(5);
      function s(e) {
        var t = e;
        return (
          o && (i.setAttribute("href", t), (t = i.href)),
          i.setAttribute("href", t),
          {
            href: i.href,
            protocol: i.protocol ? i.protocol.replace(/:$/, "") : "",
            host: i.host,
            search: i.search ? i.search.replace(/^\?/, "") : "",
            hash: i.hash ? i.hash.replace(/^#/, "") : "",
            hostname: i.hostname,
            port: i.port,
            pathname:
              "/" === i.pathname.charAt(0) ? i.pathname : "/" + i.pathname,
          }
        );
      }
      e.exports = a.isStandardBrowserEnv()
        ? ((o = /(msie|trident)/i.test(navigator.userAgent)),
          (i = document.createElement("a")),
          (n = s(window.location.href)),
          function (e) {
            var t = a.isString(e) ? s(e) : e;
            return t.protocol === n.protocol && t.host === n.host;
          })
        : function () {
            return !0;
          };
    },
    function (e, t, r) {
      "use strict";
      var s = r(5);
      e.exports = s.isStandardBrowserEnv()
        ? {
            write: function (e, t, r, n, o, i) {
              var a = [];
              (a.push(e + "=" + encodeURIComponent(t)),
                s.isNumber(r) && a.push("expires=" + new Date(r).toGMTString()),
                s.isString(n) && a.push("path=" + n),
                s.isString(o) && a.push("domain=" + o),
                !0 === i && a.push("secure"),
                (document.cookie = a.join("; ")));
            },
            read: function (e) {
              var t = document.cookie.match(
                new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"),
              );
              return t ? decodeURIComponent(t[3]) : null;
            },
            remove: function (e) {
              this.write(e, "", Date.now() - 864e5);
            },
          }
        : {
            write: function () {},
            read: function () {
              return null;
            },
            remove: function () {},
          };
    },
    function (e, t, r) {
      "use strict";
      var n = r(5);
      function o() {
        this.handlers = [];
      }
      ((o.prototype.use = function (e, t) {
        return (
          this.handlers.push({ fulfilled: e, rejected: t }),
          this.handlers.length - 1
        );
      }),
        (o.prototype.eject = function (e) {
          this.handlers[e] && (this.handlers[e] = null);
        }),
        (o.prototype.forEach = function (t) {
          n.forEach(this.handlers, function (e) {
            null !== e && t(e);
          });
        }),
        (e.exports = o));
    },
    function (e, t, r) {
      "use strict";
      var n = r(5),
        o = r(39),
        i = r(20),
        a = r(12),
        s = r(40),
        u = r(41);
      function c(e) {
        e.cancelToken && e.cancelToken.throwIfRequested();
      }
      e.exports = function (t) {
        return (
          c(t),
          t.baseURL && !s(t.url) && (t.url = u(t.baseURL, t.url)),
          (t.headers = t.headers || {}),
          (t.data = o(t.data, t.headers, t.transformRequest)),
          (t.headers = n.merge(
            t.headers.common || {},
            t.headers[t.method] || {},
            t.headers || {},
          )),
          n.forEach(
            ["delete", "get", "head", "post", "put", "patch", "common"],
            function (e) {
              delete t.headers[e];
            },
          ),
          (t.adapter || a.adapter)(t).then(
            function (e) {
              return (
                c(t),
                (e.data = o(e.data, e.headers, t.transformResponse)),
                e
              );
            },
            function (e) {
              return (
                i(e) ||
                  (c(t),
                  e &&
                    e.response &&
                    (e.response.data = o(
                      e.response.data,
                      e.response.headers,
                      t.transformResponse,
                    ))),
                Promise.reject(e)
              );
            },
          )
        );
      };
    },
    function (e, t, r) {
      "use strict";
      var n = r(5);
      e.exports = function (t, r, e) {
        return (
          n.forEach(e, function (e) {
            t = e(t, r);
          }),
          t
        );
      };
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e) {
        return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e);
      };
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e, t) {
        return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e;
      };
    },
    function (e, t, r) {
      "use strict";
      var n = r(21);
      function o(e) {
        if ("function" != typeof e)
          throw new TypeError("executor must be a function.");
        var t;
        this.promise = new Promise(function (e) {
          t = e;
        });
        var r = this;
        e(function (e) {
          r.reason || ((r.reason = new n(e)), t(r.reason));
        });
      }
      ((o.prototype.throwIfRequested = function () {
        if (this.reason) throw this.reason;
      }),
        (o.source = function () {
          var t;
          return {
            token: new o(function (e) {
              t = e;
            }),
            cancel: t,
          };
        }),
        (e.exports = o));
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (t) {
        return function (e) {
          return t.apply(null, e);
        };
      };
    },
    function (e, q, U) {
      (function (N, k) {
        var I;
        function R(e) {
          return (R =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                })(e);
        }
        /*! https://mths.be/punycode v1.4.1 by @mathias */ !(function (e) {
          var t = "object" == R(q) && q && !q.nodeType && q,
            r = "object" == R(N) && N && !N.nodeType && N,
            n = "object" == (void 0 === k ? "undefined" : R(k)) && k;
          (n.global !== n && n.window !== n && n.self !== n) || (e = n);
          var o,
            i,
            g = 2147483647,
            v = 36,
            b = 1,
            w = 26,
            a = 38,
            s = 700,
            P = 72,
            x = 128,
            C = "-",
            u = /^xn--/,
            c = /[^\x20-\x7E]/,
            f = /[\x2E\u3002\uFF0E\uFF61]/g,
            h = {
              overflow: "Overflow: input needs wider integers to process",
              "not-basic": "Illegal input >= 0x80 (not a basic code point)",
              "invalid-input": "Invalid input",
            },
            l = v - b,
            S = Math.floor,
            j = String.fromCharCode;
          function O(e) {
            throw new RangeError(h[e]);
          }
          function p(e, t) {
            for (var r = e.length, n = []; r--; ) n[r] = t(e[r]);
            return n;
          }
          function d(e, t) {
            var r = e.split("@"),
              n = "";
            return (
              1 < r.length && ((n = r[0] + "@"), (e = r[1])),
              n + p((e = e.replace(f, ".")).split("."), t).join(".")
            );
          }
          function T(e) {
            for (var t, r, n = [], o = 0, i = e.length; o < i; )
              55296 <= (t = e.charCodeAt(o++)) && t <= 56319 && o < i
                ? 56320 == (64512 & (r = e.charCodeAt(o++)))
                  ? n.push(((1023 & t) << 10) + (1023 & r) + 65536)
                  : (n.push(t), o--)
                : n.push(t);
            return n;
          }
          function A(e) {
            return p(e, function (e) {
              var t = "";
              return (
                65535 < e &&
                  ((t += j((((e -= 65536) >>> 10) & 1023) | 55296)),
                  (e = 56320 | (1023 & e))),
                (t += j(e))
              );
            }).join("");
          }
          function E(e, t) {
            return e + 22 + 75 * (e < 26) - ((0 != t) << 5);
          }
          function _(e, t, r) {
            var n = 0;
            for (
              e = r ? S(e / s) : e >> 1, e += S(e / t);
              (l * w) >> 1 < e;
              n += v
            )
              e = S(e / l);
            return S(n + ((l + 1) * e) / (e + a));
          }
          function m(e) {
            var t,
              r,
              n,
              o,
              i,
              a,
              s,
              u,
              c,
              f,
              h,
              l = [],
              p = e.length,
              d = 0,
              m = x,
              y = P;
            for ((r = e.lastIndexOf(C)) < 0 && (r = 0), n = 0; n < r; ++n)
              (128 <= e.charCodeAt(n) && O("not-basic"),
                l.push(e.charCodeAt(n)));
            for (o = 0 < r ? r + 1 : 0; o < p; ) {
              for (
                i = d, a = 1, s = v;
                p <= o && O("invalid-input"),
                  (h = e.charCodeAt(o++)),
                  (v <=
                    (u =
                      h - 48 < 10
                        ? h - 22
                        : h - 65 < 26
                          ? h - 65
                          : h - 97 < 26
                            ? h - 97
                            : v) ||
                    u > S((g - d) / a)) &&
                    O("overflow"),
                  (d += u * a),
                  !(u < (c = s <= y ? b : y + w <= s ? w : s - y));
                s += v
              )
                (a > S(g / (f = v - c)) && O("overflow"), (a *= f));
              ((y = _(d - i, (t = l.length + 1), 0 == i)),
                S(d / t) > g - m && O("overflow"),
                (m += S(d / t)),
                (d %= t),
                l.splice(d++, 0, m));
            }
            return A(l);
          }
          function y(e) {
            var t,
              r,
              n,
              o,
              i,
              a,
              s,
              u,
              c,
              f,
              h,
              l,
              p,
              d,
              m,
              y = [];
            for (l = (e = T(e)).length, t = x, i = P, a = r = 0; a < l; ++a)
              (h = e[a]) < 128 && y.push(j(h));
            for (n = o = y.length, o && y.push(C); n < l; ) {
              for (s = g, a = 0; a < l; ++a)
                t <= (h = e[a]) && h < s && (s = h);
              for (
                s - t > S((g - r) / (p = n + 1)) && O("overflow"),
                  r += (s - t) * p,
                  t = s,
                  a = 0;
                a < l;
                ++a
              )
                if (((h = e[a]) < t && ++r > g && O("overflow"), h == t)) {
                  for (
                    u = r, c = v;
                    !(u < (f = c <= i ? b : i + w <= c ? w : c - i));
                    c += v
                  )
                    ((m = u - f),
                      (d = v - f),
                      y.push(j(E(f + (m % d), 0))),
                      (u = S(m / d)));
                  (y.push(j(E(u, 0))), (i = _(r, p, n == o)), (r = 0), ++n);
                }
              (++r, ++t);
            }
            return y.join("");
          }
          if (
            ((o = {
              version: "1.4.1",
              ucs2: { decode: T, encode: A },
              decode: m,
              encode: y,
              toASCII: function (e) {
                return d(e, function (e) {
                  return c.test(e) ? "xn--" + y(e) : e;
                });
              },
              toUnicode: function (e) {
                return d(e, function (e) {
                  return u.test(e) ? m(e.slice(4).toLowerCase()) : e;
                });
              },
            }),
            "object" == R(U(11)) && U(11))
          )
            void 0 ===
              (I = function () {
                return o;
              }.call(q, U, q, N)) || (N.exports = I);
          else if (t && r)
            if (N.exports == t) r.exports = o;
            else for (i in o) o.hasOwnProperty(i) && (t[i] = o[i]);
          else e.punycode = o;
        })(this);
      }).call(this, U(45)(e), U(14));
    },
    function (e, t) {
      e.exports = function (e) {
        return (
          e.webpackPolyfill ||
            ((e.deprecate = function () {}),
            (e.paths = []),
            e.children || (e.children = []),
            Object.defineProperty(e, "loaded", {
              enumerable: !0,
              get: function () {
                return e.l;
              },
            }),
            Object.defineProperty(e, "id", {
              enumerable: !0,
              get: function () {
                return e.i;
              },
            }),
            (e.webpackPolyfill = 1)),
          e
        );
      };
    },
    function (e, t, r) {
      "use strict";
      function n(e) {
        return (n =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      e.exports = {
        isString: function (e) {
          return "string" == typeof e;
        },
        isObject: function (e) {
          return "object" === n(e) && null !== e;
        },
        isNull: function (e) {
          return null === e;
        },
        isNullOrUndefined: function (e) {
          return null == e;
        },
      };
    },
    function (e, t, r) {
      "use strict";
      ((t.decode = t.parse = r(48)), (t.encode = t.stringify = r(49)));
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e, t, r, n) {
        ((t = t || "&"), (r = r || "="));
        var o = {};
        if ("string" != typeof e || 0 === e.length) return o;
        var i = /\+/g;
        e = e.split(t);
        var a = 1e3;
        n && "number" == typeof n.maxKeys && (a = n.maxKeys);
        var s,
          u,
          c = e.length;
        0 < a && a < c && (c = a);
        for (var f = 0; f < c; ++f) {
          var h,
            l,
            p,
            d,
            m = e[f].replace(i, "%20"),
            y = m.indexOf(r);
          ((l =
            0 <= y ? ((h = m.substr(0, y)), m.substr(y + 1)) : ((h = m), "")),
            (p = decodeURIComponent(h)),
            (d = decodeURIComponent(l)),
            (s = o),
            (u = p),
            Object.prototype.hasOwnProperty.call(s, u)
              ? g(o[p])
                ? o[p].push(d)
                : (o[p] = [o[p], d])
              : (o[p] = d));
        }
        return o;
      };
      var g =
        Array.isArray ||
        function (e) {
          return "[object Array]" === Object.prototype.toString.call(e);
        };
    },
    function (e, t, r) {
      "use strict";
      function i(e) {
        return (i =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      function a(e) {
        switch (i(e)) {
          case "string":
            return e;
          case "boolean":
            return e ? "true" : "false";
          case "number":
            return isFinite(e) ? e : "";
          default:
            return "";
        }
      }
      e.exports = function (r, n, o, e) {
        return (
          (n = n || "&"),
          (o = o || "="),
          null === r && (r = void 0),
          "object" === i(r)
            ? u(c(r), function (e) {
                var t = encodeURIComponent(a(e)) + o;
                return s(r[e])
                  ? u(r[e], function (e) {
                      return t + encodeURIComponent(a(e));
                    }).join(n)
                  : t + encodeURIComponent(a(r[e]));
              }).join(n)
            : e
              ? encodeURIComponent(a(e)) + o + encodeURIComponent(a(r))
              : ""
        );
      };
      var s =
        Array.isArray ||
        function (e) {
          return "[object Array]" === Object.prototype.toString.call(e);
        };
      function u(e, t) {
        if (e.map) return e.map(t);
        for (var r = [], n = 0; n < e.length; n++) r.push(t(e[n], n));
        return r;
      }
      var c =
        Object.keys ||
        function (e) {
          var t = [];
          for (var r in e)
            Object.prototype.hasOwnProperty.call(e, r) && t.push(r);
          return t;
        };
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e) {
        return encodeURIComponent(e).replace(/[!'()*]/g, function (e) {
          return "%".concat(e.charCodeAt(0).toString(16).toUpperCase());
        });
      };
    },
    function (e, t, r) {
      "use strict";
      function n(e) {
        return (n =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var o = "%[a-f0-9]{2}",
        i = new RegExp(o, "gi"),
        s = new RegExp("(" + o + ")+", "gi");
      function a(e, t) {
        try {
          return decodeURIComponent(e.join(""));
        } catch (e) {}
        if (1 === e.length) return e;
        t = t || 1;
        var r = e.slice(0, t),
          n = e.slice(t);
        return Array.prototype.concat.call([], a(r), a(n));
      }
      function u(t) {
        try {
          return decodeURIComponent(t);
        } catch (e) {
          for (var r = t.match(i), n = 1; n < r.length; n++)
            r = (t = a(r, n).join("")).match(i);
          return t;
        }
      }
      e.exports = function (t) {
        if ("string" != typeof t)
          throw new TypeError(
            "Expected `encodedURI` to be of type `string`, got `" + n(t) + "`",
          );
        try {
          return ((t = t.replace(/\+/g, " ")), decodeURIComponent(t));
        } catch (e) {
          return (function (e) {
            for (
              var t = { "%FE%FF": "��", "%FF%FE": "��" }, r = s.exec(e);
              r;
            ) {
              try {
                t[r[0]] = decodeURIComponent(r[0]);
              } catch (e) {
                var n = u(r[0]);
                n !== r[0] && (t[r[0]] = n);
              }
              r = s.exec(e);
            }
            t["%C2"] = "�";
            for (var o = Object.keys(t), i = 0; i < o.length; i++) {
              var a = o[i];
              e = e.replace(new RegExp(a, "g"), t[a]);
            }
            return e;
          })(t);
        }
      };
    },
    function (e, t, r) {
      "use strict";
      e.exports = function (e, t) {
        if ("string" != typeof e || "string" != typeof t)
          throw new TypeError("Expected the arguments to be of type `string`");
        if ("" === t) return [e];
        var r = e.indexOf(t);
        return -1 === r ? [e] : [e.slice(0, r), e.slice(r + t.length)];
      };
    },
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    function (e, t, r) {
      "use strict";
      r.r(t);
      var c,
        n,
        o = {
          createKeyboardEventHandler: function (e, t, r, n) {
            return (function (t, r, n, o) {
              return (
                void 0 === n && (n = !1),
                void 0 === o && (o = !1),
                function (e) {
                  r(e) &&
                    (n && e.preventDefault(), o && e.stopPropagation(), t());
                }
              );
            })(
              e,
              function (e) {
                return (function (e) {
                  return e instanceof Event
                    ? e instanceof KeyboardEvent
                    : e.nativeEvent && e.nativeEvent instanceof KeyboardEvent;
                })(e)
                  ? t.includes(e.key)
                  : (console.info(
                      "The event passed in is not a keyboard event, are you using the handler in the wrong place?",
                    ),
                    !1);
              },
              r,
              n,
            );
          },
        };
      (((n = c = c || {}).processFailure = "processFailure"),
        (n.unretriableFailure = "unretriableFailure"),
        (n.maxAttemptsReached = "maxAttemptsReached"));
      function i(r, n) {
        return function (e) {
          var t = Math.pow(2, e - 1) * r;
          return Math.min(n, t);
        };
      }
      function a() {
        ((this.completeItems = new Map()),
          (this.requestQueue = []),
          (this.active = !1));
      }
      var s =
        ((a.prototype.handleBatchResult = function (e, t, r, n) {
          var o = this,
            i = 0,
            a = new Date().getTime();
          (t.forEach(function (e) {
            if (o.completeItems.has(e.key))
              e.resolve(o.completeItems.get(e.key));
            else if (
              n.maxRetryAttempts &&
              0 < n.maxRetryAttempts &&
              r !== c.unretriableFailure
            ) {
              var t = (function (e, t) {
                return t.getFailureCooldown ? t.getFailureCooldown(e) : 1e3;
              })(e.retryAttempts, n);
              ((i = 0 < i ? Math.min(i, t) : t),
                ++e.retryAttempts <= n.maxRetryAttempts
                  ? ((e.queueAfter = a + t), o.requestQueue.unshift(e))
                  : e.reject(c.maxAttemptsReached));
            } else e.reject(r);
          }),
            0 < i &&
              setTimeout(function () {
                return o.processQueue(e, n);
              }, i + n.processBatchWaitTime),
            (this.active = !1),
            this.processQueue(e, n));
        }),
        (a.prototype.processQueue = function (r, n) {
          var e,
            o = this;
          if (!this.active) {
            for (
              var i = [], t = new Map(), a = [], s = new Date().getTime();
              i.length < n.batchSize && 0 < this.requestQueue.length;
            ) {
              var u = this.requestQueue.shift();
              u.queueAfter > s
                ? (t.set(u.key, u), a.push(u))
                : this.completeItems.has(u.key)
                  ? u.resolve(this.completeItems.get(u.key))
                  : t.has(u.key)
                    ? a.push(u)
                    : (t.set(u.key, u), i.push(u));
            }
            ((e = this.requestQueue).push.apply(e, a),
              i.length <= 0 ||
                ((this.active = !0),
                r(i).then(
                  function (e) {
                    for (var t in e)
                      e.hasOwnProperty(t) && o.saveCompleteItem(t, e[t], n);
                    o.handleBatchResult(r, i, c.processFailure, n);
                  },
                  function (e) {
                    o.handleBatchResult(r, i, e, n);
                  },
                )));
          }
        }),
        (a.prototype.saveCompleteItem = function (e, t, r) {
          var n = this;
          (this.completeItems.set(e, t),
            r.getItemExpiration &&
              setTimeout(function () {
                n.completeItems.delete(e);
              }, r.getItemExpiration(e)));
        }),
        (a.prototype.queueItem = function (r, n, o, i) {
          var a = this;
          return new Promise(function (e, t) {
            (a.requestQueue.push({
              key: o(r),
              itemId: r,
              retryAttempts: 0,
              queueAfter: 0,
              startTime: new Date(),
              resolve: e,
              reject: t,
            }),
              setTimeout(function () {
                return a.processQueue(n, i);
              }, i.processBatchWaitTime));
          });
        }),
        (a.prototype.invalidateItem = function (e, t) {
          this.completeItems.delete(t(e));
        }),
        a);
      function u() {
        this.createExponentialBackoffCooldown = i;
      }
      var f,
        h = new ((u.prototype.createQueueProcessor = function (t, r, n) {
          var o = new s();
          return {
            queueItem: function (e) {
              return o.queueItem(e, t, r, n);
            },
            invalidateItem: function (e) {
              return o.invalidateItem(e, r);
            },
          };
        }),
        (u.prototype.createRequestProcessor = function (e, t, r) {
          return (
            r.processBatchWaitTime || (r.processBatchWaitTime = 50),
            this.createQueueProcessor(e, t, r)
          );
        }),
        u)();
      (f = f || {}).copy = "Copy";
      var l = f,
        p = {
          commands: l,
          isCommandSupported: function (e) {
            return (
              !!e &&
              !!document.queryCommandSupported &&
              !!document.queryCommandSupported(e)
            );
          },
          write: function (e) {
            var t = document.createElement("input");
            ((t.value = e),
              document.body.appendChild(t),
              t.select(),
              document.execCommand(l.copy),
              document.body.removeChild(t));
          },
        },
        d = {
          sortOrder: { ascending: "Asc", descending: "Desc" },
          status: { idle: "idle", loading: "loading" },
          errorType: {
            pagingParametersChanged: "pagingParametersChanged",
            getItemsFailure: "getItemsFailure",
            invalidPageNumber: "invalidPageNumber",
          },
        };
      function m(e, t) {
        for (var r = 0; r < t.length; r++) {
          var n = t[r];
          ((n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n));
        }
      }
      var y = (function () {
        function t(e) {
          (!(function (e, t) {
            if (!(e instanceof t))
              throw new TypeError("Cannot call a class as a function");
          })(this, t),
            (this.pageSize = e),
            (this.cache = {}));
        }
        return (
          (function (e, t, r) {
            (t && m(e.prototype, t), r && m(e, r));
          })(t, [
            {
              key: "getPage",
              value: function (e, t) {
                var r = this.cache[e];
                return r
                  ? r.slice((t - 1) * this.pageSize, t * this.pageSize)
                  : [];
              },
            },
            {
              key: "getLength",
              value: function (e) {
                var t = this.cache[e];
                return t ? t.length : 0;
              },
            },
            {
              key: "append",
              value: function (e, t) {
                (this.cache[e] || (this.cache[e] = []),
                  (this.cache[e] = this.cache[e].concat(t)));
              },
            },
            {
              key: "removeAfterIndex",
              value: function (e, t) {
                this.cache[e] && (this.cache[e] = this.cache[e].slice(0, t));
              },
            },
            {
              key: "clear",
              value: function (e) {
                delete this.cache[e];
              },
            },
          ]),
          t
        );
      })();
      function g(e, t) {
        for (var r = 0; r < t.length; r++) {
          var n = t[r];
          ((n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n));
        }
      }
      var v = (function () {
        function n(e, t, r) {
          (!(function (e, t) {
            if (!(e instanceof t))
              throw new TypeError("Cannot call a class as a function");
          })(this, n),
            (this._pageSize = e),
            (this._loadPageSize = t),
            (this._getItems = r),
            (this._cache = new y(e)),
            (this._firstPagePagingParameters = {}),
            (this._pagingParameters = {}),
            (this._indexCursors = {}),
            (this._initId = 0),
            (this._status = d.status.idle),
            (this._currentPageNumber = 1),
            this._setNextPageCursor(""));
        }
        return (
          (function (e, t, r) {
            (t && g(e.prototype, t), r && g(e, r));
          })(n, [
            {
              key: "setPagingParametersAndLoadFirstPage",
              value: function (e) {
                var t = this._getCacheKey();
                return (
                  this._cache.clear(t),
                  (this._currentPageNumber = 1),
                  (this._indexCursors = {}),
                  (this._firstPagePagingParameters = Object.assign({}, e)),
                  (this._pagingParameters = Object.assign({}, e)),
                  this._setNextPageCursor(""),
                  this._loadPage(1)
                );
              },
            },
            {
              key: "reloadCurrentPage",
              value: function () {
                if (1 === this.currentPageNumber) return this.loadFirstPage();
                var e = this._getCacheKey(),
                  t = 0,
                  r = this._indexCursors,
                  n = this.currentPageNumber * (this._pageSize - 1);
                Object.keys(r).forEach(function (e) {
                  Number(e) > n ? delete r[e] : (t = Math.max(e, t));
                });
                var o = Math.floor(n / this._loadPageSize) * this._loadPageSize;
                return (
                  this._cache.removeAfterIndex(e, o),
                  this._setNextPageCursor(r[t] || ""),
                  this._loadPage(this._currentPageNumber)
                );
              },
            },
            {
              key: "getCurrentPage",
              value: function () {
                return this._loadPage(this.currentPageNumber);
              },
            },
            {
              key: "loadNextPage",
              value: function () {
                return this._loadPage(this.currentPageNumber + 1);
              },
            },
            {
              key: "loadPreviousPage",
              value: function () {
                return this._loadPage(this.currentPageNumber - 1);
              },
            },
            {
              key: "loadFirstPage",
              value: function () {
                return this.setPagingParametersAndLoadFirstPage(
                  this._firstPagePagingParameters,
                );
              },
            },
            {
              key: "_loadPage",
              value: function (a, s) {
                var u = this;
                return (
                  (s = s || ++u._initId),
                  new Promise(function (t, r) {
                    function e(e) {
                      u._initId === s
                        ? ((u._status = d.status.idle), r(e))
                        : r({ type: d.errorType.pagingParametersChanged });
                    }
                    function n(e) {
                      u._initId === s
                        ? ((u._status = d.status.idle),
                          (u._currentPageNumber = a),
                          t(e))
                        : r({ type: d.errorType.pagingParametersChanged });
                    }
                    if (a < 1) e({ type: d.errorType.invalidPageNumber });
                    else {
                      var o = u._getCacheKey(),
                        i = u._cache.getPage(o, a);
                      if (i.length !== u._pageSize) {
                        if ("string" != typeof u._pagingParameters.cursor)
                          return i.length <= 0 && 1 < a
                            ? void e({ type: d.errorType.invalidPageNumber })
                            : void n(i);
                        ((u._status = d.status.loading),
                          u
                            ._loadNextPageIntoCache(o, s)
                            .then(function () {
                              u._loadPage(a, s).then(n).catch(e);
                            })
                            .catch(e));
                      } else n(i);
                    }
                  })
                );
              },
            },
            {
              key: "_getCacheKey",
              value: function () {
                return JSON.stringify(this._firstPagePagingParameters);
              },
            },
            {
              key: "_setNextPageCursor",
              value: function (e) {
                this._pagingParameters = Object.assign(
                  {},
                  this._pagingParameters,
                  { cursor: e },
                );
              },
            },
            {
              key: "_loadNextPageIntoCache",
              value: function (n, o) {
                var i = this;
                return new Promise(function (t, r) {
                  i._indexCursors[i._cache.getLength(n)] =
                    i._pagingParameters.cursor;
                  var e = Object.keys(i._indexCursors).length;
                  i._getItems(
                    Object.assign({}, i._pagingParameters, {
                      count: i._loadPageSize,
                      pageNumber: e,
                    }),
                  )
                    .then(function (e) {
                      o === i._initId
                        ? (i._setNextPageCursor(e.nextPageCursor),
                          i._cache.append(n, e.items),
                          t())
                        : r({ type: d.errorType.pagingParametersChanged });
                    })
                    .catch(function (e) {
                      o === i._initId
                        ? r({ type: d.errorType.getItemsFailure, data: e })
                        : r({ type: d.errorType.pagingParametersChanged });
                    });
                });
              },
            },
            {
              key: "status",
              get: function () {
                return this._status;
              },
            },
            {
              key: "isBusy",
              get: function () {
                return this.status !== d.status.idle;
              },
            },
            {
              key: "currentPageNumber",
              get: function () {
                return this._currentPageNumber;
              },
            },
            {
              key: "pagingParameters",
              get: function () {
                return Object.assign({}, this._firstPagePagingParameters);
              },
            },
            {
              key: "hasNextPage",
              get: function () {
                var e = this._getCacheKey();
                return (
                  this._cache.getLength(e) >
                    this.currentPageNumber * this._pageSize ||
                  "string" == typeof this._pagingParameters.cursor
                );
              },
            },
            {
              key: "canLoadNextPage",
              get: function () {
                return this.hasNextPage && !this.isBusy;
              },
            },
            {
              key: "canLoadPreviousPage",
              get: function () {
                return !this.isBusy && 1 < this.currentPageNumber;
              },
            },
            {
              key: "canLoadFirstPage",
              get: function () {
                return !this.isBusy;
              },
            },
            {
              key: "canReloadCurrentPage",
              get: function () {
                return !this.isBusy;
              },
            },
          ]),
          n
        );
      })();
      function b(e, t) {
        var r = new Date(e.toISOString());
        return (r.setDate(e.getDate() + t), r);
      }
      function w(e, t) {
        var r = new Date(e.toISOString());
        return (r.setMonth(e.getMonth() + t), r);
      }
      function P(e, t) {
        var r = new Date(e.toISOString());
        return (r.setYear(e.getFullYear() + t), r);
      }
      var x = {
        getUtcQueryString: function (e) {
          if (!e) return "";
          var t = (e.getUTCMonth() + 1).toString().padStart(2, "0"),
            r = e.getUTCDate().toString().padStart(2, "0");
          return "".concat(e.getUTCFullYear(), "-").concat(t, "-").concat(r);
        },
        endOfToday: function () {
          var e = new Date();
          return (e.setHours(23, 59, 59, 999), e);
        },
        startOfToday: function () {
          var e = new Date();
          return (e.setHours(0, 0, 0, 0), e);
        },
        addYears: P,
        subYears: function (e, t) {
          return P(e, -t);
        },
        addMonths: w,
        subMonths: function (e, t) {
          return w(e, -t);
        },
        addDays: b,
        subDays: function (e, t) {
          return b(e, -t);
        },
      };
      function C() {
        var r = this;
        (!(function (e, t) {
          if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function");
        })(this, C),
          (this.promise = new Promise(function (e, t) {
            ((r.resolve = e), (r.reject = t));
          })),
          (this.then = this.promise.then.bind(this.promise)),
          (this.catch = this.promise.catch.bind(this.promise)),
          (this.finally = this.promise.finally.bind(this.promise)));
      }
      var S = r(1);
      function j(e, t, r) {
        ((this.list = e || []),
          (this.filteredList = []),
          (this.totalPages = 0),
          (this.searchTypesMap = t || {}),
          (this.sortTypesMap = r || {}));
      }
      var O,
        T,
        A =
          ((j.prototype.updateList = function (e) {
            ((this.list = e), (this.filteredList = []));
          }),
          (j.prototype.search = function (e) {
            if (e) {
              var t = e.keyword,
                r = e.searchTypeKey,
                n = e.extraArgs,
                o = this.searchTypesMap[r],
                i = "string" == typeof t && t.trim();
              this.filteredList =
                i && o && "function" == typeof o
                  ? o(i, this.list, n)
                  : this.list;
            }
          }),
          (j.prototype.sort = function (e) {
            if (e) {
              var t = e.sortTypeKey,
                r = e.extraArgs,
                n = this.sortTypesMap[t];
              n && "function" == typeof n && n(this.filteredList, r);
            }
          }),
          (j.prototype.paginate = function (e) {
            if (e) {
              var t = e.offset,
                r = e.pageSize;
              this.totalPages = Math.ceil(this.filteredList.length / r);
              var n = t < this.filteredList.length ? t : 0,
                o = this.filteredList.slice(n, n + r);
              this.filteredList = o;
            }
          }),
          (j.prototype.filter = function (e, t, r) {
            return (
              this.search(t),
              this.sort(r),
              this.paginate(e),
              { list: this.filteredList, totalPages: this.totalPages }
            );
          }),
          j);
      (((T = O = O || {}).RollerCoaster = "RollerCoaster"),
        (T.Landing = "Landing"));
      var E = O,
        _ =
          ((N.getInternalPageName = function () {
            if (!N.internalPageName) {
              var e = document.querySelector('meta[name="page-meta"]');
              e &&
                e.dataset &&
                e.dataset.internalPageName &&
                (N.internalPageName = e.dataset.internalPageName);
            }
            return N.internalPageName;
          }),
          (N.isLandingPage = function () {
            var e = N.getInternalPageName();
            return e === E.Landing || e === E.RollerCoaster;
          }),
          N);
      function N() {}
      var k,
        I,
        R = { PageNames: E, PageNameProvider: _ },
        q = r(10),
        U = {
          withPlus: ["", "K+", "M+", "B+", "T+"],
          withoutPlus: ["", "K", "M", "B", "T"],
        };
      (((I = k = k || {}).withPlus = "withPlus"),
        (I.withoutPlus = "withoutPlus"));
      var L = k,
        F = {
          getNumberFormat: function (t, e, r, n) {
            try {
              return new Intl.NumberFormat(e, { style: r, currency: n }).format(
                t,
              );
            } catch (e) {
              return t.toString();
            }
          },
        },
        B = {
          getAbbreviatedValue: function (e, t, r, n) {
            var o = "" + e;
            if (r && e < r) return n ? F.getNumberFormat(e) : o;
            var i = t ? U[t] : U[L.withoutPlus],
              a = Math.ceil(o.length / 3),
              s = Math.pow(1e3, a),
              u = Math.round((e / s) * 10) / 10,
              c = a - 1,
              f = Math.pow(1e3, c),
              h = Math.round((e / f) * 10) / 10;
            return (o = 1e3 <= h ? u + i[a] : h + i[c]);
          },
          suffixNames: L,
          getTruncValue: function (e, t, r, n) {
            var o = "" + e;
            if (e < (t || 1e4)) return F.getNumberFormat(e);
            var i = r ? U[r] : U[L.withPlus],
              a = i[i.length - 1],
              s = 12;
            ((a = i[Math.floor(Math.log(e) / Math.log(1e3))]),
              e < 1e6 ? (s = 3) : e < 1e9 ? (s = 6) : e < 1e12 && (s = 9));
            var u = o.length - s,
              c = n ? "." + o.substring(u, n) : "";
            return o.substring(0, u) + c + a;
          },
        },
        M = r(22);
      window.CoreUtilities = {
        accessibility: o,
        batchRequestFactory: h,
        clipboard: p,
        CursorPager: v,
        cursorPaginationConstants: d,
        dateService: x,
        defer: function () {
          return new C();
        },
        downloadFile: function (e, t, r) {
          var n = new Blob([e], { type: r }),
            o = URL.createObjectURL(n),
            i = document.createElement("a");
          (i.setAttribute("href", o),
            i.setAttribute("download", t),
            (i.style.visibility = "hidden"),
            document.body.appendChild(i),
            i.click(),
            document.body.removeChild(i));
        },
        httpRequestMethods: S.b,
        httpResponseCodes: S.c,
        httpService: S.d,
        ListFilterProvider: A,
        PaginationCache: y,
        pageName: R,
        ready: function (e) {
          "loading" === document.readyState
            ? document.addEventListener("DOMContentLoaded", e)
            : e();
        },
        urlService: q.a,
        regex: {
          email:
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
          escape: function (e) {
            return e.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
          },
        },
        abbreviateNumber: B,
        quote: M.a,
        numberFormat: F,
      };
    },
  ]);
  //# sourceMappingURL=https://js.rbxcdn.com/833715350611d1c28d50-coreUtilities.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("CoreUtilities");
}
