var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (n) {
    var o = {};
    function i(t) {
      if (o[t]) return o[t].exports;
      var e = (o[t] = { i: t, l: !1, exports: {} });
      return (n[t].call(e.exports, e, e.exports, i), (e.l = !0), e.exports);
    }
    ((i.m = n),
      (i.c = o),
      (i.d = function (t, e, n) {
        i.o(t, e) || Object.defineProperty(t, e, { enumerable: !0, get: n });
      }),
      (i.r = function (t) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(t, "__esModule", { value: !0 }));
      }),
      (i.t = function (e, t) {
        if ((1 & t && (e = i(e)), 8 & t)) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (
          (i.r(n),
          Object.defineProperty(n, "default", { enumerable: !0, value: e }),
          2 & t && "string" != typeof e)
        )
          for (var o in e)
            i.d(
              n,
              o,
              function (t) {
                return e[t];
              }.bind(null, o),
            );
        return n;
      }),
      (i.n = function (t) {
        var e =
          t && t.__esModule
            ? function () {
                return t.default;
              }
            : function () {
                return t;
              };
        return (i.d(e, "a", e), e);
      }),
      (i.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
      }),
      (i.p = ""),
      i((i.s = 195)));
  })({
    10: function (t, e, n) {
      "use strict";
      var o = n(6),
        i = n(2),
        r = n
          .n(i)
          .a.module("modal", ["ui.bootstrap", "modalHtmlTemplate"])
          .config([
            "$uibModalProvider",
            "$injector",
            function (t, e) {
              ((t.options.openedClass = "modal-open-noscroll"),
                (t.options.animation = !1),
                o.Lang &&
                  o.Lang.ControlsResources &&
                  e
                    .get("languageResourceProvider")
                    .setLanguageKeysFromFile(o.Lang.ControlsResources));
            },
          ])
          .run([
            "modalOptions",
            "$uibModalStack",
            "$rootScope",
            function (n, o, t) {
              var e = t.$watch(
                function () {
                  return document.querySelectorAll(n.layoutParams.modalSelector)
                    .length;
                },
                function (t) {
                  0 < t &&
                    (window.NodeList &&
                      !NodeList.prototype.forEach &&
                      (NodeList.prototype.forEach = Array.prototype.forEach),
                    document
                      .querySelectorAll(n.layoutParams.modalSelector)
                      .forEach(function (t) {
                        var e = o.getTop();
                        e &&
                          e.value.backdrop !== n.backdropStatus.static &&
                          (t.addEventListener(
                            n.userInteraction.mouseDown,
                            function (t) {
                              t.button === n.mainButtonPressed &&
                                o.getTop().key.dismiss();
                            },
                          ),
                          t
                            .querySelector(n.layoutParams.modalContentSelector)
                            .addEventListener(
                              n.userInteraction.mouseDown,
                              function (t) {
                                t.stopPropagation();
                              },
                            ));
                      }),
                    o.getTop() &&
                      (o.getTop().value.backdrop = n.backdropStatus.static));
                },
              );
              t.$on("$destroy", function () {
                e();
              });
            },
          ]);
      e.a = r;
    },
    125: function (t, e, n) {
      "use strict";
      var o = n(2),
        i = n.n(o).a.module("limitedIcon", ["limitedIconTemplate"]);
      e.a = i;
    },
    195: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(2),
        i = n.n(o),
        r = n(4);
      (n(196), n(36), n(37), n(38), n(58), n(10), n(125));
      Object(r.importFilesUnderPath)(n(80));
      var s = n(82);
      (Object(r.templateCacheGenerator)(i.a, "toastHtmlTemplate", s),
        Object(r.importFilesUnderPath)(n(84)),
        Object(r.importFilesUnderPath)(n(86)),
        Object(r.importFilesUnderPath)(n(197)),
        Object(r.importFilesUnderPath)(n(199)),
        Object(r.importFilesUnderPath)(n(88)),
        Object(r.importFilesUnderPath)(n(90)),
        Object(r.importFilesUnderPath)(n(92)));
      var a = n(95);
      (Object(r.templateCacheGenerator)(i.a, "modalHtmlTemplate", a),
        Object(r.importFilesUnderPath)(n(200)));
      var u = n(202);
      Object(r.templateCacheGenerator)(i.a, "limitedIconTemplate", u);
    },
    196: function (t, e, n) {},
    197: function (t, e, n) {
      var o = { "./glideConstants.js": 198 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 197));
    },
    198: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = {
        options: {
          breakpoints: {
            479: { perView: 3 },
            766: { perView: 5 },
            1023: { perView: 7 },
          },
          startAt: 0,
          perView: 7,
        },
        breakpointWidth: [479, 766, 1023],
        glideControl: {
          defaultNumItemsToMove: 7,
          currentNumSlidesToMove: 7,
          currentPageNumber: 0,
          disableLeftMove: !1,
          disableRightMove: !1,
        },
      };
      (n(58).a.constant("glideConstants", o), (e.default = o));
    },
    199: function (t, e, n) {
      var o = { "./controlService.js": 384 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 199));
    },
    2: function (t, e) {
      t.exports = angular;
    },
    200: function (t, e, n) {
      var o = { "./limitedIconDirective.js": 201 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 200));
    },
    201: function (t, e, n) {
      "use strict";
      function o() {
        return {
          restrict: "A",
          replace: !0,
          scope: { layoutOptions: "=layoutOptions" },
          templateUrl: "limited-icon-container",
        };
      }
      (n.r(e), n(125).a.directive("limitedIcon", o), (e.default = o));
    },
    202: function (t, e, n) {
      var o = { "./directives/templates/limitedIconContainer.html": 203 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 202));
    },
    203: function (t, e) {
      t.exports =
        '<span class="limited-icon-container"> <span class="icon-shop-limited" ng-hide="layoutOptions.isIconDisabled"> </span> <span class="limited-number-container" ng-show="layoutOptions.isUnique"> <span class="font-caption-header">#</span> <span class="font-caption-header text-subheader limited-number" ng-show="layoutOptions.isLimitedNumberShown" ng-bind="layoutOptions.limitedNumber"></span> </span>';
    },
    36: function (t, e, n) {
      "use strict";
      var o = n(2),
        i = n.n(o).a.module("toast", ["toastHtmlTemplate"]);
      e.a = i;
    },
    37: function (t, e, n) {
      "use strict";
      var o = n(2),
        i = n.n(o).a.module("infiniteScroll", []);
      e.a = i;
    },
    38: function (t, e, n) {
      "use strict";
      var o = n(2),
        i = n.n(o).a.module("verticalMenu", []);
      e.a = i;
    },
    384: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(58);
      function i(t) {
        return (i =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      /*!
       * Glide.js v3.3.0
       * (c) 2013-2019 Jędrzej Chałubek <jedrzej.chalubek@gmail.com> (http://jedrzejchalubek.com/)
       * Released under the MIT License.
       */ var r = {
        type: "slider",
        startAt: 0,
        perView: 1,
        focusAt: 0,
        gap: 10,
        autoplay: !1,
        hoverpause: !0,
        keyboard: !0,
        bound: !1,
        swipeThreshold: 80,
        dragThreshold: 120,
        perTouch: !1,
        touchRatio: 0.5,
        touchAngle: 45,
        animationDuration: 400,
        rewind: !0,
        rewindDuration: 800,
        animationTimingFunc: "cubic-bezier(.165, .840, .440, 1)",
        throttle: 10,
        direction: "ltr",
        peek: 0,
        breakpoints: {},
        classes: {
          direction: { ltr: "glide--ltr", rtl: "glide--rtl" },
          slider: "glide--slider",
          carousel: "glide--carousel",
          swipeable: "glide--swipeable",
          dragging: "glide--dragging",
          cloneSlide: "glide__slide--clone",
          activeNav: "glide__bullet--active",
          activeSlide: "glide__slide--active",
          disabledArrow: "glide__arrow--disabled",
        },
      };
      function a(t) {
        console.error("[Glide warn]: " + t);
      }
      function s(t, e) {
        if (!(t instanceof e))
          throw new TypeError("Cannot call a class as a function");
      }
      var u =
          "function" == typeof Symbol && "symbol" === i(Symbol.iterator)
            ? function (t) {
                return i(t);
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : i(t);
              },
        c = function (t, e, n) {
          return (e && l(t.prototype, e), n && l(t, n), t);
        };
      function l(t, e) {
        for (var n = 0; n < e.length; n++) {
          var o = e[n];
          ((o.enumerable = o.enumerable || !1),
            (o.configurable = !0),
            "value" in o && (o.writable = !0),
            Object.defineProperty(t, o.key, o));
        }
      }
      var d =
        Object.assign ||
        function (t) {
          for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var o in n)
              Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
          }
          return t;
        };
      function b(t) {
        return parseInt(t);
      }
      function f(t) {
        return "string" == typeof t;
      }
      function m(t) {
        var e = void 0 === t ? "undefined" : u(t);
        return "function" === e || ("object" === e && !!t);
      }
      function v(t) {
        return "function" == typeof t;
      }
      function h(t) {
        return void 0 === t;
      }
      function p(t) {
        return t.constructor === Array;
      }
      function g(t, e, n) {
        Object.defineProperty(t, e, n);
      }
      function y(t, e) {
        var n = d({}, t, e);
        return (
          e.hasOwnProperty("classes") &&
            ((n.classes = d({}, t.classes, e.classes)),
            e.classes.hasOwnProperty("direction") &&
              (n.classes.direction = d(
                {},
                t.classes.direction,
                e.classes.direction,
              ))),
          e.hasOwnProperty("breakpoints") &&
            (n.breakpoints = d({}, t.breakpoints, e.breakpoints)),
          n
        );
      }
      var w =
        (c(k, [
          {
            key: "on",
            value: function (t, e) {
              if (p(t)) for (var n = 0; n < t.length; n++) this.on(t[n], e);
              this.hop.call(this.events, t) || (this.events[t] = []);
              var o = this.events[t].push(e) - 1;
              return {
                remove: function () {
                  delete this.events[t][o];
                },
              };
            },
          },
          {
            key: "emit",
            value: function (t, e) {
              if (p(t)) for (var n = 0; n < t.length; n++) this.emit(t[n], e);
              this.hop.call(this.events, t) &&
                this.events[t].forEach(function (t) {
                  t(e || {});
                });
            },
          },
        ]),
        k);
      function k() {
        var t =
          0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        (s(this, k), (this.events = t), (this.hop = t.hasOwnProperty));
      }
      var S =
        (c(O, [
          {
            key: "mount",
            value: function (t) {
              var e = 0 < arguments.length && void 0 !== t ? t : {};
              return (
                this._e.emit("mount.before"),
                m(e)
                  ? (this._c = (function (t, e, n) {
                      var o = {};
                      for (var i in e)
                        v(e[i])
                          ? (o[i] = e[i](t, o, n))
                          : a("Extension must be a function");
                      for (var r in o) v(o[r].mount) && o[r].mount();
                      return o;
                    })(this, e, this._e))
                  : a("You need to provide a object on `mount()`"),
                this._e.emit("mount.after"),
                this
              );
            },
          },
          {
            key: "mutate",
            value: function (t) {
              var e = 0 < arguments.length && void 0 !== t ? t : [];
              return (
                p(e)
                  ? (this._t = e)
                  : a("You need to provide a array on `mutate()`"),
                this
              );
            },
          },
          {
            key: "update",
            value: function (t) {
              var e = 0 < arguments.length && void 0 !== t ? t : {};
              return (
                (this.settings = y(this.settings, e)),
                e.hasOwnProperty("startAt") && (this.index = e.startAt),
                this._e.emit("update"),
                this
              );
            },
          },
          {
            key: "go",
            value: function (t) {
              return (this._c.Run.make(t), this);
            },
          },
          {
            key: "move",
            value: function (t) {
              return (this._c.Transition.disable(), this._c.Move.make(t), this);
            },
          },
          {
            key: "destroy",
            value: function () {
              return (this._e.emit("destroy"), this);
            },
          },
          {
            key: "play",
            value: function (t) {
              var e = 0 < arguments.length && void 0 !== t && t;
              return (
                e && (this.settings.autoplay = e),
                this._e.emit("play"),
                this
              );
            },
          },
          {
            key: "pause",
            value: function () {
              return (this._e.emit("pause"), this);
            },
          },
          {
            key: "disable",
            value: function () {
              return ((this.disabled = !0), this);
            },
          },
          {
            key: "enable",
            value: function () {
              return ((this.disabled = !1), this);
            },
          },
          {
            key: "on",
            value: function (t, e) {
              return (this._e.on(t, e), this);
            },
          },
          {
            key: "isType",
            value: function (t) {
              return this.settings.type === t;
            },
          },
          {
            key: "settings",
            get: function () {
              return this._o;
            },
            set: function (t) {
              m(t) ? (this._o = t) : a("Options must be an `object` instance.");
            },
          },
          {
            key: "index",
            get: function () {
              return this._i;
            },
            set: function (t) {
              this._i = b(t);
            },
          },
          {
            key: "type",
            get: function () {
              return this.settings.type;
            },
          },
          {
            key: "disabled",
            get: function () {
              return this._d;
            },
            set: function (t) {
              this._d = !!t;
            },
          },
        ]),
        O);
      function O(t) {
        var e =
          1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {};
        (s(this, O),
          (this._c = {}),
          (this._t = []),
          (this._e = new w()),
          (this.disabled = !1),
          (this.selector = t),
          (this.settings = y(r, e)),
          (this.index = this.settings.startAt));
      }
      function _() {
        return new Date().getTime();
      }
      function T(n, o, i) {
        var r = void 0,
          s = void 0,
          a = void 0,
          u = void 0,
          c = 0;
        i = i || {};
        function l() {
          ((c = !1 === i.leading ? 0 : _()),
            (r = null),
            (u = n.apply(s, a)),
            r || (s = a = null));
        }
        function t() {
          var t = _();
          c || !1 !== i.leading || (c = t);
          var e = o - (t - c);
          return (
            (s = this),
            (a = arguments),
            e <= 0 || o < e
              ? (r && (clearTimeout(r), (r = null)),
                (c = t),
                (u = n.apply(s, a)),
                r || (s = a = null))
              : r || !1 === i.trailing || (r = setTimeout(l, e)),
            u
          );
        }
        return (
          (t.cancel = function () {
            (clearTimeout(r), (c = 0), (r = s = a = null));
          }),
          t
        );
      }
      var D = {
        ltr: ["marginLeft", "marginRight"],
        rtl: ["marginRight", "marginLeft"],
      };
      function x(t) {
        if (t && t.parentNode) {
          for (var e = t.parentNode.firstChild, n = []; e; e = e.nextSibling)
            1 === e.nodeType && e !== t && n.push(e);
          return n;
        }
        return [];
      }
      function C(t) {
        return !!(t && t instanceof window.HTMLElement);
      }
      var M = '[data-glide-el="track"]';
      var j =
        (c(N, [
          {
            key: "on",
            value: function (t, e, n, o) {
              var i = 3 < arguments.length && void 0 !== o && o;
              f(t) && (t = [t]);
              for (var r = 0; r < t.length; r++)
                ((this.listeners[t[r]] = n),
                  e.addEventListener(t[r], this.listeners[t[r]], i));
            },
          },
          {
            key: "off",
            value: function (t, e, n) {
              var o = 2 < arguments.length && void 0 !== n && n;
              f(t) && (t = [t]);
              for (var i = 0; i < t.length; i++)
                e.removeEventListener(t[i], this.listeners[t[i]], o);
            },
          },
          {
            key: "destroy",
            value: function () {
              delete this.listeners;
            },
          },
        ]),
        N);
      function N() {
        var t =
          0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        (s(this, N), (this.listeners = t));
      }
      var P = ["ltr", "rtl"],
        E = { ">": "<", "<": ">", "=": "=" };
      function H(t, e) {
        return {
          modify: function (t) {
            return e.Direction.is("rtl") ? -t : t;
          },
        };
      }
      function L(o, i, r) {
        var s = [
          function (e, n) {
            return {
              modify: function (t) {
                return t + n.Gaps.value * e.index;
              },
            };
          },
          function (t, e) {
            return {
              modify: function (t) {
                return t + e.Clones.grow / 2;
              },
            };
          },
          function (n, o) {
            return {
              modify: function (t) {
                if (0 <= n.settings.focusAt) {
                  var e = o.Peek.value;
                  return m(e) ? t - e.before : t - e;
                }
                return t;
              },
            };
          },
          function (r, s) {
            return {
              modify: function (t) {
                var e = s.Gaps.value,
                  n = s.Sizes.width,
                  o = r.settings.focusAt,
                  i = s.Sizes.slideWidth;
                return "center" === o ? t - (n / 2 - i / 2) : t - i * o - e * o;
              },
            };
          },
        ].concat(o._t, [H]);
        return {
          mutate: function (t) {
            for (var e = 0; e < s.length; e++) {
              var n = s[e];
              v(n) && v(n().modify)
                ? (t = n(o, i, r).modify(t))
                : a(
                    "Transformer should be a function that returns an object with `modify()` method",
                  );
            }
            return t;
          },
        };
      }
      var U = !1;
      try {
        var A = Object.defineProperty({}, "passive", {
          get: function () {
            U = !0;
          },
        });
        (window.addEventListener("testPassive", null, A),
          window.removeEventListener("testPassive", null, A));
      } catch (t) {}
      var $ = U,
        I = ["touchstart", "mousedown"],
        R = ["touchmove", "mousemove"],
        F = ["touchend", "touchcancel", "mouseup", "mouseleave"],
        B = ["mousedown", "mousemove", "mouseup", "mouseleave"];
      function z(t) {
        return m(t)
          ? (function (n) {
              return Object.keys(n)
                .sort()
                .reduce(function (t, e) {
                  return ((t[e] = n[e]), t[e], t);
                }, {});
            })(t)
          : (a("Breakpoints option must be an object"), {});
      }
      var W = {
        Html: function (e, t) {
          var n = {
            mount: function () {
              ((this.root = e.selector),
                (this.track = this.root.querySelector(M)),
                (this.slides = Array.prototype.slice
                  .call(this.wrapper.children)
                  .filter(function (t) {
                    return !t.classList.contains(e.settings.classes.cloneSlide);
                  })));
            },
          };
          return (
            g(n, "root", {
              get: function () {
                return n._r;
              },
              set: function (t) {
                (f(t) && (t = document.querySelector(t)),
                  C(t)
                    ? (n._r = t)
                    : a("Root element must be a existing Html node"));
              },
            }),
            g(n, "track", {
              get: function () {
                return n._t;
              },
              set: function (t) {
                C(t)
                  ? (n._t = t)
                  : a(
                      "Could not find track element. Please use " +
                        M +
                        " attribute.",
                    );
              },
            }),
            g(n, "wrapper", {
              get: function () {
                return n.track.children[0];
              },
            }),
            n
          );
        },
        Translate: function (i, r, s) {
          var a = {
            set: function (t) {
              var e = L(i, r).mutate(t);
              r.Html.wrapper.style.transform =
                "translate3d(" + -1 * e + "px, 0px, 0px)";
            },
            remove: function () {
              r.Html.wrapper.style.transform = "";
            },
          };
          return (
            s.on("move", function (t) {
              var e = r.Gaps.value,
                n = r.Sizes.length,
                o = r.Sizes.slideWidth;
              return i.isType("carousel") && r.Run.isOffset("<")
                ? (r.Transition.after(function () {
                    (s.emit("translate.jump"), a.set(o * (n - 1)));
                  }),
                  a.set(-o - e * n))
                : i.isType("carousel") && r.Run.isOffset(">")
                  ? (r.Transition.after(function () {
                      (s.emit("translate.jump"), a.set(0));
                    }),
                    a.set(o * n + e * n))
                  : a.set(t.movement);
            }),
            s.on("destroy", function () {
              a.remove();
            }),
            a
          );
        },
        Transition: function (n, o, t) {
          var i = !1,
            e = {
              compose: function (t) {
                var e = n.settings;
                return i
                  ? t + " 0ms " + e.animationTimingFunc
                  : t + " " + this.duration + "ms " + e.animationTimingFunc;
              },
              set: function (t) {
                var e = 0 < arguments.length && void 0 !== t ? t : "transform";
                o.Html.wrapper.style.transition = this.compose(e);
              },
              remove: function () {
                o.Html.wrapper.style.transition = "";
              },
              after: function (t) {
                setTimeout(function () {
                  t();
                }, this.duration);
              },
              enable: function () {
                ((i = !1), this.set());
              },
              disable: function () {
                ((i = !0), this.set());
              },
            };
          return (
            g(e, "duration", {
              get: function () {
                var t = n.settings;
                return n.isType("slider") && o.Run.offset
                  ? t.rewindDuration
                  : t.animationDuration;
              },
            }),
            t.on("move", function () {
              e.set();
            }),
            t.on(["build.before", "resize", "translate.jump"], function () {
              e.disable();
            }),
            t.on("run", function () {
              e.enable();
            }),
            t.on("destroy", function () {
              e.remove();
            }),
            e
          );
        },
        Direction: function (t, e, n) {
          var o = {
            mount: function () {
              this.value = t.settings.direction;
            },
            resolve: function (t) {
              var e = t.slice(0, 1);
              return this.is("rtl") ? t.split(e).join(E[e]) : t;
            },
            is: function (t) {
              return this.value === t;
            },
            addClass: function () {
              e.Html.root.classList.add(
                t.settings.classes.direction[this.value],
              );
            },
            removeClass: function () {
              e.Html.root.classList.remove(
                t.settings.classes.direction[this.value],
              );
            },
          };
          return (
            g(o, "value", {
              get: function () {
                return o._v;
              },
              set: function (t) {
                -1 < P.indexOf(t)
                  ? (o._v = t)
                  : a("Direction value must be `ltr` or `rtl`");
              },
            }),
            n.on(["destroy", "update"], function () {
              o.removeClass();
            }),
            n.on("update", function () {
              o.mount();
            }),
            n.on(["build.before", "update"], function () {
              o.addClass();
            }),
            o
          );
        },
        Peek: function (n, t, e) {
          var o = {
            mount: function () {
              this.value = n.settings.peek;
            },
          };
          return (
            g(o, "value", {
              get: function () {
                return o._v;
              },
              set: function (t) {
                (m(t)
                  ? ((t.before = b(t.before)), (t.after = b(t.after)))
                  : (t = b(t)),
                  (o._v = t));
              },
            }),
            g(o, "reductor", {
              get: function () {
                var t = o.value,
                  e = n.settings.perView;
                return m(t) ? t.before / e + t.after / e : (2 * t) / e;
              },
            }),
            e.on(["resize", "update"], function () {
              o.mount();
            }),
            o
          );
        },
        Sizes: function (t, o, e) {
          var n = {
            setupSlides: function () {
              for (
                var t = this.slideWidth + "px", e = o.Html.slides, n = 0;
                n < e.length;
                n++
              )
                e[n].style.width = t;
            },
            setupWrapper: function (t) {
              o.Html.wrapper.style.width = this.wrapperSize + "px";
            },
            remove: function () {
              for (var t = o.Html.slides, e = 0; e < t.length; e++)
                t[e].style.width = "";
              o.Html.wrapper.style.width = "";
            },
          };
          return (
            g(n, "length", {
              get: function () {
                return o.Html.slides.length;
              },
            }),
            g(n, "width", {
              get: function () {
                return o.Html.root.offsetWidth;
              },
            }),
            g(n, "wrapperSize", {
              get: function () {
                return n.slideWidth * n.length + o.Gaps.grow + o.Clones.grow;
              },
            }),
            g(n, "slideWidth", {
              get: function () {
                return (
                  n.width / t.settings.perView -
                  o.Peek.reductor -
                  o.Gaps.reductor
                );
              },
            }),
            e.on(["build.before", "resize", "update"], function () {
              (n.setupSlides(), n.setupWrapper());
            }),
            e.on("destroy", function () {
              n.remove();
            }),
            n
          );
        },
        Gaps: function (e, r, t) {
          var n = {
            apply: function (t) {
              for (var e = 0, n = t.length; e < n; e++) {
                var o = t[e].style,
                  i = r.Direction.value;
                ((o[D[i][0]] = 0 !== e ? this.value / 2 + "px" : ""),
                  e !== t.length - 1
                    ? (o[D[i][1]] = this.value / 2 + "px")
                    : (o[D[i][1]] = ""));
              }
            },
            remove: function (t) {
              for (var e = 0, n = t.length; e < n; e++) {
                var o = t[e].style;
                ((o.marginLeft = ""), (o.marginRight = ""));
              }
            },
          };
          return (
            g(n, "value", {
              get: function () {
                return b(e.settings.gap);
              },
            }),
            g(n, "grow", {
              get: function () {
                return n.value * (r.Sizes.length - 1);
              },
            }),
            g(n, "reductor", {
              get: function () {
                var t = e.settings.perView;
                return (n.value * (t - 1)) / t;
              },
            }),
            t.on(
              ["build.after", "update"],
              T(function () {
                n.apply(r.Html.wrapper.children);
              }, 30),
            ),
            t.on("destroy", function () {
              n.remove(r.Html.wrapper.children);
            }),
            n
          );
        },
        Move: function (t, o, i) {
          var e = {
            mount: function () {
              this._o = 0;
            },
            make: function (t) {
              var e = this,
                n = 0 < arguments.length && void 0 !== t ? t : 0;
              ((this.offset = n),
                i.emit("move", { movement: this.value }),
                o.Transition.after(function () {
                  i.emit("move.after", { movement: e.value });
                }));
            },
          };
          return (
            g(e, "offset", {
              get: function () {
                return e._o;
              },
              set: function (t) {
                e._o = h(t) ? 0 : b(t);
              },
            }),
            g(e, "translate", {
              get: function () {
                return o.Sizes.slideWidth * t.index;
              },
            }),
            g(e, "value", {
              get: function () {
                var t = this.offset,
                  e = this.translate;
                return o.Direction.is("rtl") ? e + t : e - t;
              },
            }),
            i.on(["build.before", "run"], function () {
              e.make();
            }),
            e
          );
        },
        Clones: function (v, h, t) {
          var e = {
            mount: function () {
              ((this.items = []),
                v.isType("carousel") && (this.items = this.collect()));
            },
            collect: function (t) {
              for (
                var e = 0 < arguments.length && void 0 !== t ? t : [],
                  n = h.Html.slides,
                  o = v.settings,
                  i = o.perView,
                  r = o.classes,
                  s = i + +!!v.settings.peek,
                  a = n.slice(0, s),
                  u = n.slice(-s),
                  c = 0;
                c < Math.max(1, Math.floor(i / n.length));
                c++
              ) {
                for (var l = 0; l < a.length; l++) {
                  var d = a[l].cloneNode(!0);
                  (d.classList.add(r.cloneSlide), e.push(d));
                }
                for (var f = 0; f < u.length; f++) {
                  var m = u[f].cloneNode(!0);
                  (m.classList.add(r.cloneSlide), e.unshift(m));
                }
              }
              return e;
            },
            append: function () {
              for (
                var t = this.items,
                  e = h.Html,
                  n = e.wrapper,
                  o = e.slides,
                  i = Math.floor(t.length / 2),
                  r = t.slice(0, i).reverse(),
                  s = t.slice(i, t.length),
                  a = h.Sizes.slideWidth + "px",
                  u = 0;
                u < s.length;
                u++
              )
                n.appendChild(s[u]);
              for (var c = 0; c < r.length; c++) n.insertBefore(r[c], o[0]);
              for (var l = 0; l < t.length; l++) t[l].style.width = a;
            },
            remove: function () {
              for (var t = this.items, e = 0; e < t.length; e++)
                h.Html.wrapper.removeChild(t[e]);
            },
          };
          return (
            g(e, "grow", {
              get: function () {
                return (h.Sizes.slideWidth + h.Gaps.value) * e.items.length;
              },
            }),
            t.on("update", function () {
              (e.remove(), e.mount(), e.append());
            }),
            t.on("build.before", function () {
              v.isType("carousel") && e.append();
            }),
            t.on("destroy", function () {
              e.remove();
            }),
            e
          );
        },
        Resize: function (t, e, n) {
          var o = new j(),
            i = {
              mount: function () {
                this.bind();
              },
              bind: function () {
                o.on(
                  "resize",
                  window,
                  T(function () {
                    n.emit("resize");
                  }, t.settings.throttle),
                );
              },
              unbind: function () {
                o.off("resize", window);
              },
            };
          return (
            n.on("destroy", function () {
              (i.unbind(), o.destroy());
            }),
            i
          );
        },
        Build: function (n, o, t) {
          var e = {
            mount: function () {
              (t.emit("build.before"),
                this.typeClass(),
                this.activeClass(),
                t.emit("build.after"));
            },
            typeClass: function () {
              o.Html.root.classList.add(n.settings.classes[n.settings.type]);
            },
            activeClass: function () {
              var e = n.settings.classes,
                t = o.Html.slides[n.index];
              t &&
                (t.classList.add(e.activeSlide),
                x(t).forEach(function (t) {
                  t.classList.remove(e.activeSlide);
                }));
            },
            removeClasses: function () {
              var e = n.settings.classes;
              (o.Html.root.classList.remove(e[n.settings.type]),
                o.Html.slides.forEach(function (t) {
                  t.classList.remove(e.activeSlide);
                }));
            },
          };
          return (
            t.on(["destroy", "update"], function () {
              e.removeClasses();
            }),
            t.on(["resize", "update"], function () {
              e.mount();
            }),
            t.on("move.after", function () {
              e.activeClass();
            }),
            e
          );
        },
        Run: function (r, n, o) {
          var t = {
            mount: function () {
              this._o = !1;
            },
            make: function (t) {
              var e = this;
              r.disabled ||
                (r.disable(),
                (this.move = t),
                o.emit("run.before", this.move),
                this.calculate(),
                o.emit("run", this.move),
                n.Transition.after(function () {
                  (e.isStart() && o.emit("run.start", e.move),
                    e.isEnd() && o.emit("run.end", e.move),
                    (e.isOffset("<") || e.isOffset(">")) &&
                      ((e._o = !1), o.emit("run.offset", e.move)),
                    o.emit("run.after", e.move),
                    r.enable());
                }));
            },
            calculate: function () {
              var t = this.move,
                e = this.length,
                n = t.steps,
                o = t.direction,
                i =
                  (function (t) {
                    return "number" == typeof t;
                  })(b(n)) && 0 !== b(n);
              switch (o) {
                case ">":
                  ">" === n
                    ? (r.index = e)
                    : this.isEnd()
                      ? (r.isType("slider") && !r.settings.rewind) ||
                        ((this._o = !0), (r.index = 0))
                      : i
                        ? (r.index += Math.min(e - r.index, -b(n)))
                        : r.index++;
                  break;
                case "<":
                  "<" === n
                    ? (r.index = 0)
                    : this.isStart()
                      ? (r.isType("slider") && !r.settings.rewind) ||
                        ((this._o = !0), (r.index = e))
                      : i
                        ? (r.index -= Math.min(r.index, b(n)))
                        : r.index--;
                  break;
                case "=":
                  r.index = n;
                  break;
                default:
                  a("Invalid direction pattern [" + o + n + "] has been used");
              }
            },
            isStart: function () {
              return 0 === r.index;
            },
            isEnd: function () {
              return r.index === this.length;
            },
            isOffset: function (t) {
              return this._o && this.move.direction === t;
            },
          };
          return (
            g(t, "move", {
              get: function () {
                return this._m;
              },
              set: function (t) {
                var e = t.substr(1);
                this._m = {
                  direction: t.substr(0, 1),
                  steps: e ? (b(e) ? b(e) : e) : 0,
                };
              },
            }),
            g(t, "length", {
              get: function () {
                var t = r.settings,
                  e = n.Html.slides.length;
                return r.isType("slider") && "center" !== t.focusAt && t.bound
                  ? e - 1 - (b(t.perView) - 1) + b(t.focusAt)
                  : e - 1;
              },
            }),
            g(t, "offset", {
              get: function () {
                return this._o;
              },
            }),
            t
          );
        },
        Swipe: function (f, m, v) {
          var n = new j(),
            h = 0,
            p = 0,
            g = 0,
            o = !1,
            i = !!$ && { passive: !0 },
            t = {
              mount: function () {
                this.bindSwipeStart();
              },
              start: function (t) {
                if (!o && !f.disabled) {
                  this.disable();
                  var e = this.touches(t);
                  ((h = null),
                    (p = b(e.pageX)),
                    (g = b(e.pageY)),
                    this.bindSwipeMove(),
                    this.bindSwipeEnd(),
                    v.emit("swipe.start"));
                }
              },
              move: function (t) {
                if (!f.disabled) {
                  var e = f.settings,
                    n = e.touchAngle,
                    o = e.touchRatio,
                    i = e.classes,
                    r = this.touches(t),
                    s = b(r.pageX) - p,
                    a = b(r.pageY) - g,
                    u = Math.abs(s << 2),
                    c = Math.abs(a << 2),
                    l = Math.sqrt(u + c),
                    d = Math.sqrt(c);
                  if (!((180 * (h = Math.asin(d / l))) / Math.PI < n))
                    return !1;
                  (t.stopPropagation(),
                    m.Move.make(
                      s *
                        (function (t) {
                          return parseFloat(t);
                        })(o),
                    ),
                    m.Html.root.classList.add(i.dragging),
                    v.emit("swipe.move"));
                }
              },
              end: function (t) {
                if (!f.disabled) {
                  var e = f.settings,
                    n = this.touches(t),
                    o = this.threshold(t),
                    i = n.pageX - p,
                    r = (180 * h) / Math.PI,
                    s = Math.round(i / m.Sizes.slideWidth);
                  (this.enable(),
                    o < i && r < e.touchAngle
                      ? (e.perTouch && (s = Math.min(s, b(e.perTouch))),
                        m.Direction.is("rtl") && (s = -s),
                        m.Run.make(m.Direction.resolve("<" + s)))
                      : i < -o && r < e.touchAngle
                        ? (e.perTouch && (s = Math.max(s, -b(e.perTouch))),
                          m.Direction.is("rtl") && (s = -s),
                          m.Run.make(m.Direction.resolve(">" + s)))
                        : m.Move.make(),
                    m.Html.root.classList.remove(e.classes.dragging),
                    this.unbindSwipeMove(),
                    this.unbindSwipeEnd(),
                    v.emit("swipe.end"));
                }
              },
              bindSwipeStart: function () {
                var e = this,
                  t = f.settings;
                (t.swipeThreshold &&
                  n.on(
                    I[0],
                    m.Html.wrapper,
                    function (t) {
                      e.start(t);
                    },
                    i,
                  ),
                  t.dragThreshold &&
                    n.on(
                      I[1],
                      m.Html.wrapper,
                      function (t) {
                        e.start(t);
                      },
                      i,
                    ));
              },
              unbindSwipeStart: function () {
                (n.off(I[0], m.Html.wrapper, i),
                  n.off(I[1], m.Html.wrapper, i));
              },
              bindSwipeMove: function () {
                var e = this;
                n.on(
                  R,
                  m.Html.wrapper,
                  T(function (t) {
                    e.move(t);
                  }, f.settings.throttle),
                  i,
                );
              },
              unbindSwipeMove: function () {
                n.off(R, m.Html.wrapper, i);
              },
              bindSwipeEnd: function () {
                var e = this;
                n.on(F, m.Html.wrapper, function (t) {
                  e.end(t);
                });
              },
              unbindSwipeEnd: function () {
                n.off(F, m.Html.wrapper);
              },
              touches: function (t) {
                return -1 < B.indexOf(t.type)
                  ? t
                  : t.touches[0] || t.changedTouches[0];
              },
              threshold: function (t) {
                var e = f.settings;
                return -1 < B.indexOf(t.type)
                  ? e.dragThreshold
                  : e.swipeThreshold;
              },
              enable: function () {
                return ((o = !1), m.Transition.enable(), this);
              },
              disable: function () {
                return ((o = !0), m.Transition.disable(), this);
              },
            };
          return (
            v.on("build.after", function () {
              m.Html.root.classList.add(f.settings.classes.swipeable);
            }),
            v.on("destroy", function () {
              (t.unbindSwipeStart(),
                t.unbindSwipeMove(),
                t.unbindSwipeEnd(),
                n.destroy());
            }),
            t
          );
        },
        Images: function (t, e, n) {
          var o = new j(),
            i = {
              mount: function () {
                this.bind();
              },
              bind: function () {
                o.on("dragstart", e.Html.wrapper, this.dragstart);
              },
              unbind: function () {
                o.off("dragstart", e.Html.wrapper);
              },
              dragstart: function (t) {
                t.preventDefault();
              },
            };
          return (
            n.on("destroy", function () {
              (i.unbind(), o.destroy());
            }),
            i
          );
        },
        Anchors: function (t, e, n) {
          var o = new j(),
            i = !1,
            r = !1,
            s = {
              mount: function () {
                ((this._a = e.Html.wrapper.querySelectorAll("a")), this.bind());
              },
              bind: function () {
                o.on("click", e.Html.wrapper, this.click);
              },
              unbind: function () {
                o.off("click", e.Html.wrapper);
              },
              click: function (t) {
                r && (t.stopPropagation(), t.preventDefault());
              },
              detach: function () {
                if (((r = !0), !i)) {
                  for (var t = 0; t < this.items.length; t++)
                    ((this.items[t].draggable = !1),
                      this.items[t].setAttribute(
                        "data-href",
                        this.items[t].getAttribute("href"),
                      ),
                      this.items[t].removeAttribute("href"));
                  i = !0;
                }
                return this;
              },
              attach: function () {
                if (((r = !1), i)) {
                  for (var t = 0; t < this.items.length; t++)
                    ((this.items[t].draggable = !0),
                      this.items[t].setAttribute(
                        "href",
                        this.items[t].getAttribute("data-href"),
                      ));
                  i = !1;
                }
                return this;
              },
            };
          return (
            g(s, "items", {
              get: function () {
                return s._a;
              },
            }),
            n.on("swipe.move", function () {
              s.detach();
            }),
            n.on("swipe.end", function () {
              e.Transition.after(function () {
                s.attach();
              });
            }),
            n.on("destroy", function () {
              (s.attach(), s.unbind(), o.destroy());
            }),
            s
          );
        },
        Controls: function (o, e, t) {
          var n = new j(),
            i = !!$ && { passive: !0 },
            r = {
              mount: function () {
                ((this._n = e.Html.root.querySelectorAll(
                  '[data-glide-el="controls[nav]"]',
                )),
                  (this._c = e.Html.root.querySelectorAll(
                    '[data-glide-el^="controls"]',
                  )),
                  this.addBindings());
              },
              setActive: function () {
                for (var t = 0; t < this._n.length; t++)
                  this.addClass(this._n[t].children);
              },
              removeActive: function () {
                for (var t = 0; t < this._n.length; t++)
                  this.removeClass(this._n[t].children);
              },
              addClass: function (t) {
                var e = o.settings,
                  n = t[o.index];
                n &&
                  (n.classList.add(e.classes.activeNav),
                  x(n).forEach(function (t) {
                    t.classList.remove(e.classes.activeNav);
                  }));
              },
              removeClass: function (t) {
                var e = t[o.index];
                e && e.classList.remove(o.settings.classes.activeNav);
              },
              addBindings: function () {
                for (var t = 0; t < this._c.length; t++)
                  this.bind(this._c[t].children);
              },
              removeBindings: function () {
                for (var t = 0; t < this._c.length; t++)
                  this.unbind(this._c[t].children);
              },
              bind: function (t) {
                for (var e = 0; e < t.length; e++)
                  (n.on("click", t[e], this.click),
                    n.on("touchstart", t[e], this.click, i));
              },
              unbind: function (t) {
                for (var e = 0; e < t.length; e++)
                  n.off(["click", "touchstart"], t[e]);
              },
              click: function (t) {
                (t.preventDefault(),
                  e.Run.make(
                    e.Direction.resolve(
                      t.currentTarget.getAttribute("data-glide-dir"),
                    ),
                  ));
              },
            };
          return (
            g(r, "items", {
              get: function () {
                return r._c;
              },
            }),
            t.on(["mount.after", "move.after"], function () {
              r.setActive();
            }),
            t.on("destroy", function () {
              (r.removeBindings(), r.removeActive(), n.destroy());
            }),
            r
          );
        },
        Keyboard: function (t, e, n) {
          var o = new j(),
            i = {
              mount: function () {
                t.settings.keyboard && this.bind();
              },
              bind: function () {
                o.on("keyup", document, this.press);
              },
              unbind: function () {
                o.off("keyup", document);
              },
              press: function (t) {
                (39 === t.keyCode && e.Run.make(e.Direction.resolve(">")),
                  37 === t.keyCode && e.Run.make(e.Direction.resolve("<")));
              },
            };
          return (
            n.on(["destroy", "update"], function () {
              i.unbind();
            }),
            n.on("update", function () {
              i.mount();
            }),
            n.on("destroy", function () {
              o.destroy();
            }),
            i
          );
        },
        Autoplay: function (e, n, t) {
          var o = new j(),
            i = {
              mount: function () {
                (this.start(), e.settings.hoverpause && this.bind());
              },
              start: function () {
                var t = this;
                e.settings.autoplay &&
                  h(this._i) &&
                  (this._i = setInterval(function () {
                    (t.stop(), n.Run.make(">"), t.start());
                  }, this.time));
              },
              stop: function () {
                this._i = clearInterval(this._i);
              },
              bind: function () {
                var t = this;
                (o.on("mouseover", n.Html.root, function () {
                  t.stop();
                }),
                  o.on("mouseout", n.Html.root, function () {
                    t.start();
                  }));
              },
              unbind: function () {
                o.off(["mouseover", "mouseout"], n.Html.root);
              },
            };
          return (
            g(i, "time", {
              get: function () {
                var t = n.Html.slides[e.index].getAttribute(
                  "data-glide-autoplay",
                );
                return b(t || e.settings.autoplay);
              },
            }),
            t.on(["destroy", "update"], function () {
              i.unbind();
            }),
            t.on(
              ["run.before", "pause", "destroy", "swipe.start", "update"],
              function () {
                i.stop();
              },
            ),
            t.on(["run.after", "play", "swipe.end"], function () {
              i.start();
            }),
            t.on("update", function () {
              i.mount();
            }),
            t.on("destroy", function () {
              o.destroy();
            }),
            i
          );
        },
        Breakpoints: function (t, e, n) {
          var o = new j(),
            i = t.settings,
            r = z(i.breakpoints),
            s = d({}, i),
            a = {
              match: function (t) {
                if (void 0 !== window.matchMedia)
                  for (var e in t)
                    if (
                      t.hasOwnProperty(e) &&
                      window.matchMedia("(max-width: " + e + "px)").matches
                    )
                      return t[e];
                return s;
              },
            };
          return (
            d(i, a.match(r)),
            o.on(
              "resize",
              window,
              T(function () {
                t.settings = y(i, a.match(r));
              }, t.settings.throttle),
            ),
            n.on("update", function () {
              ((r = z(r)), (s = d({}, i)));
            }),
            n.on("destroy", function () {
              o.off("resize", window);
            }),
            a
          );
        },
      };
      function V() {
        return (
          s(this, V),
          (function (t, e) {
            if (!t)
              throw new ReferenceError(
                "this hasn't been initialised - super() hasn't been called",
              );
            return !e || ("object" !== i(e) && "function" != typeof e) ? t : e;
          })(
            this,
            (V.__proto__ || Object.getPrototypeOf(V)).apply(this, arguments),
          )
        );
      }
      var G =
        ((function (t, e) {
          if ("function" != typeof e && null !== e)
            throw new TypeError(
              "Super expression must either be null or a function, not " + i(e),
            );
          ((t.prototype = Object.create(e && e.prototype, {
            constructor: {
              value: t,
              enumerable: !1,
              writable: !0,
              configurable: !0,
            },
          })),
            e &&
              (Object.setPrototypeOf
                ? Object.setPrototypeOf(t, e)
                : (t.__proto__ = e)));
        })(V, S),
        c(V, [
          {
            key: "mount",
            value: function (t) {
              var e = 0 < arguments.length && void 0 !== t ? t : {};
              return (function t(e, n, o) {
                null === e && (e = Function.prototype);
                var i = Object.getOwnPropertyDescriptor(e, n);
                if (void 0 === i) {
                  var r = Object.getPrototypeOf(e);
                  return null === r ? void 0 : t(r, n, o);
                }
                if ("value" in i) return i.value;
                var s = i.get;
                return void 0 !== s ? s.call(o) : void 0;
              })(
                V.prototype.__proto__ || Object.getPrototypeOf(V.prototype),
                "mount",
                this,
              ).call(this, d({}, W, e));
            },
          },
        ]),
        V);
      function q(d, l, f) {
        var a = !1;
        function u(t) {
          var e = t.currentPageNumber,
            n = t.currentTotalPages;
          ((t.disableRightMove = e === n - 1), (t.disableLeftMove = 0 === e));
        }
        function m(t, e, n) {
          var o = e.length;
          return t <= e[n] && (n + 1 === o || t > e[n + 1]);
        }
        return {
          setupCarouselControl: function (t, e) {
            (e = e || f).glideControl.totalSlides = t;
            var n = e,
              o = n.breakpointWidth,
              i = n.glideControl,
              r = n.options,
              s = i.defaultNumItemsToMove,
              a = i.currentPageNumber,
              u = d.innerWidth,
              c = o.sort(function (t, e) {
                return e - t;
              });
            (c.some(function (t, e) {
              m(u, c, e) &&
                (i.currentNumSlidesToMove = r.breakpoints[t].perView);
            }),
              (i.currentNumSlidesToMove = i.currentNumSlidesToMove || s));
            var l = Math.ceil(t / i.currentNumSlidesToMove);
            return (
              (i.currentTotalPages = l),
              (i.disableLeftMove = 0 === a),
              (i.disableRightMove = a === l - 1),
              Object.assign({}, i)
            );
          },
          listenToResize: function (t, e, s) {
            if (t && s) {
              var n = (e = e || f),
                o = n.breakpointWidth,
                i = n.glideControl,
                a = n.options,
                u = i.totalSlides,
                c = o.sort(function (t, e) {
                  return e - t;
                });
              c.length;
              t.on("resize", function () {
                var r = d.innerWidth;
                c.some(function (t, e) {
                  if (m(r, c, e)) {
                    var n = s.currentNumSlidesToMove,
                      o = n * s.currentPageNumber;
                    l.debug(
                      "resize event from glide --- $window.innerWidth ---" +
                        d.innerWidth,
                    );
                    var i = a.breakpoints[t].perView;
                    n !== i &&
                      ((s.currentNumSlidesToMove = i),
                      (s.currentPageNumber = Math.floor(o / i)),
                      (s.currentTotalPages = Math.ceil(u / i)));
                  }
                });
              });
            }
          },
          backward: function (t, e) {
            return function () {
              (l.debug("------------- backward ------------------"),
                (function (t, e) {
                  if (t && e && !a) {
                    a = !0;
                    var n = e.currentPageNumber,
                      o = e.currentNumSlidesToMove,
                      i = e.disableLeftMove;
                    if (0 < n && !i) {
                      var r = "=".concat(--n * o);
                      (t.go(r),
                        (e.currentPageNumber = n),
                        l.debug(
                          "------------- setupBackward ------------------ currentPageNumber" +
                            n,
                        ));
                    }
                    u(e);
                  }
                })(t, e));
            };
          },
          forward: function (t, e) {
            return function () {
              (l.debug("------------- forward ------------------"),
                (function (t, e) {
                  if (t && e && !a) {
                    a = !0;
                    var n = e.currentPageNumber,
                      o = e.currentNumSlidesToMove,
                      i = e.currentTotalPages,
                      r = e.disableRightMove;
                    if (n < i - 1 && !r) {
                      var s = "=".concat(++n * o);
                      (t.go(s),
                        (e.currentPageNumber = n),
                        l.debug(
                          "------------- setupForward ------------------ currentPageNumber" +
                            n,
                        ));
                    }
                    u(e);
                  }
                })(t, e));
            };
          },
          initializeGlideCarousel: function (t, e, n) {
            var o = {
              startAt: n.startAt || 0,
              perView: n.defaultNumItemsToMove || 0,
              animationDuration: n.animationDuration || 300,
              perTouch: n.defaultNumItemsToMove || !1,
              swipeThreshold: n.swipeThreshold || 20,
              touchRatio: n.touchRatio || 0.8,
            };
            Object.assign(o, e.options);
            var i = new G(t, o);
            return (
              i.mount(),
              i.on(["move.after"], function () {
                (l.debug("------------- move.after ------------------"),
                  (a = !1));
              }),
              i
            );
          },
        };
      }
      ((q.$inject = ["$window", "$log", "glideConstants"]),
        o.a.service("controlService", q));
      e.default = q;
    },
    4: function (t, e) {
      function r(t) {
        return t.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
      }
      function s(t) {
        return t.split("/").pop().replace(".html", "");
      }
      var n = {
        importFilesUnderPath: function (t) {
          t.keys().forEach(t);
        },
        templateCacheGenerator: function (t, e, o, i) {
          return t.module(e, []).run([
            "$templateCache",
            function (n) {
              (o &&
                o.keys().forEach(function (t) {
                  var e = r(s(t));
                  n.put(e, o(t));
                }),
                i &&
                  i.keys().forEach(function (t) {
                    var e = r(s(t));
                    n.put(
                      e,
                      (function (t) {
                        return t.replace(/<\/?script[^>]*>/gi, "");
                      })(i(t)),
                    );
                  }));
            },
          ]);
        },
      };
      t.exports = n;
    },
    58: function (t, e, n) {
      "use strict";
      var o = n(2),
        i = n.n(o).a.module("glideCarousel", []);
      e.a = i;
    },
    6: function (t, e) {
      t.exports = Roblox;
    },
    80: function (t, e, n) {
      var o = { "./toastDirective.js": 81 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 80));
    },
    81: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(36);
      function i(o) {
        return {
          restrict: "A",
          replace: !0,
          scope: { toastLayout: "=" },
          templateUrl: "toast",
          link: function (n, t, e) {
            ((n.layout = {
              isEnabled: !1,
              isVisible: !1,
              isNeeded: !1,
              text: "",
              timeout: null,
              animationDuration: 200,
              visibilityDelay: 50,
            }),
              n.$watch(
                "toastLayout.isNeeded",
                function (t, e) {
                  t !== e &&
                    t &&
                    !n.layout.timeout &&
                    ((n.layout.text = n.toastLayout.text),
                    (n.layout.isEnabled = t),
                    (n.toastLayout.isNeeded = !1),
                    o(function () {
                      n.layout.isVisible = !0;
                    }, n.layout.visibilityDelay),
                    (n.layout.timeout = o(function () {
                      ((n.layout.isVisible = !1),
                        o(function () {
                          ((n.layout.isEnabled = !1),
                            (n.layout.timeout = null),
                            (n.toastLayout.isNeeded = !1));
                        }, n.layout.animationDuration));
                    }, n.toastLayout.timeout)),
                    (n.toastLayout.isNeeded = !1));
                },
                !0,
              ));
          },
        };
      }
      ((i.$inject = ["$timeout"]), o.a.directive("toast", i), (e.default = i));
    },
    82: function (t, e, n) {
      var o = { "./directives/templates/toast.html": 83 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 82));
    },
    83: function (t, e) {
      t.exports =
        '<div class="toast-container" ng-show="layout.isEnabled" ng-class="{\'toast-visible\': layout.isVisible}"> <div class="toast-content"> <span ng-bind="layout.text"></span> </div> </div>';
    },
    84: function (t, e, n) {
      var o = { "./infiniteScrollDirective.js": 85 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 84));
    },
    85: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(37);
      function i(c, l, d, f) {
        return {
          link: function (n, o, i) {
            var r, e, s, a;
            ((l = angular.element(l)),
              (s = 0),
              null != i.infiniteScrollDistance &&
                n.$watch(i.infiniteScrollDistance, function (t) {
                  return (s = parseInt(t, 10));
                }));
            var t,
              u = !0;
            return (
              (r = !(a = !0)),
              null != i.infiniteScrollDisabled &&
                n.$watch(i.infiniteScrollDisabled, function (t) {
                  if ((a = !t) && r) return ((r = !1), e());
                }),
              (e = function () {
                return (
                  !!u &&
                  ((e = l.height() + l.scrollTop()),
                  (t = o.offset().top + o.height() - e <= l.height() * s) && a
                    ? c.$$phase
                      ? n.$eval(i.infiniteScroll)
                      : n.$apply(i.infiniteScroll)
                    : t
                      ? (r = !0)
                      : void 0)
                );
                var t, e;
              }),
              null !== i.infiniteScrollAlwaysDisabled &&
                (t = n.$watch(
                  function () {
                    return f(i.infiniteScrollAlwaysDisabled)(n);
                  },
                  function (t) {
                    null != t && (u = !t);
                  },
                )),
              l.on("scroll", e),
              n.$on("manualInfiniteScrollCheck", e),
              n.$on("$destroy", function () {
                return (t && t(), l.off("scroll", e));
              }),
              d(function () {
                return (
                  i.infiniteScrollImmediateCheck &&
                    n.$eval(i.infiniteScrollImmediateCheck),
                  e()
                );
              }, 0)
            );
          },
        };
      }
      ((i.$inject = ["$rootScope", "$window", "$timeout", "$parse"]),
        o.a.directive("infiniteScroll", i),
        (e.default = i));
    },
    86: function (t, e, n) {
      var o = { "./verticalMenuDirective.js": 87 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 86));
    },
    87: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(38),
        i = n(6);
      function r() {
        return {
          restrict: "A",
          link: function (t, e, n) {
            var o = t.$watch(n.resetVerticalMenu, function () {
              i.BootstrapWidgets.SetupVerticalMenu();
            });
            t.$on("$destroy", function () {
              o && o();
            });
          },
        };
      }
      (o.a.directive("verticalMenu", r), (e.default = r));
    },
    88: function (t, e, n) {
      var o = { "./modalOptions.js": 89 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 88));
    },
    89: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = {
        params: {
          titleText: "",
          titleIcon: "",
          bodyText: "",
          bodyHtmlUnsafe: "",
          footerText: "",
          footerHtmlUnsafe: "",
          imageUrl: "",
          actionButtonShow: !1,
          actionButtonClass: "btn-secondary-md",
          actionButtonId: "modal-action-button",
          neutralButtonShow: !0,
          neutralButtonClass: "btn-control-md",
          closeButtonShow: !0,
          cssClass: "modal-window",
        },
        defaults: { keyboard: !0, animation: !1 },
        commonTemplateUrl: "cc-modal-template",
        commonController: "modalController",
        layoutParams: {
          modalSelector: ".modal",
          modalContentSelector: ".modal-content",
        },
        backdropStatus: { static: "static" },
        userInteraction: { mouseDown: "mousedown" },
        mainButtonPressed: 0,
      };
      (n(10).a.constant("modalOptions", o), (e.default = o));
    },
    90: function (t, e, n) {
      var o = { "./modalController.js": 91 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 90));
    },
    91: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(10);
      function i(t, e, n, o, i, r) {
        ((e.modalData = i),
          (e.closeActions = r.closeActions),
          (e.close = function (t) {
            o.close(t);
          }),
          (e.dismiss = function () {
            o.dismiss("dismissed");
          }));
      }
      ((i.$inject = [
        "$log",
        "$scope",
        "$sce",
        "$uibModalInstance",
        "modalData",
        "modalService",
      ]),
        o.a.controller("modalController", i),
        (e.default = i));
    },
    92: function (t, e, n) {
      var o = { "./modalService.js": 93, "./modalStringService.js": 94 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 92));
    },
    93: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(2),
        s = n.n(o),
        i = n(10);
      function r(o, i, t) {
        var r = s.a.extend({}, t.params, i.params);
        return {
          open: function (t) {
            var e = s.a.extend({}, r, t),
              n = o.open({
                templateUrl: i.commonTemplateUrl,
                controller: i.commonController,
                windowClass: e.cssClass || "",
                animation: e.animation || i.defaults.animation,
                keyboard: e.keyboard || i.defaults.keyboard,
                backdrop: !!e.closeButtonShow || "static",
                openedClass: e.openedClass || "modal-open-noscroll",
                resolve: { modalData: e },
              });
            return (n.result.then(s.a.noop, s.a.noop), n);
          },
        };
      }
      ((r.$inject = ["$uibModal", "modalOptions", "modalStringService"]),
        i.a.service("modalService", r),
        (e.default = r));
    },
    94: function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(10);
      function i(t) {
        var e = t;
        return {
          params: {
            actionButtonText: e.get("Action.Yes"),
            neutralButtonText: e.get("Action.OK"),
          },
        };
      }
      ((i.$inject = ["languageResource"]),
        o.a.service("modalStringService", i),
        (e.default = i));
    },
    95: function (t, e, n) {
      var o = { "./controllers/templates/commonModal.html": 96 };
      function i(t) {
        var e = r(t);
        return n(e);
      }
      function r(t) {
        var e = o[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((i.keys = function () {
        return Object.keys(o);
      }),
        (i.resolve = r),
        ((t.exports = i).id = 95));
    },
    96: function (t, e) {
      t.exports =
        '<div> <div class="modal-header"> <button type="button" class="close" ng-show="modalData.closeButtonShow" ng-click="dismiss()"> <span class="icon-close"></span> </button> <div class="modal-title"> <span ng-if="modalData.titleIcon && modalData.titleIcon.length > 0" ng-class="modalData.titleIcon"></span> <h4 ng-bind="modalData.titleText"></h4> </div> </div> <div class="modal-body"> <p ng-if="modalData.bodyText" class="body-text text-description" ng-bind="modalData.bodyText"></p> <p ng-if="modalData.bodyHtmlUnsafe" class="body-text text-description" ng-bind-html="modalData.bodyHtmlUnsafe"></p> <div class="img-container modal-image-container" ng-show="modalData.imageUrl && modalData.imageUrl.length > 0"> <img class="modal-thumb" ng-src="{{modalData.imageUrl}}"/> </div> </div> <div class="modal-buttons"> <button type="submit" ng-attr-id="{{modalData.actionButtonId}}" class="modal-button" ng-class="modalData.actionButtonClass" ng-if="modalData.actionButtonShow" ng-click="close(true)" ng-bind="modalData.actionButtonText"></button> <button type="button" class="modal-button" ng-class="modalData.neutralButtonClass" ng-if="modalData.neutralButtonShow" ng-click="dismiss()" ng-bind="modalData.neutralButtonText"></button> </div> <div class="modal-footer" ng-if="modalData.footerText && modalData.footerText.length > 0"> <div class="text-footer" ng-bind="modalData.footerText"></div> </div> <div class="modal-footer" ng-if="modalData.footerHtmlUnsafe && modalData.footerHtmlUnsafe.length > 0"> <div class="text-footer" ng-bind-html="modalData.footerHtmlUnsafe"></div> </div> </div> ';
    },
  });
  //# sourceMappingURL=https://js.rbxcdn.com/e5762b96ebbd2e5ede06-styleGuide.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("StyleGuide");
}
