var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (r) {
    var a = {};
    function n(e) {
      if (a[e]) return a[e].exports;
      var t = (a[e] = { i: e, l: !1, exports: {} });
      return (r[e].call(t.exports, t, t.exports, n), (t.l = !0), t.exports);
    }
    ((n.m = r),
      (n.c = a),
      (n.d = function (e, t, r) {
        n.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
      }),
      (n.r = function (e) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 }));
      }),
      (n.t = function (t, e) {
        if ((1 & e && (t = n(t)), 8 & e)) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (
          (n.r(r),
          Object.defineProperty(r, "default", { enumerable: !0, value: t }),
          2 & e && "string" != typeof t)
        )
          for (var a in t)
            n.d(
              r,
              a,
              function (e) {
                return t[e];
              }.bind(null, a),
            );
        return r;
      }),
      (n.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return (n.d(t, "a", t), t);
      }),
      (n.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (n.p = ""),
      n((n.s = 459)));
  })({
    0: function (e, t, r) {
      "use strict";
      function D(e) {
        return (D =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var B = r(105),
        x = r(106);
      function A() {
        ((this.protocol = null),
          (this.slashes = null),
          (this.auth = null),
          (this.host = null),
          (this.port = null),
          (this.hostname = null),
          (this.hash = null),
          (this.search = null),
          (this.query = null),
          (this.pathname = null),
          (this.path = null),
          (this.href = null));
      }
      ((t.parse = o),
        (t.resolve = function (e, t) {
          return o(e, !1, !0).resolve(t);
        }),
        (t.resolveObject = function (e, t) {
          return e ? o(e, !1, !0).resolveObject(t) : t;
        }),
        (t.format = function (e) {
          x.isString(e) && (e = o(e));
          return e instanceof A ? e.format() : A.prototype.format.call(e);
        }),
        (t.Url = A));
      var E = /^([a-z0-9.+-]+:)/i,
        a = /:[0-9]*$/,
        F = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,
        n = ["{", "}", "|", "\\", "^", "`"].concat([
          "<",
          ">",
          '"',
          "`",
          " ",
          "\r",
          "\n",
          "\t",
        ]),
        N = ["'"].concat(n),
        z = ["%", "/", "?", ";", "#"].concat(N),
        j = ["/", "?", "#"],
        _ = /^[+a-z0-9A-Z_-]{0,63}$/,
        k = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
        M = { javascript: !0, "javascript:": !0 },
        H = { javascript: !0, "javascript:": !0 },
        V = {
          http: !0,
          https: !0,
          ftp: !0,
          gopher: !0,
          file: !0,
          "http:": !0,
          "https:": !0,
          "ftp:": !0,
          "gopher:": !0,
          "file:": !0,
        },
        W = r(107);
      function o(e, t, r) {
        if (e && x.isObject(e) && e instanceof A) return e;
        var a = new A();
        return (a.parse(e, t, r), a);
      }
      ((A.prototype.parse = function (e, t, r) {
        if (!x.isString(e))
          throw new TypeError("Parameter 'url' must be a string, not " + D(e));
        var a = e.indexOf("?"),
          n = -1 !== a && a < e.indexOf("#") ? "?" : "#",
          o = e.split(n);
        o[0] = o[0].replace(/\\/g, "/");
        var s = (e = o.join(n));
        if (((s = s.trim()), !r && 1 === e.split("#").length)) {
          var i = F.exec(s);
          if (i)
            return (
              (this.path = s),
              (this.href = s),
              (this.pathname = i[1]),
              i[2]
                ? ((this.search = i[2]),
                  (this.query = t
                    ? W.parse(this.search.substr(1))
                    : this.search.substr(1)))
                : t && ((this.search = ""), (this.query = {})),
              this
            );
        }
        var u = E.exec(s);
        if (u) {
          var l = (u = u[0]).toLowerCase();
          ((this.protocol = l), (s = s.substr(u.length)));
        }
        if (r || u || s.match(/^\/\/[^@\/]+@[^@\/]+/)) {
          var d = "//" === s.substr(0, 2);
          !d || (u && H[u]) || ((s = s.substr(2)), (this.slashes = !0));
        }
        if (!H[u] && (d || (u && !V[u]))) {
          for (var c, v, p = -1, h = 0; h < j.length; h++) {
            -1 !== (m = s.indexOf(j[h])) && (-1 === p || m < p) && (p = m);
          }
          (-1 !== (v = -1 === p ? s.lastIndexOf("@") : s.lastIndexOf("@", p)) &&
            ((c = s.slice(0, v)),
            (s = s.slice(v + 1)),
            (this.auth = decodeURIComponent(c))),
            (p = -1));
          for (h = 0; h < z.length; h++) {
            var m;
            -1 !== (m = s.indexOf(z[h])) && (-1 === p || m < p) && (p = m);
          }
          (-1 === p && (p = s.length),
            (this.host = s.slice(0, p)),
            (s = s.slice(p)),
            this.parseHost(),
            (this.hostname = this.hostname || ""));
          var g =
            "[" === this.hostname[0] &&
            "]" === this.hostname[this.hostname.length - 1];
          if (!g)
            for (
              var f = this.hostname.split(/\./), G = ((h = 0), f.length);
              h < G;
              h++
            ) {
              var y = f[h];
              if (y && !y.match(_)) {
                for (var I = "", b = 0, P = y.length; b < P; b++)
                  127 < y.charCodeAt(b) ? (I += "x") : (I += y[b]);
                if (!I.match(_)) {
                  var w = f.slice(0, h),
                    C = f.slice(h + 1),
                    q = y.match(k);
                  (q && (w.push(q[1]), C.unshift(q[2])),
                    C.length && (s = "/" + C.join(".") + s),
                    (this.hostname = w.join(".")));
                  break;
                }
              }
            }
          (255 < this.hostname.length
            ? (this.hostname = "")
            : (this.hostname = this.hostname.toLowerCase()),
            g || (this.hostname = B.toASCII(this.hostname)));
          var L = this.port ? ":" + this.port : "",
            A = this.hostname || "";
          ((this.host = A + L),
            (this.href += this.host),
            g &&
              ((this.hostname = this.hostname.substr(
                1,
                this.hostname.length - 2,
              )),
              "/" !== s[0] && (s = "/" + s)));
        }
        if (!M[l])
          for (h = 0, G = N.length; h < G; h++) {
            var T = N[h];
            if (-1 !== s.indexOf(T)) {
              var S = encodeURIComponent(T);
              (S === T && (S = escape(T)), (s = s.split(T).join(S)));
            }
          }
        var R = s.indexOf("#");
        -1 !== R && ((this.hash = s.substr(R)), (s = s.slice(0, R)));
        var U = s.indexOf("?");
        if (
          (-1 !== U
            ? ((this.search = s.substr(U)),
              (this.query = s.substr(U + 1)),
              t && (this.query = W.parse(this.query)),
              (s = s.slice(0, U)))
            : t && ((this.search = ""), (this.query = {})),
          s && (this.pathname = s),
          V[l] && this.hostname && !this.pathname && (this.pathname = "/"),
          this.pathname || this.search)
        ) {
          L = this.pathname || "";
          var O = this.search || "";
          this.path = L + O;
        }
        return ((this.href = this.format()), this);
      }),
        (A.prototype.format = function () {
          var e = this.auth || "";
          e &&
            ((e = (e = encodeURIComponent(e)).replace(/%3A/i, ":")),
            (e += "@"));
          var t = this.protocol || "",
            r = this.pathname || "",
            a = this.hash || "",
            n = !1,
            o = "";
          (this.host
            ? (n = e + this.host)
            : this.hostname &&
              ((n =
                e +
                (-1 === this.hostname.indexOf(":")
                  ? this.hostname
                  : "[" + this.hostname + "]")),
              this.port && (n += ":" + this.port)),
            this.query &&
              x.isObject(this.query) &&
              Object.keys(this.query).length &&
              (o = W.stringify(this.query)));
          var s = this.search || (o && "?" + o) || "";
          return (
            t && ":" !== t.substr(-1) && (t += ":"),
            this.slashes || ((!t || V[t]) && !1 !== n)
              ? ((n = "//" + (n || "")),
                r && "/" !== r.charAt(0) && (r = "/" + r))
              : (n = n || ""),
            a && "#" !== a.charAt(0) && (a = "#" + a),
            s && "?" !== s.charAt(0) && (s = "?" + s),
            t +
              n +
              (r = r.replace(/[?#]/g, function (e) {
                return encodeURIComponent(e);
              })) +
              (s = s.replace("#", "%23")) +
              a
          );
        }),
        (A.prototype.resolve = function (e) {
          return this.resolveObject(o(e, !1, !0)).format();
        }),
        (A.prototype.resolveObject = function (e) {
          if (x.isString(e)) {
            var t = new A();
            (t.parse(e, !1, !0), (e = t));
          }
          for (
            var r = new A(), a = Object.keys(this), n = 0;
            n < a.length;
            n++
          ) {
            var o = a[n];
            r[o] = this[o];
          }
          if (((r.hash = e.hash), "" === e.href))
            return ((r.href = r.format()), r);
          if (e.slashes && !e.protocol) {
            for (var s = Object.keys(e), i = 0; i < s.length; i++) {
              var u = s[i];
              "protocol" !== u && (r[u] = e[u]);
            }
            return (
              V[r.protocol] &&
                r.hostname &&
                !r.pathname &&
                (r.path = r.pathname = "/"),
              (r.href = r.format()),
              r
            );
          }
          if (e.protocol && e.protocol !== r.protocol) {
            if (!V[e.protocol]) {
              for (var l = Object.keys(e), d = 0; d < l.length; d++) {
                var c = l[d];
                r[c] = e[c];
              }
              return ((r.href = r.format()), r);
            }
            if (((r.protocol = e.protocol), e.host || H[e.protocol]))
              r.pathname = e.pathname;
            else {
              for (
                var v = (e.pathname || "").split("/");
                v.length && !(e.host = v.shift());
              );
              (e.host || (e.host = ""),
                e.hostname || (e.hostname = ""),
                "" !== v[0] && v.unshift(""),
                v.length < 2 && v.unshift(""),
                (r.pathname = v.join("/")));
            }
            if (
              ((r.search = e.search),
              (r.query = e.query),
              (r.host = e.host || ""),
              (r.auth = e.auth),
              (r.hostname = e.hostname || e.host),
              (r.port = e.port),
              r.pathname || r.search)
            ) {
              var p = r.pathname || "",
                h = r.search || "";
              r.path = p + h;
            }
            return (
              (r.slashes = r.slashes || e.slashes),
              (r.href = r.format()),
              r
            );
          }
          var m = r.pathname && "/" === r.pathname.charAt(0),
            g = e.host || (e.pathname && "/" === e.pathname.charAt(0)),
            f = g || m || (r.host && e.pathname),
            G = f,
            y = (r.pathname && r.pathname.split("/")) || [],
            I =
              ((v = (e.pathname && e.pathname.split("/")) || []),
              r.protocol && !V[r.protocol]);
          if (
            (I &&
              ((r.hostname = ""),
              (r.port = null),
              r.host && ("" === y[0] ? (y[0] = r.host) : y.unshift(r.host)),
              (r.host = ""),
              e.protocol &&
                ((e.hostname = null),
                (e.port = null),
                e.host && ("" === v[0] ? (v[0] = e.host) : v.unshift(e.host)),
                (e.host = null)),
              (f = f && ("" === v[0] || "" === y[0]))),
            g)
          )
            ((r.host = e.host || "" === e.host ? e.host : r.host),
              (r.hostname =
                e.hostname || "" === e.hostname ? e.hostname : r.hostname),
              (r.search = e.search),
              (r.query = e.query),
              (y = v));
          else if (v.length)
            ((y = y || []).pop(),
              (y = y.concat(v)),
              (r.search = e.search),
              (r.query = e.query));
          else if (!x.isNullOrUndefined(e.search)) {
            if (I)
              ((r.hostname = r.host = y.shift()),
                (q =
                  !!(r.host && 0 < r.host.indexOf("@")) && r.host.split("@")) &&
                  ((r.auth = q.shift()), (r.host = r.hostname = q.shift())));
            return (
              (r.search = e.search),
              (r.query = e.query),
              (x.isNull(r.pathname) && x.isNull(r.search)) ||
                (r.path =
                  (r.pathname ? r.pathname : "") + (r.search ? r.search : "")),
              (r.href = r.format()),
              r
            );
          }
          if (!y.length)
            return (
              (r.pathname = null),
              r.search ? (r.path = "/" + r.search) : (r.path = null),
              (r.href = r.format()),
              r
            );
          for (
            var b = y.slice(-1)[0],
              P =
                ((r.host || e.host || 1 < y.length) &&
                  ("." === b || ".." === b)) ||
                "" === b,
              w = 0,
              C = y.length;
            0 <= C;
            C--
          )
            "." === (b = y[C])
              ? y.splice(C, 1)
              : ".." === b
                ? (y.splice(C, 1), w++)
                : w && (y.splice(C, 1), w--);
          if (!f && !G) for (; w--; ) y.unshift("..");
          (!f ||
            "" === y[0] ||
            (y[0] && "/" === y[0].charAt(0)) ||
            y.unshift(""),
            P && "/" !== y.join("/").substr(-1) && y.push(""));
          var q,
            L = "" === y[0] || (y[0] && "/" === y[0].charAt(0));
          I &&
            ((r.hostname = r.host = L ? "" : y.length ? y.shift() : ""),
            (q = !!(r.host && 0 < r.host.indexOf("@")) && r.host.split("@")) &&
              ((r.auth = q.shift()), (r.host = r.hostname = q.shift())));
          return (
            (f = f || (r.host && y.length)) && !L && y.unshift(""),
            y.length
              ? (r.pathname = y.join("/"))
              : ((r.pathname = null), (r.path = null)),
            (x.isNull(r.pathname) && x.isNull(r.search)) ||
              (r.path =
                (r.pathname ? r.pathname : "") + (r.search ? r.search : "")),
            (r.auth = e.auth || r.auth),
            (r.slashes = r.slashes || e.slashes),
            (r.href = r.format()),
            r
          );
        }),
        (A.prototype.parseHost = function () {
          var e = this.host,
            t = a.exec(e);
          (t &&
            (":" !== (t = t[0]) && (this.port = t.substr(1)),
            (e = e.substr(0, e.length - t.length))),
            e && (this.hostname = e));
        }));
    },
    1: function (e, t, r) {
      "use strict";
      var a,
        n,
        o = r(25),
        s = r.n(o),
        i = r(3);
      (((n = a = a || {})[(n.ok = 200)] = "ok"),
        (n[(n.accepted = 202)] = "accepted"),
        (n[(n.movedPermanently = 301)] = "movedPermanently"),
        (n[(n.badRequest = 400)] = "badRequest"),
        (n[(n.unauthorized = 401)] = "unauthorized"),
        (n[(n.forbidden = 403)] = "forbidden"),
        (n[(n.notFound = 404)] = "notFound"),
        (n[(n.methodNotAllowed = 405)] = "methodNotAllowed"),
        (n[(n.conflict = 409)] = "conflict"),
        (n[(n.payloadTooLarge = 413)] = "payloadTooLarge"),
        (n[(n.tooManyAttempts = 429)] = "tooManyAttempts"),
        (n[(n.serverError = 500)] = "serverError"),
        (n[(n.serviceUnavailable = 503)] = "serviceUnavailable"));
      var u,
        l,
        d = Object.freeze(a);
      (((l = u = u || {}).GET = "get"),
        (l.HEAD = "head"),
        (l.POST = "post"),
        (l.PUT = "put"),
        (l.DELETE = "delete"),
        (l.OPTIONS = "options"),
        (l.PATCH = "patch"));
      var c = Object.freeze(u),
        v = function () {
          return (v =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        },
        p = "x-csrf-token",
        h = d.forbidden,
        m = i.XsrfToken.getToken();
      (s.a.interceptors.request.use(function (e) {
        var t = e.method,
          r = e.noCache,
          a = e.headers,
          n = v({}, e);
        return (
          (t !== c.POST && t !== c.PATCH && t !== c.DELETE) ||
            ((m = m || i.XsrfToken.getToken()),
            r &&
              ((n.headers = a || {}),
              (n["Cache-Control"] = "no-cache, no-store, must-revalidate"),
              (n.Pragma = "no-cache"),
              (n.Expires = 0)),
            (n.headers[p] = m)),
          n
        );
      }, null),
        s.a.interceptors.response.use(null, function (e) {
          var t = e.response;
          if (t) {
            var r = t.status,
              a = t.headers,
              n = t.config,
              o = a[p];
            if (r === h && o)
              return (
                (n.headers[p] = o),
                (m = o),
                i.XsrfToken.setToken(o),
                s.a.request(n)
              );
          }
          return Promise.reject(t);
        }));
      var g = s.a,
        f = function () {
          return (f =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      function G(e, t) {
        return (
          t || Promise.reject(new Error("No config found")),
          g(
            (function (e, t) {
              var r = f({}, e);
              return (
                t.withCredentials && (r.withCredentials = t.withCredentials),
                t.retryable && (r.retryable = t.retryable),
                t.noCache &&
                  (r.headers = {
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    Pragma: "no-cache",
                    Expires: 0,
                  }),
                t.headers && (r.headers = f(f({}, r.headers), t.headers)),
                r
              );
            })(e, t),
          )
        );
      }
      function y(e, t) {
        return G({ method: c.GET, url: e.url, params: t }, e);
      }
      function I(e, t) {
        return G({ method: c.POST, url: e.url, data: t }, e);
      }
      var b = {
        methods: c,
        get: y,
        post: I,
        delete: function (e) {
          return G({ method: c.DELETE, url: e.url }, e);
        },
        patch: function (e, t) {
          return G({ method: c.PATCH, url: e.url, data: t }, e);
        },
        buildBatchPromises: function (e, t, r, a, n) {
          for (
            var o = [], s = 0, i = e.slice(s, t), u = n || "userIds";
            0 < i.length;
          ) {
            var l = {};
            ((l[u] = i),
              a ? o.push(I(r, l)) : o.push(y(r, l)),
              (s += 1),
              (i = e.slice(s * t, s * t + t)));
          }
          return Promise.all(o);
        },
      };
      (r.d(t, "a", function () {
        return g;
      }),
        r.d(t, "d", function () {
          return b;
        }),
        r.d(t, "c", function () {
          return d;
        }),
        r.d(t, "b", function () {
          return c;
        }));
    },
    10: function (e, t, r) {
      "use strict";
      function o(e) {
        return (o =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var n = r(61),
        a = r(88),
        s = Object.prototype.toString;
      function i(e) {
        return "[object Array]" === s.call(e);
      }
      function u(e) {
        return null !== e && "object" === o(e);
      }
      function l(e) {
        return "[object Function]" === s.call(e);
      }
      function d(e, t) {
        if (null != e)
          if (("object" !== o(e) && (e = [e]), i(e)))
            for (var r = 0, a = e.length; r < a; r++) t.call(null, e[r], r, e);
          else
            for (var n in e)
              Object.prototype.hasOwnProperty.call(e, n) &&
                t.call(null, e[n], n, e);
      }
      e.exports = {
        isArray: i,
        isArrayBuffer: function (e) {
          return "[object ArrayBuffer]" === s.call(e);
        },
        isBuffer: a,
        isFormData: function (e) {
          return "undefined" != typeof FormData && e instanceof FormData;
        },
        isArrayBufferView: function (e) {
          return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView
            ? ArrayBuffer.isView(e)
            : e && e.buffer && e.buffer instanceof ArrayBuffer;
        },
        isString: function (e) {
          return "string" == typeof e;
        },
        isNumber: function (e) {
          return "number" == typeof e;
        },
        isObject: u,
        isUndefined: function (e) {
          return void 0 === e;
        },
        isDate: function (e) {
          return "[object Date]" === s.call(e);
        },
        isFile: function (e) {
          return "[object File]" === s.call(e);
        },
        isBlob: function (e) {
          return "[object Blob]" === s.call(e);
        },
        isFunction: l,
        isStream: function (e) {
          return u(e) && l(e.pipe);
        },
        isURLSearchParams: function (e) {
          return (
            "undefined" != typeof URLSearchParams &&
            e instanceof URLSearchParams
          );
        },
        isStandardBrowserEnv: function () {
          return (
            ("undefined" == typeof navigator ||
              "ReactNative" !== navigator.product) &&
            "undefined" != typeof window &&
            "undefined" != typeof document
          );
        },
        forEach: d,
        merge: function r() {
          var a = {};
          function e(e, t) {
            "object" === o(a[t]) && "object" === o(e)
              ? (a[t] = r(a[t], e))
              : (a[t] = e);
          }
          for (var t = 0, n = arguments.length; t < n; t++) d(arguments[t], e);
          return a;
        },
        extend: function (r, e, a) {
          return (
            d(e, function (e, t) {
              r[t] = a && "function" == typeof e ? n(e, a) : e;
            }),
            r
          );
        },
        trim: function (e) {
          return e.replace(/^\s*/, "").replace(/\s*$/, "");
        },
      };
    },
    100: function (e, t, r) {
      "use strict";
      var a = r(10);
      e.exports = function (t, r, e) {
        return (
          a.forEach(e, function (e) {
            t = e(t, r);
          }),
          t
        );
      };
    },
    101: function (e, t, r) {
      "use strict";
      e.exports = function (e) {
        return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e);
      };
    },
    102: function (e, t, r) {
      "use strict";
      e.exports = function (e, t) {
        return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e;
      };
    },
    103: function (e, t, r) {
      "use strict";
      var a = r(65);
      function n(e) {
        if ("function" != typeof e)
          throw new TypeError("executor must be a function.");
        var t;
        this.promise = new Promise(function (e) {
          t = e;
        });
        var r = this;
        e(function (e) {
          r.reason || ((r.reason = new a(e)), t(r.reason));
        });
      }
      ((n.prototype.throwIfRequested = function () {
        if (this.reason) throw this.reason;
      }),
        (n.source = function () {
          var t;
          return {
            token: new n(function (e) {
              t = e;
            }),
            cancel: t,
          };
        }),
        (e.exports = n));
    },
    104: function (e, t, r) {
      "use strict";
      e.exports = function (t) {
        return function (e) {
          return t.apply(null, e);
        };
      };
    },
    105: function (e, x, E) {
      (function (U, O) {
        var D;
        function B(e) {
          return (B =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                })(e);
        }
        /*! https://mths.be/punycode v1.4.1 by @mathias */ !(function (e) {
          var t = "object" == B(x) && x && !x.nodeType && x,
            r = "object" == B(U) && U && !U.nodeType && U,
            a = "object" == (void 0 === O ? "undefined" : B(O)) && O;
          (a.global !== a && a.window !== a && a.self !== a) || (e = a);
          var n,
            o,
            f = 2147483647,
            G = 36,
            y = 1,
            I = 26,
            s = 38,
            i = 700,
            b = 72,
            P = 128,
            w = "-",
            u = /^xn--/,
            l = /[^\x20-\x7E]/,
            d = /[\x2E\u3002\uFF0E\uFF61]/g,
            c = {
              overflow: "Overflow: input needs wider integers to process",
              "not-basic": "Illegal input >= 0x80 (not a basic code point)",
              "invalid-input": "Invalid input",
            },
            v = G - y,
            C = Math.floor,
            q = String.fromCharCode;
          function L(e) {
            throw new RangeError(c[e]);
          }
          function p(e, t) {
            for (var r = e.length, a = []; r--; ) a[r] = t(e[r]);
            return a;
          }
          function h(e, t) {
            var r = e.split("@"),
              a = "";
            return (
              1 < r.length && ((a = r[0] + "@"), (e = r[1])),
              a + p((e = e.replace(d, ".")).split("."), t).join(".")
            );
          }
          function A(e) {
            for (var t, r, a = [], n = 0, o = e.length; n < o; )
              55296 <= (t = e.charCodeAt(n++)) && t <= 56319 && n < o
                ? 56320 == (64512 & (r = e.charCodeAt(n++)))
                  ? a.push(((1023 & t) << 10) + (1023 & r) + 65536)
                  : (a.push(t), n--)
                : a.push(t);
            return a;
          }
          function T(e) {
            return p(e, function (e) {
              var t = "";
              return (
                65535 < e &&
                  ((t += q((((e -= 65536) >>> 10) & 1023) | 55296)),
                  (e = 56320 | (1023 & e))),
                (t += q(e))
              );
            }).join("");
          }
          function S(e, t) {
            return e + 22 + 75 * (e < 26) - ((0 != t) << 5);
          }
          function R(e, t, r) {
            var a = 0;
            for (
              e = r ? C(e / i) : e >> 1, e += C(e / t);
              (v * I) >> 1 < e;
              a += G
            )
              e = C(e / v);
            return C(a + ((v + 1) * e) / (e + s));
          }
          function m(e) {
            var t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v = [],
              p = e.length,
              h = 0,
              m = P,
              g = b;
            for ((r = e.lastIndexOf(w)) < 0 && (r = 0), a = 0; a < r; ++a)
              (128 <= e.charCodeAt(a) && L("not-basic"),
                v.push(e.charCodeAt(a)));
            for (n = 0 < r ? r + 1 : 0; n < p; ) {
              for (
                o = h, s = 1, i = G;
                p <= n && L("invalid-input"),
                  (c = e.charCodeAt(n++)),
                  (G <=
                    (u =
                      c - 48 < 10
                        ? c - 22
                        : c - 65 < 26
                          ? c - 65
                          : c - 97 < 26
                            ? c - 97
                            : G) ||
                    u > C((f - h) / s)) &&
                    L("overflow"),
                  (h += u * s),
                  !(u < (l = i <= g ? y : g + I <= i ? I : i - g));
                i += G
              )
                (s > C(f / (d = G - l)) && L("overflow"), (s *= d));
              ((g = R(h - o, (t = v.length + 1), 0 == o)),
                C(h / t) > f - m && L("overflow"),
                (m += C(h / t)),
                (h %= t),
                v.splice(h++, 0, m));
            }
            return T(v);
          }
          function g(e) {
            var t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v,
              p,
              h,
              m,
              g = [];
            for (v = (e = A(e)).length, t = P, o = b, s = r = 0; s < v; ++s)
              (c = e[s]) < 128 && g.push(q(c));
            for (a = n = g.length, n && g.push(w); a < v; ) {
              for (i = f, s = 0; s < v; ++s)
                t <= (c = e[s]) && c < i && (i = c);
              for (
                i - t > C((f - r) / (p = a + 1)) && L("overflow"),
                  r += (i - t) * p,
                  t = i,
                  s = 0;
                s < v;
                ++s
              )
                if (((c = e[s]) < t && ++r > f && L("overflow"), c == t)) {
                  for (
                    u = r, l = G;
                    !(u < (d = l <= o ? y : o + I <= l ? I : l - o));
                    l += G
                  )
                    ((m = u - d),
                      (h = G - d),
                      g.push(q(S(d + (m % h), 0))),
                      (u = C(m / h)));
                  (g.push(q(S(u, 0))), (o = R(r, p, a == n)), (r = 0), ++a);
                }
              (++r, ++t);
            }
            return g.join("");
          }
          if (
            ((n = {
              version: "1.4.1",
              ucs2: { decode: A, encode: T },
              decode: m,
              encode: g,
              toASCII: function (e) {
                return h(e, function (e) {
                  return l.test(e) ? "xn--" + g(e) : e;
                });
              },
              toUnicode: function (e) {
                return h(e, function (e) {
                  return u.test(e) ? m(e.slice(4).toLowerCase()) : e;
                });
              },
            }),
            "object" == B(E(37)) && E(37))
          )
            void 0 ===
              (D = function () {
                return n;
              }.call(x, E, x, U)) || (U.exports = D);
          else if (t && r)
            if (U.exports == t) r.exports = n;
            else for (o in n) n.hasOwnProperty(o) && (t[o] = n[o]);
          else e.punycode = n;
        })(this);
      }).call(this, E(66)(e), E(52));
    },
    106: function (e, t, r) {
      "use strict";
      function a(e) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      e.exports = {
        isString: function (e) {
          return "string" == typeof e;
        },
        isObject: function (e) {
          return "object" === a(e) && null !== e;
        },
        isNull: function (e) {
          return null === e;
        },
        isNullOrUndefined: function (e) {
          return null == e;
        },
      };
    },
    107: function (e, t, r) {
      "use strict";
      ((t.decode = t.parse = r(108)), (t.encode = t.stringify = r(109)));
    },
    108: function (e, t, r) {
      "use strict";
      e.exports = function (e, t, r, a) {
        ((t = t || "&"), (r = r || "="));
        var n = {};
        if ("string" != typeof e || 0 === e.length) return n;
        var o = /\+/g;
        e = e.split(t);
        var s = 1e3;
        a && "number" == typeof a.maxKeys && (s = a.maxKeys);
        var i,
          u,
          l = e.length;
        0 < s && s < l && (l = s);
        for (var d = 0; d < l; ++d) {
          var c,
            v,
            p,
            h,
            m = e[d].replace(o, "%20"),
            g = m.indexOf(r);
          ((v =
            0 <= g ? ((c = m.substr(0, g)), m.substr(g + 1)) : ((c = m), "")),
            (p = decodeURIComponent(c)),
            (h = decodeURIComponent(v)),
            (i = n),
            (u = p),
            Object.prototype.hasOwnProperty.call(i, u)
              ? f(n[p])
                ? n[p].push(h)
                : (n[p] = [n[p], h])
              : (n[p] = h));
        }
        return n;
      };
      var f =
        Array.isArray ||
        function (e) {
          return "[object Array]" === Object.prototype.toString.call(e);
        };
    },
    109: function (e, t, r) {
      "use strict";
      function o(e) {
        return (o =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      function s(e) {
        switch (o(e)) {
          case "string":
            return e;
          case "boolean":
            return e ? "true" : "false";
          case "number":
            return isFinite(e) ? e : "";
          default:
            return "";
        }
      }
      e.exports = function (r, a, n, e) {
        return (
          (a = a || "&"),
          (n = n || "="),
          null === r && (r = void 0),
          "object" === o(r)
            ? u(l(r), function (e) {
                var t = encodeURIComponent(s(e)) + n;
                return i(r[e])
                  ? u(r[e], function (e) {
                      return t + encodeURIComponent(s(e));
                    }).join(a)
                  : t + encodeURIComponent(s(r[e]));
              }).join(a)
            : e
              ? encodeURIComponent(s(e)) + n + encodeURIComponent(s(r))
              : ""
        );
      };
      var i =
        Array.isArray ||
        function (e) {
          return "[object Array]" === Object.prototype.toString.call(e);
        };
      function u(e, t) {
        if (e.map) return e.map(t);
        for (var r = [], a = 0; a < e.length; a++) r.push(t(e[a], a));
        return r;
      }
      var l =
        Object.keys ||
        function (e) {
          var t = [];
          for (var r in e)
            Object.prototype.hasOwnProperty.call(e, r) && t.push(r);
          return t;
        };
    },
    110: function (e, t, r) {
      "use strict";
      e.exports = function (e) {
        return encodeURIComponent(e).replace(/[!'()*]/g, function (e) {
          return "%".concat(e.charCodeAt(0).toString(16).toUpperCase());
        });
      };
    },
    111: function (e, t, r) {
      "use strict";
      function a(e) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var n = "%[a-f0-9]{2}",
        o = new RegExp(n, "gi"),
        i = new RegExp("(" + n + ")+", "gi");
      function s(e, t) {
        try {
          return decodeURIComponent(e.join(""));
        } catch (e) {}
        if (1 === e.length) return e;
        t = t || 1;
        var r = e.slice(0, t),
          a = e.slice(t);
        return Array.prototype.concat.call([], s(r), s(a));
      }
      function u(t) {
        try {
          return decodeURIComponent(t);
        } catch (e) {
          for (var r = t.match(o), a = 1; a < r.length; a++)
            r = (t = s(r, a).join("")).match(o);
          return t;
        }
      }
      e.exports = function (t) {
        if ("string" != typeof t)
          throw new TypeError(
            "Expected `encodedURI` to be of type `string`, got `" + a(t) + "`",
          );
        try {
          return ((t = t.replace(/\+/g, " ")), decodeURIComponent(t));
        } catch (e) {
          return (function (e) {
            for (
              var t = { "%FE%FF": "��", "%FF%FE": "��" }, r = i.exec(e);
              r;
            ) {
              try {
                t[r[0]] = decodeURIComponent(r[0]);
              } catch (e) {
                var a = u(r[0]);
                a !== r[0] && (t[r[0]] = a);
              }
              r = i.exec(e);
            }
            t["%C2"] = "�";
            for (var n = Object.keys(t), o = 0; o < n.length; o++) {
              var s = n[o];
              e = e.replace(new RegExp(s, "g"), t[s]);
            }
            return e;
          })(t);
        }
      };
    },
    112: function (e, t, r) {
      "use strict";
      e.exports = function (e, t) {
        if ("string" != typeof e || "string" != typeof t)
          throw new TypeError("Expected the arguments to be of type `string`");
        if ("" === t) return [e];
        var r = e.indexOf(t);
        return -1 === r ? [e] : [e.slice(0, r), e.slice(r + t.length)];
      };
    },
    25: function (e, t, r) {
      e.exports = r(87);
    },
    26: function (e, t, r) {
      "use strict";
      function p(e, t) {
        return (
          (function (e) {
            if (Array.isArray(e)) return e;
          })(e) ||
          (function (e, t) {
            var r = [],
              a = !0,
              n = !1,
              o = void 0;
            try {
              for (
                var s, i = e[Symbol.iterator]();
                !(a = (s = i.next()).done) &&
                (r.push(s.value), !t || r.length !== t);
                a = !0
              );
            } catch (e) {
              ((n = !0), (o = e));
            } finally {
              try {
                a || null == i.return || i.return();
              } finally {
                if (n) throw o;
              }
            }
            return r;
          })(e, t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to destructure non-iterable instance",
            );
          })()
        );
      }
      function h(e) {
        return (h =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      function o(e) {
        return (
          (function (e) {
            if (Array.isArray(e)) {
              for (var t = 0, r = new Array(e.length); t < e.length; t++)
                r[t] = e[t];
              return r;
            }
          })(e) ||
          (function (e) {
            if (
              Symbol.iterator in Object(e) ||
              "[object Arguments]" === Object.prototype.toString.call(e)
            )
              return Array.from(e);
          })(e) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to spread non-iterable instance",
            );
          })()
        );
      }
      var a = r(110),
        n = r(111),
        m = r(112);
      function s(e, t) {
        return t.encode ? (t.strict ? a(e) : encodeURIComponent(e)) : e;
      }
      function g(e, t) {
        return t.decode ? n(e) : e;
      }
      function i(e) {
        var t = e.indexOf("#");
        return (-1 !== t && (e = e.slice(0, t)), e);
      }
      function u(e) {
        var t = (e = i(e)).indexOf("?");
        return -1 === t ? "" : e.slice(t + 1);
      }
      function l(e, t) {
        var r = (function (e) {
            var a;
            switch (e.arrayFormat) {
              case "index":
                return function (e, t, r) {
                  ((a = /\[(\d*)\]$/.exec(e)),
                    (e = e.replace(/\[\d*\]$/, "")),
                    a
                      ? (void 0 === r[e] && (r[e] = {}), (r[e][a[1]] = t))
                      : (r[e] = t));
                };
              case "bracket":
                return function (e, t, r) {
                  ((a = /(\[\])$/.exec(e)),
                    (e = e.replace(/\[\]$/, "")),
                    a
                      ? void 0 !== r[e]
                        ? (r[e] = [].concat(r[e], t))
                        : (r[e] = [t])
                      : (r[e] = t));
                };
              case "comma":
                return function (e, t, r) {
                  var a =
                    "string" == typeof t && -1 < t.split("").indexOf(",")
                      ? t.split(",")
                      : t;
                  r[e] = a;
                };
              default:
                return function (e, t, r) {
                  void 0 !== r[e] ? (r[e] = [].concat(r[e], t)) : (r[e] = t);
                };
            }
          })(
            (t = Object.assign(
              { decode: !0, sort: !0, arrayFormat: "none", parseNumbers: !1 },
              t,
            )),
          ),
          a = Object.create(null);
        if ("string" != typeof e) return a;
        if (!(e = e.trim().replace(/^[?#&]/, ""))) return a;
        var n = !0,
          o = !1,
          s = void 0;
        try {
          for (
            var i, u = e.split("&")[Symbol.iterator]();
            !(n = (i = u.next()).done);
            n = !0
          ) {
            var l = i.value,
              d = p(m(l.replace(/\+/g, " "), "="), 2),
              c = d[0],
              v = d[1];
            ((v = void 0 === v ? null : g(v, t)),
              t.parseNumbers && !Number.isNaN(Number(v)) && (v = Number(v)),
              r(g(c, t), v, a));
          }
        } catch (e) {
          ((o = !0), (s = e));
        } finally {
          try {
            n || null == u.return || u.return();
          } finally {
            if (o) throw s;
          }
        }
        return !1 === t.sort
          ? a
          : (!0 === t.sort
              ? Object.keys(a).sort()
              : Object.keys(a).sort(t.sort)
            ).reduce(function (e, t) {
              var r = a[t];
              return (
                Boolean(r) && "object" === h(r) && !Array.isArray(r)
                  ? (e[t] = (function e(t) {
                      return Array.isArray(t)
                        ? t.sort()
                        : "object" === h(t)
                          ? e(Object.keys(t))
                              .sort(function (e, t) {
                                return Number(e) - Number(t);
                              })
                              .map(function (e) {
                                return t[e];
                              })
                          : t;
                    })(r))
                  : (e[t] = r),
                e
              );
            }, Object.create(null));
      }
      ((t.extract = u),
        (t.parse = l),
        (t.stringify = function (r, a) {
          if (!r) return "";
          var n = (function (n) {
              switch (n.arrayFormat) {
                case "index":
                  return function (a) {
                    return function (e, t) {
                      var r = e.length;
                      return void 0 === t
                        ? e
                        : [].concat(
                            o(e),
                            null === t
                              ? [[s(a, n), "[", r, "]"].join("")]
                              : [
                                  [s(a, n), "[", s(r, n), "]=", s(t, n)].join(
                                    "",
                                  ),
                                ],
                          );
                    };
                  };
                case "bracket":
                  return function (r) {
                    return function (e, t) {
                      return void 0 === t
                        ? e
                        : [].concat(
                            o(e),
                            null === t
                              ? [[s(r, n), "[]"].join("")]
                              : [[s(r, n), "[]=", s(t, n)].join("")],
                          );
                    };
                  };
                case "comma":
                  return function (a) {
                    return function (e, t, r) {
                      return null == t || 0 === t.length
                        ? e
                        : 0 === r
                          ? [[s(a, n), "=", s(t, n)].join("")]
                          : [[e, s(t, n)].join(",")];
                    };
                  };
                default:
                  return function (r) {
                    return function (e, t) {
                      return void 0 === t
                        ? e
                        : [].concat(
                            o(e),
                            null === t
                              ? [s(r, n)]
                              : [[s(r, n), "=", s(t, n)].join("")],
                          );
                    };
                  };
              }
            })(
              (a = Object.assign(
                { encode: !0, strict: !0, arrayFormat: "none" },
                a,
              )),
            ),
            e = Object.keys(r);
          return (
            !1 !== a.sort && e.sort(a.sort),
            e
              .map(function (e) {
                var t = r[e];
                return void 0 === t
                  ? ""
                  : null === t
                    ? s(e, a)
                    : Array.isArray(t)
                      ? t.reduce(n(e), []).join("&")
                      : s(e, a) + "=" + s(t, a);
              })
              .filter(function (e) {
                return 0 < e.length;
              })
              .join("&")
          );
        }),
        (t.parseUrl = function (e, t) {
          return { url: i(e).split("?")[0] || "", query: l(u(e), t) };
        }));
    },
    3: function (e, t) {
      e.exports = Roblox;
    },
    36: function (e, t, r) {
      "use strict";
      function a(e) {
        var t =
          0 < arguments.length && void 0 !== e ? e : window.location.search;
        return l.a.parse(t);
      }
      function n(e) {
        var t = 0 < arguments.length && void 0 !== e ? e : {};
        return l.a.stringify(t);
      }
      function o(e) {
        return d.Endpoints ? d.Endpoints.getAbsoluteUrl(e) : e;
      }
      var s = r(0),
        i = r.n(s),
        u = r(26),
        l = r.n(u),
        d = r(3);
      t.a = {
        parseQueryString: a,
        composeQueryString: n,
        getQueryParam: function (e) {
          return a()[e];
        },
        formatUrl: i.a.format,
        resolveUrl: i.a.resolve,
        parseUrl: i.a.parse,
        parseUrlAndQueryString: l.a.parseUrl,
        extractQueryString: l.a.extract,
        getGameDetailReferralUrls: function (e) {
          return o("/games/refer?".concat(n(e)));
        },
        getUrlWithQueries: function (e, t) {
          return o("".concat(e, "?").concat(n(t)));
        },
      };
    },
    37: function (t, e) {
      (function (e) {
        t.exports = e;
      }).call(this, {});
    },
    40: function (i, e, u) {
      "use strict";
      (function (e) {
        var r = u(10),
          a = u(91),
          t = { "Content-Type": "application/x-www-form-urlencoded" };
        function n(e, t) {
          !r.isUndefined(e) &&
            r.isUndefined(e["Content-Type"]) &&
            (e["Content-Type"] = t);
        }
        var o,
          s = {
            adapter:
              ("undefined" != typeof XMLHttpRequest
                ? (o = u(62))
                : void 0 !== e && (o = u(62)),
              o),
            transformRequest: [
              function (e, t) {
                return (
                  a(t, "Content-Type"),
                  r.isFormData(e) ||
                  r.isArrayBuffer(e) ||
                  r.isBuffer(e) ||
                  r.isStream(e) ||
                  r.isFile(e) ||
                  r.isBlob(e)
                    ? e
                    : r.isArrayBufferView(e)
                      ? e.buffer
                      : r.isURLSearchParams(e)
                        ? (n(
                            t,
                            "application/x-www-form-urlencoded;charset=utf-8",
                          ),
                          e.toString())
                        : r.isObject(e)
                          ? (n(t, "application/json;charset=utf-8"),
                            JSON.stringify(e))
                          : e
                );
              },
            ],
            transformResponse: [
              function (e) {
                if ("string" == typeof e)
                  try {
                    e = JSON.parse(e);
                  } catch (e) {}
                return e;
              },
            ],
            timeout: 0,
            xsrfCookieName: "XSRF-TOKEN",
            xsrfHeaderName: "X-XSRF-TOKEN",
            maxContentLength: -1,
            validateStatus: function (e) {
              return 200 <= e && e < 300;
            },
          };
        ((s.headers = {
          common: { Accept: "application/json, text/plain, */*" },
        }),
          r.forEach(["delete", "get", "head"], function (e) {
            s.headers[e] = {};
          }),
          r.forEach(["post", "put", "patch"], function (e) {
            s.headers[e] = r.merge(t);
          }),
          (i.exports = s));
      }).call(this, u(90));
    },
    459: function (e, t, r) {
      "use strict";
      r.r(t);
      function a(e, t, r) {
        (void 0 === t && (t = I),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var n,
        o,
        P = r(0),
        y = r(1),
        i = r(3),
        s = r.n(i),
        u =
          ((n = function (e, t) {
            return (n =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (n(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        I = i.EnvironmentUrls.catalogApi.replace(/\/+$/, ""),
        l = ",",
        c = ((o = Error), u(d, o), d);
      function d(e, t) {
        var r = o.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var v,
        p,
        h,
        m,
        g,
        f,
        G,
        b,
        w,
        C,
        q,
        L,
        A,
        T,
        S,
        R,
        U,
        O,
        D,
        B,
        x,
        E,
        F,
        N,
        z,
        j,
        _,
        k,
        M,
        H,
        V,
        W,
        J,
        K,
        $,
        Q,
        X,
        Y,
        Z,
        ee,
        te,
        re,
        ae,
        ne,
        oe,
        se,
        ie,
        ue,
        le,
        de,
        ce,
        ve,
        pe,
        he,
        me,
        ge,
        fe,
        Ge,
        ye,
        Ie,
        be,
        Pe,
        we,
        Ce,
        qe,
        Le,
        Ae,
        Te,
        Se,
        Re,
        Ue,
        Oe,
        De,
        Be,
        xe,
        Ee,
        Fe,
        Ne,
        ze,
        je,
        _e,
        ke,
        Me,
        He,
        Ve,
        We =
          ((v = function (e, t) {
            return (v =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (v(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        Je = function () {
          return (Je =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      (((h = p = p || {}).Accessories = "Accessories"),
        (h.All = "All"),
        (h.AvatarAnimations = "AvatarAnimations"),
        (h.BackAccessories = "BackAccessories"),
        (h.BodyParts = "BodyParts"),
        (h.Clothing = "Clothing"),
        (h.Collectibles = "Collectibles"),
        (h.FaceAccessories = "FaceAccessories"),
        (h.Faces = "Faces"),
        (h.Featured = "Featured"),
        (h.FrontAccessories = "FrontAccessories"),
        (h.Gear = "Gear"),
        (h.HairAccessories = "HairAccessories"),
        (h.Hats = "Hats"),
        (h.Heads = "Heads"),
        (h.NeckAccessories = "NeckAccessories"),
        (h.Pants = "Pants"),
        (h.Shirts = "Shirts"),
        (h.ShoulderAccessories = "ShoulderAccessories"),
        (h.Tshirts = "Tshirts"),
        (h.WaistAccessories = "WaistAccessories"),
        (h.Bundles = "Bundles"),
        (h.AnimationBundles = "AnimationBundles"),
        (h.EmoteAnimations = "EmoteAnimations"),
        (h.CommunityCreations = "CommunityCreations"),
        (h.Melee = "Melee"),
        (h.Ranged = "Ranged"),
        (h.Explosive = "Explosive"),
        (h.PowerUp = "PowerUp"),
        (h.Navigation = "Navigation"),
        (h.Musical = "Musical"),
        (h.Social = "Social"),
        (h.Building = "Building"),
        (h.Transport = "Transport"),
        ((g = m = m || {}).Accessories = "Accessories"),
        (g.All = "All"),
        (g.AvatarAnimations = "AvatarAnimations"),
        (g.BodyParts = "BodyParts"),
        (g.Clothing = "Clothing"),
        (g.Collectibles = "Collectibles"),
        (g.Featured = "Featured"),
        (g.Gear = "Gear"),
        (g.CommunityCreations = "CommunityCreations"),
        ((G = f = f || {}).User = "User"),
        (G.Group = "Group"),
        ((w = b = b || {}).All = "All"),
        (w.Robux = "Robux"),
        (w.Tickets = "Tickets"),
        (w.CustomRobux = "CustomRobux"),
        (w.CustomTickets = "CustomTickets"),
        (w.Free = "Free"),
        ((q = C = C || {}).Relevance = "Relevance"),
        (q.Favorited = "Favorited"),
        (q.Sales = "Sales"),
        (q.Updated = "Updated"),
        (q.PriceAsc = "PriceAsc"),
        (q.PriceDesc = "PriceDesc"),
        ((A = L = L || {}).Past12Hours = "Past12Hours"),
        (A.PastDay = "PastDay"),
        (A.Past3Days = "Past3Days"),
        (A.PastWeek = "PastWeek"),
        (A.PastMonth = "PastMonth"),
        (A.AllTime = "AllTime"),
        ((S = T = T || {}).Accessories = "Accessories"),
        (S.All = "All"),
        (S.AvatarAnimations = "AvatarAnimations"),
        (S.BodyParts = "BodyParts"),
        (S.Clothing = "Clothing"),
        (S.Collectibles = "Collectibles"),
        (S.Featured = "Featured"),
        (S.Gear = "Gear"),
        (S.CommunityCreations = "CommunityCreations"),
        ((U = R = R || {}).Accessories = "Accessories"),
        (U.All = "All"),
        (U.AvatarAnimations = "AvatarAnimations"),
        (U.BackAccessories = "BackAccessories"),
        (U.BodyParts = "BodyParts"),
        (U.Clothing = "Clothing"),
        (U.Collectibles = "Collectibles"),
        (U.FaceAccessories = "FaceAccessories"),
        (U.Faces = "Faces"),
        (U.Featured = "Featured"),
        (U.FrontAccessories = "FrontAccessories"),
        (U.Gear = "Gear"),
        (U.HairAccessories = "HairAccessories"),
        (U.Hats = "Hats"),
        (U.Heads = "Heads"),
        (U.NeckAccessories = "NeckAccessories"),
        (U.Pants = "Pants"),
        (U.Shirts = "Shirts"),
        (U.ShoulderAccessories = "ShoulderAccessories"),
        (U.Tshirts = "Tshirts"),
        (U.WaistAccessories = "WaistAccessories"),
        (U.Bundles = "Bundles"),
        (U.AnimationBundles = "AnimationBundles"),
        (U.EmoteAnimations = "EmoteAnimations"),
        (U.CommunityCreations = "CommunityCreations"),
        (U.Melee = "Melee"),
        (U.Ranged = "Ranged"),
        (U.Explosive = "Explosive"),
        (U.PowerUp = "PowerUp"),
        (U.Navigation = "Navigation"),
        (U.Musical = "Musical"),
        (U.Social = "Social"),
        (U.Building = "Building"),
        (U.Transport = "Transport"),
        ((D = O = O || {}).Accessories = "Accessories"),
        (D.All = "All"),
        (D.AvatarAnimations = "AvatarAnimations"),
        (D.BodyParts = "BodyParts"),
        (D.Clothing = "Clothing"),
        (D.Collectibles = "Collectibles"),
        (D.Featured = "Featured"),
        (D.Gear = "Gear"),
        (D.CommunityCreations = "CommunityCreations"),
        ((x = B = B || {}).All = "All"),
        (x.Robux = "Robux"),
        (x.Tickets = "Tickets"),
        (x.CustomRobux = "CustomRobux"),
        (x.CustomTickets = "CustomTickets"),
        (x.Free = "Free"),
        ((F = E = E || {}).All = "All"),
        (F.Robux = "Robux"),
        (F.Tickets = "Tickets"),
        (F.CustomRobux = "CustomRobux"),
        (F.CustomTickets = "CustomTickets"),
        (F.Free = "Free"),
        ((z = N = N || {}).All = "All"),
        (z.Robux = "Robux"),
        (z.Tickets = "Tickets"),
        (z.CustomRobux = "CustomRobux"),
        (z.CustomTickets = "CustomTickets"),
        (z.Free = "Free"),
        ((_ = j = j || {}).Asset = "Asset"),
        (_.Bundle = "Bundle"),
        ((M = k = k || {}).Image = "Image"),
        (M.TShirt = "TShirt"),
        (M.Audio = "Audio"),
        (M.Mesh = "Mesh"),
        (M.Lua = "Lua"),
        (M.HTML = "HTML"),
        (M.Text = "Text"),
        (M.Hat = "Hat"),
        (M.Place = "Place"),
        (M.Model = "Model"),
        (M.Shirt = "Shirt"),
        (M.Pants = "Pants"),
        (M.Decal = "Decal"),
        (M.Avatar = "Avatar"),
        (M.Head = "Head"),
        (M.Face = "Face"),
        (M.Gear = "Gear"),
        (M.Badge = "Badge"),
        (M.GroupEmblem = "GroupEmblem"),
        (M.Animation = "Animation"),
        (M.Arms = "Arms"),
        (M.Legs = "Legs"),
        (M.Torso = "Torso"),
        (M.RightArm = "RightArm"),
        (M.LeftArm = "LeftArm"),
        (M.LeftLeg = "LeftLeg"),
        (M.RightLeg = "RightLeg"),
        (M.Package = "Package"),
        (M.YouTubeVideo = "YouTubeVideo"),
        (M.GamePass = "GamePass"),
        (M.App = "App"),
        (M.Code = "Code"),
        (M.Plugin = "Plugin"),
        (M.SolidModel = "SolidModel"),
        (M.MeshPart = "MeshPart"),
        (M.HairAccessory = "HairAccessory"),
        (M.FaceAccessory = "FaceAccessory"),
        (M.NeckAccessory = "NeckAccessory"),
        (M.ShoulderAccessory = "ShoulderAccessory"),
        (M.FrontAccessory = "FrontAccessory"),
        (M.BackAccessory = "BackAccessory"),
        (M.WaistAccessory = "WaistAccessory"),
        (M.ClimbAnimation = "ClimbAnimation"),
        (M.DeathAnimation = "DeathAnimation"),
        (M.FallAnimation = "FallAnimation"),
        (M.IdleAnimation = "IdleAnimation"),
        (M.JumpAnimation = "JumpAnimation"),
        (M.RunAnimation = "RunAnimation"),
        (M.SwimAnimation = "SwimAnimation"),
        (M.WalkAnimation = "WalkAnimation"),
        (M.PoseAnimation = "PoseAnimation"),
        (M.LocalizationTableManifest = "LocalizationTableManifest"),
        (M.LocalizationTableTranslation = "LocalizationTableTranslation"),
        (M.EmoteAnimation = "EmoteAnimation"),
        (M.Video = "Video"),
        ((V = H = H || {}).BodyParts = "BodyParts"),
        (V.AvatarAnimations = "AvatarAnimations"),
        ((J = W = W || {}).All = "All"),
        (J.Tutorial = "Tutorial"),
        (J.Scary = "Scary"),
        (J.TownAndCity = "TownAndCity"),
        (J.War = "War"),
        (J.Funny = "Funny"),
        (J.Fantasy = "Fantasy"),
        (J.Adventure = "Adventure"),
        (J.SciFi = "SciFi"),
        (J.Pirate = "Pirate"),
        (J.FPS = "FPS"),
        (J.RPG = "RPG"),
        (J.Sports = "Sports"),
        (J.Ninja = "Ninja"),
        (J.WildWest = "WildWest"),
        (($ = K = K || {}).New = "New"),
        ($.Sale = "Sale"),
        ($.XboxExclusive = "XboxExclusive"),
        ($.AmazonExclusive = "AmazonExclusive"),
        ($.GooglePlayExclusive = "GooglePlayExclusive"),
        ($.IosExclusive = "IosExclusive"),
        ($.SaleTimer = "SaleTimer"),
        ((X = Q = Q || {}).ThirteenPlus = "ThirteenPlus"),
        (X.LimitedUnique = "LimitedUnique"),
        (X.Limited = "Limited"),
        (X.BuildersClub = "BuildersClub"),
        (X.TurboBuildersClub = "TurboBuildersClub"),
        (X.OutrageousBuildersClub = "OutrageousBuildersClub"),
        (X.Rthro = "Rthro"),
        ((Z = Y = Y || {}).User = "User"),
        (Z.Group = "Group"),
        ((te = ee = ee || {}).Free = "Free"),
        (te.OffSale = "OffSale"),
        (te.NoResellers = "NoResellers"),
        ((ae = re = re || {}).Accessories = "Accessories"),
        (ae.All = "All"),
        (ae.AvatarAnimations = "AvatarAnimations"),
        (ae.BodyParts = "BodyParts"),
        (ae.Clothing = "Clothing"),
        (ae.Collectibles = "Collectibles"),
        (ae.Featured = "Featured"),
        (ae.Gear = "Gear"),
        (ae.CommunityCreations = "CommunityCreations"),
        ((oe = ne = ne || {}).Accessories = "Accessories"),
        (oe.All = "All"),
        (oe.AvatarAnimations = "AvatarAnimations"),
        (oe.BackAccessories = "BackAccessories"),
        (oe.BodyParts = "BodyParts"),
        (oe.Clothing = "Clothing"),
        (oe.Collectibles = "Collectibles"),
        (oe.FaceAccessories = "FaceAccessories"),
        (oe.Faces = "Faces"),
        (oe.Featured = "Featured"),
        (oe.FrontAccessories = "FrontAccessories"),
        (oe.Gear = "Gear"),
        (oe.HairAccessories = "HairAccessories"),
        (oe.Hats = "Hats"),
        (oe.Heads = "Heads"),
        (oe.NeckAccessories = "NeckAccessories"),
        (oe.Pants = "Pants"),
        (oe.Shirts = "Shirts"),
        (oe.ShoulderAccessories = "ShoulderAccessories"),
        (oe.Tshirts = "Tshirts"),
        (oe.WaistAccessories = "WaistAccessories"),
        (oe.Bundles = "Bundles"),
        (oe.AnimationBundles = "AnimationBundles"),
        (oe.EmoteAnimations = "EmoteAnimations"),
        (oe.CommunityCreations = "CommunityCreations"),
        (oe.Melee = "Melee"),
        (oe.Ranged = "Ranged"),
        (oe.Explosive = "Explosive"),
        (oe.PowerUp = "PowerUp"),
        (oe.Navigation = "Navigation"),
        (oe.Musical = "Musical"),
        (oe.Social = "Social"),
        (oe.Building = "Building"),
        (oe.Transport = "Transport"),
        ((ie = se = se || {}).Past12Hours = "Past12Hours"),
        (ie.PastDay = "PastDay"),
        (ie.Past3Days = "Past3Days"),
        (ie.PastWeek = "PastWeek"),
        (ie.PastMonth = "PastMonth"),
        (ie.AllTime = "AllTime"),
        ((le = ue = ue || {}).All = "All"),
        (le.Robux = "Robux"),
        (le.Tickets = "Tickets"),
        (le.CustomRobux = "CustomRobux"),
        (le.CustomTickets = "CustomTickets"),
        (le.Free = "Free"),
        ((ce = de = de || {}).TownAndCity = "TownAndCity"),
        (ce.Medieval = "Medieval"),
        (ce.SciFi = "SciFi"),
        (ce.Fighting = "Fighting"),
        (ce.Horror = "Horror"),
        (ce.Naval = "Naval"),
        (ce.Adventure = "Adventure"),
        (ce.Sports = "Sports"),
        (ce.Comedy = "Comedy"),
        (ce.Western = "Western"),
        (ce.Military = "Military"),
        (ce.Building = "Building"),
        (ce.Fps = "Fps"),
        (ce.Rpg = "Rpg"),
        ((pe = ve = ve || {}).Relevance = "Relevance"),
        (pe.Favorited = "Favorited"),
        (pe.Sales = "Sales"),
        (pe.Updated = "Updated"),
        (pe.PriceAsc = "PriceAsc"),
        (pe.PriceDesc = "PriceDesc"),
        ((me = he = he || {}).User = "User"),
        (me.Group = "Group"),
        ((fe = ge = ge || {}).Asset = "Asset"),
        (fe.Bundle = "Bundle"),
        ((ye = Ge = Ge || {}).Accessories = "Accessories"),
        (ye.All = "All"),
        (ye.AvatarAnimations = "AvatarAnimations"),
        (ye.BodyParts = "BodyParts"),
        (ye.Clothing = "Clothing"),
        (ye.Collectibles = "Collectibles"),
        (ye.Featured = "Featured"),
        (ye.Gear = "Gear"),
        (ye.CommunityCreations = "CommunityCreations"),
        ((be = Ie = Ie || {}).TownAndCity = "TownAndCity"),
        (be.Medieval = "Medieval"),
        (be.SciFi = "SciFi"),
        (be.Fighting = "Fighting"),
        (be.Horror = "Horror"),
        (be.Naval = "Naval"),
        (be.Adventure = "Adventure"),
        (be.Sports = "Sports"),
        (be.Comedy = "Comedy"),
        (be.Western = "Western"),
        (be.Military = "Military"),
        (be.Building = "Building"),
        (be.Fps = "Fps"),
        (be.Rpg = "Rpg"),
        ((we = Pe = Pe || {}).Asset = "Asset"),
        (we.Bundle = "Bundle"),
        ((qe = Ce = Ce || {}).All = "All"),
        (qe.Robux = "Robux"),
        (qe.Tickets = "Tickets"),
        (qe.CustomRobux = "CustomRobux"),
        (qe.CustomTickets = "CustomTickets"),
        (qe.Free = "Free"),
        ((Ae = Le = Le || {}).Past12Hours = "Past12Hours"),
        (Ae.PastDay = "PastDay"),
        (Ae.Past3Days = "Past3Days"),
        (Ae.PastWeek = "PastWeek"),
        (Ae.PastMonth = "PastMonth"),
        (Ae.AllTime = "AllTime"),
        ((Se = Te = Te || {}).Relevance = "Relevance"),
        (Se.Favorited = "Favorited"),
        (Se.Sales = "Sales"),
        (Se.Updated = "Updated"),
        (Se.PriceAsc = "PriceAsc"),
        (Se.PriceDesc = "PriceDesc"),
        ((Ue = Re = Re || {}).Asc = "Asc"),
        (Ue.Desc = "Desc"),
        ((De = Oe = Oe || {}).Accessories = "Accessories"),
        (De.All = "All"),
        (De.AvatarAnimations = "AvatarAnimations"),
        (De.BackAccessories = "BackAccessories"),
        (De.BodyParts = "BodyParts"),
        (De.Clothing = "Clothing"),
        (De.Collectibles = "Collectibles"),
        (De.FaceAccessories = "FaceAccessories"),
        (De.Faces = "Faces"),
        (De.Featured = "Featured"),
        (De.FrontAccessories = "FrontAccessories"),
        (De.Gear = "Gear"),
        (De.HairAccessories = "HairAccessories"),
        (De.Hats = "Hats"),
        (De.Heads = "Heads"),
        (De.NeckAccessories = "NeckAccessories"),
        (De.Pants = "Pants"),
        (De.Shirts = "Shirts"),
        (De.ShoulderAccessories = "ShoulderAccessories"),
        (De.Tshirts = "Tshirts"),
        (De.WaistAccessories = "WaistAccessories"),
        (De.Bundles = "Bundles"),
        (De.AnimationBundles = "AnimationBundles"),
        (De.EmoteAnimations = "EmoteAnimations"),
        (De.CommunityCreations = "CommunityCreations"),
        (De.Melee = "Melee"),
        (De.Ranged = "Ranged"),
        (De.Explosive = "Explosive"),
        (De.PowerUp = "PowerUp"),
        (De.Navigation = "Navigation"),
        (De.Musical = "Musical"),
        (De.Social = "Social"),
        (De.Building = "Building"),
        (De.Transport = "Transport"),
        ((xe = Be = Be || {}).Asc = "Asc"),
        (xe.Desc = "Desc"),
        ((Fe = Ee = Ee || {}).Forward = "Forward"),
        (Fe.Backward = "Backward"),
        ((ze = Ne = Ne || {}).Asc = "Asc"),
        (ze.Desc = "Desc"),
        ((_e = je = je || {}).Forward = "Forward"),
        (_e.Backward = "Backward"),
        ((Me = ke = ke || {}).Asc = "Asc"),
        (Me.Desc = "Desc"),
        ((Ve = He = He || {}).Forward = "Forward"),
        (Ve.Backward = "Backward"));
      function Ke(d) {
        return {
          v1AssetsAssetIdBundlesGet: function (e, t, r, a, n) {
            if ((void 0 === n && (n = {}), null == e))
              throw new c(
                "assetId",
                "Required parameter assetId was null or undefined when calling v1AssetsAssetIdBundlesGet.",
              );
            var o,
              s = "/v1/assets/{assetId}/bundles".replace(
                "{assetId}",
                encodeURIComponent(String(e)),
              ),
              i = P.parse(s, !0);
            d && (o = d.baseOptions);
            var u = Je(Je({ method: "GET" }, o), n),
              l = {};
            return (
              void 0 !== t && (l.sortOrder = t),
              void 0 !== r && (l.limit = r),
              void 0 !== a && (l.cursor = a),
              (i.query = Je(Je(Je({}, i.query), l), n.query)),
              delete i.search,
              (u.headers = Je(Je({}, {}), n.headers)),
              { url: P.format(i), options: u }
            );
          },
          v1BundlesBundleIdDetailsGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1BundlesBundleIdDetailsGet.",
              );
            var r,
              a = "/v1/bundles/{bundleId}/details".replace(
                "{bundleId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            d && (r = d.baseOptions);
            var o = Je(Je({ method: "GET" }, r), t);
            return (
              (n.query = Je(Je(Je({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Je(Je({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1BundlesBundleIdRecommendationsGet: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1BundlesBundleIdRecommendationsGet.",
              );
            var a,
              n = "/v1/bundles/{bundleId}/recommendations".replace(
                "{bundleId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            d && (a = d.baseOptions);
            var s = Je(Je({ method: "GET" }, a), r),
              i = {};
            return (
              void 0 !== t && (i.numItems = t),
              (o.query = Je(Je(Je({}, o.query), i), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1BundlesBundleIdUnpackPost: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1BundlesBundleIdUnpackPost.",
              );
            var r,
              a = "/v1/bundles/{bundleId}/unpack".replace(
                "{bundleId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            d && (r = d.baseOptions);
            var o = Je(Je({ method: "POST" }, r), t);
            return (
              (n.query = Je(Je(Je({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Je(Je({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1BundlesDetailsGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new c(
                "bundleIds",
                "Required parameter bundleIds was null or undefined when calling v1BundlesDetailsGet.",
              );
            var r,
              a = P.parse("/v1/bundles/details", !0);
            d && (r = d.baseOptions);
            var n = Je(Je({ method: "GET" }, r), t),
              o = {};
            return (
              e && (o.bundleIds = e.join(l)),
              (a.query = Je(Je(Je({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = Je(Je({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1UsersUserIdBundlesGet: function (e, t, r, a, n) {
            if ((void 0 === n && (n = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1UsersUserIdBundlesGet.",
              );
            var o,
              s = "/v1/users/{userId}/bundles".replace(
                "{userId}",
                encodeURIComponent(String(e)),
              ),
              i = P.parse(s, !0);
            d && (o = d.baseOptions);
            var u = Je(Je({ method: "GET" }, o), n),
              l = {};
            return (
              void 0 !== t && (l.sortOrder = t),
              void 0 !== r && (l.limit = r),
              void 0 !== a && (l.cursor = a),
              (i.query = Je(Je(Je({}, i.query), l), n.query)),
              delete i.search,
              (u.headers = Je(Je({}, {}), n.headers)),
              { url: P.format(i), options: u }
            );
          },
        };
      }
      function $e(s) {
        return {
          v1AssetsAssetIdBundlesGet: function (e, t, r, a, n) {
            var o = Ke(s).v1AssetsAssetIdBundlesGet(e, t, r, a, n);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, o.options), { url: t + o.url });
              return e.request(r);
            };
          },
          v1BundlesBundleIdDetailsGet: function (e, t) {
            var a = Ke(s).v1BundlesBundleIdDetailsGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1BundlesBundleIdRecommendationsGet: function (e, t, r) {
            var a = Ke(s).v1BundlesBundleIdRecommendationsGet(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1BundlesBundleIdUnpackPost: function (e, t) {
            var a = Ke(s).v1BundlesBundleIdUnpackPost(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1BundlesDetailsGet: function (e, t) {
            var a = Ke(s).v1BundlesDetailsGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1UsersUserIdBundlesGet: function (e, t, r, a, n) {
            var o = Ke(s).v1UsersUserIdBundlesGet(e, t, r, a, n);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, o.options), { url: t + o.url });
              return e.request(r);
            };
          },
        };
      }
      var Qe,
        Xe =
          (We(Ye, (Qe = a)),
          (Ye.prototype.v1AssetsAssetIdBundlesGet = function (e, t, r, a, n) {
            return $e(this.configuration).v1AssetsAssetIdBundlesGet(
              e,
              t,
              r,
              a,
              n,
            )(this.axios, this.basePath);
          }),
          (Ye.prototype.v1BundlesBundleIdDetailsGet = function (e, t) {
            return $e(this.configuration).v1BundlesBundleIdDetailsGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (Ye.prototype.v1BundlesBundleIdRecommendationsGet = function (
            e,
            t,
            r,
          ) {
            return $e(this.configuration).v1BundlesBundleIdRecommendationsGet(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          (Ye.prototype.v1BundlesBundleIdUnpackPost = function (e, t) {
            return $e(this.configuration).v1BundlesBundleIdUnpackPost(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (Ye.prototype.v1BundlesDetailsGet = function (e, t) {
            return $e(this.configuration).v1BundlesDetailsGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (Ye.prototype.v1UsersUserIdBundlesGet = function (e, t, r, a, n) {
            return $e(this.configuration).v1UsersUserIdBundlesGet(
              e,
              t,
              r,
              a,
              n,
            )(this.axios, this.basePath);
          }),
          Ye);
      function Ye() {
        return (null !== Qe && Qe.apply(this, arguments)) || this;
      }
      function Ze(s) {
        return {
          v1CatalogItemsDetailsPost: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new c(
                "model",
                "Required parameter model was null or undefined when calling v1CatalogItemsDetailsPost.",
              );
            var r,
              a = P.parse("/v1/catalog/items/details", !0);
            s && (r = s.baseOptions);
            var n = Je(Je({ method: "POST" }, r), t),
              o = {};
            ((o["Content-Type"] = "application/json"),
              (a.query = Je(Je(Je({}, a.query), {}), t.query)),
              delete a.search,
              (n.headers = Je(Je({}, o), t.headers)));
            return (
              (n.data = JSON.stringify(void 0 !== e ? e : {})),
              { url: P.format(a), options: n }
            );
          },
          v1CatalogMetadataGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/catalog/metadata", !0);
            s && (t = s.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1CatalogSortsGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/catalog/sorts", !0);
            s && (t = s.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function et(r) {
        return {
          v1CatalogItemsDetailsPost: function (e, t) {
            var a = Ze(r).v1CatalogItemsDetailsPost(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1CatalogMetadataGet: function (e) {
            var a = Ze(r).v1CatalogMetadataGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1CatalogSortsGet: function (e) {
            var a = Ze(r).v1CatalogSortsGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var tt,
        rt =
          (We(at, (tt = a)),
          (at.prototype.v1CatalogItemsDetailsPost = function (e, t) {
            return et(this.configuration).v1CatalogItemsDetailsPost(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (at.prototype.v1CatalogMetadataGet = function (e) {
            return et(this.configuration).v1CatalogMetadataGet(e)(
              this.axios,
              this.basePath,
            );
          }),
          (at.prototype.v1CatalogSortsGet = function (e) {
            return et(this.configuration).v1CatalogSortsGet(e)(
              this.axios,
              this.basePath,
            );
          }),
          at);
      function at() {
        return (null !== tt && tt.apply(this, arguments)) || this;
      }
      function nt(n) {
        return {
          v1AssetToCategoryGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/asset-to-category", !0);
            n && (t = n.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1AssetToSubcategoryGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/asset-to-subcategory", !0);
            n && (t = n.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1CategoriesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/categories", !0);
            n && (t = n.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1SubcategoriesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/subcategories", !0);
            n && (t = n.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function ot(t) {
        return {
          v1AssetToCategoryGet: function (e) {
            var a = nt(t).v1AssetToCategoryGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AssetToSubcategoryGet: function (e) {
            var a = nt(t).v1AssetToSubcategoryGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1CategoriesGet: function (e) {
            var a = nt(t).v1CategoriesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1SubcategoriesGet: function (e) {
            var a = nt(t).v1SubcategoriesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var st;
      (We(it, (st = a)),
        (it.prototype.v1AssetToCategoryGet = function (e) {
          return ot(this.configuration).v1AssetToCategoryGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (it.prototype.v1AssetToSubcategoryGet = function (e) {
          return ot(this.configuration).v1AssetToSubcategoryGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (it.prototype.v1CategoriesGet = function (e) {
          return ot(this.configuration).v1CategoriesGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (it.prototype.v1SubcategoriesGet = function (e) {
          return ot(this.configuration).v1SubcategoriesGet(e)(
            this.axios,
            this.basePath,
          );
        }));
      function it() {
        return (null !== st && st.apply(this, arguments)) || this;
      }
      function ut(r) {
        return {
          v1ExclusiveItemsAppStoreTypeBundlesGet: function (e, t) {
            var a = (function (s) {
              return {
                v1ExclusiveItemsAppStoreTypeBundlesGet: function (e, t) {
                  if ((void 0 === t && (t = {}), null == e))
                    throw new c(
                      "appStoreType",
                      "Required parameter appStoreType was null or undefined when calling v1ExclusiveItemsAppStoreTypeBundlesGet.",
                    );
                  var r,
                    a = "/v1/exclusive-items/{appStoreType}/bundles".replace(
                      "{appStoreType}",
                      encodeURIComponent(String(e)),
                    ),
                    n = P.parse(a, !0);
                  s && (r = s.baseOptions);
                  var o = Je(Je({ method: "GET" }, r), t);
                  return (
                    (n.query = Je(Je(Je({}, n.query), {}), t.query)),
                    delete n.search,
                    (o.headers = Je(Je({}, {}), t.headers)),
                    { url: P.format(n), options: o }
                  );
                },
              };
            })(r).v1ExclusiveItemsAppStoreTypeBundlesGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var lt;
      (We(dt, (lt = a)),
        (dt.prototype.v1ExclusiveItemsAppStoreTypeBundlesGet = function (e, t) {
          return ut(this.configuration).v1ExclusiveItemsAppStoreTypeBundlesGet(
            e,
            t,
          )(this.axios, this.basePath);
        }));
      function dt() {
        return (null !== lt && lt.apply(this, arguments)) || this;
      }
      function ct(i) {
        return {
          v1FavoritesAssetsAssetIdCountGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new c(
                "assetId",
                "Required parameter assetId was null or undefined when calling v1FavoritesAssetsAssetIdCountGet.",
              );
            var r,
              a = "/v1/favorites/assets/{assetId}/count".replace(
                "{assetId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            i && (r = i.baseOptions);
            var o = Je(Je({ method: "GET" }, r), t);
            return (
              (n.query = Je(Je(Je({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Je(Je({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1FavoritesBundlesBundleIdCountGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1FavoritesBundlesBundleIdCountGet.",
              );
            var r,
              a = "/v1/favorites/bundles/{bundleId}/count".replace(
                "{bundleId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            i && (r = i.baseOptions);
            var o = Je(Je({ method: "GET" }, r), t);
            return (
              (n.query = Je(Je(Je({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Je(Je({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete.",
              );
            if (null == t)
              throw new c(
                "assetId",
                "Required parameter assetId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete.",
              );
            var a,
              n = "/v1/favorites/users/{userId}/assets/{assetId}/favorite"
                .replace("{userId}", encodeURIComponent(String(e)))
                .replace("{assetId}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            i && (a = i.baseOptions);
            var s = Je(Je({ method: "DELETE" }, a), r);
            return (
              (o.query = Je(Je(Je({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet.",
              );
            if (null == t)
              throw new c(
                "assetId",
                "Required parameter assetId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet.",
              );
            var a,
              n = "/v1/favorites/users/{userId}/assets/{assetId}/favorite"
                .replace("{userId}", encodeURIComponent(String(e)))
                .replace("{assetId}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            i && (a = i.baseOptions);
            var s = Je(Je({ method: "GET" }, a), r);
            return (
              (o.query = Je(Je(Je({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1FavoritesUsersUserIdAssetsAssetIdFavoritePost: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoritePost.",
              );
            if (null == t)
              throw new c(
                "assetId",
                "Required parameter assetId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoritePost.",
              );
            var a,
              n = "/v1/favorites/users/{userId}/assets/{assetId}/favorite"
                .replace("{userId}", encodeURIComponent(String(e)))
                .replace("{assetId}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            i && (a = i.baseOptions);
            var s = Je(Je({ method: "POST" }, a), r);
            return (
              (o.query = Je(Je(Je({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete.",
              );
            if (null == t)
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete.",
              );
            var a,
              n = "/v1/favorites/users/{userId}/bundles/{bundleId}/favorite"
                .replace("{userId}", encodeURIComponent(String(e)))
                .replace("{bundleId}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            i && (a = i.baseOptions);
            var s = Je(Je({ method: "DELETE" }, a), r);
            return (
              (o.query = Je(Je(Je({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet.",
              );
            if (null == t)
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet.",
              );
            var a,
              n = "/v1/favorites/users/{userId}/bundles/{bundleId}/favorite"
                .replace("{userId}", encodeURIComponent(String(e)))
                .replace("{bundleId}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            i && (a = i.baseOptions);
            var s = Je(Je({ method: "GET" }, a), r);
            return (
              (o.query = Je(Je(Je({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1FavoritesUsersUserIdBundlesBundleIdFavoritePost: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new c(
                "userId",
                "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoritePost.",
              );
            if (null == t)
              throw new c(
                "bundleId",
                "Required parameter bundleId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoritePost.",
              );
            var a,
              n = "/v1/favorites/users/{userId}/bundles/{bundleId}/favorite"
                .replace("{userId}", encodeURIComponent(String(e)))
                .replace("{bundleId}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            i && (a = i.baseOptions);
            var s = Je(Je({ method: "POST" }, a), r);
            return (
              (o.query = Je(Je(Je({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Je(Je({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
        };
      }
      function vt(n) {
        return {
          v1FavoritesAssetsAssetIdCountGet: function (e, t) {
            var a = ct(n).v1FavoritesAssetsAssetIdCountGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesBundlesBundleIdCountGet: function (e, t) {
            var a = ct(n).v1FavoritesBundlesBundleIdCountGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete: function (
            e,
            t,
            r,
          ) {
            var a = ct(n).v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet: function (e, t, r) {
            var a = ct(n).v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesUsersUserIdAssetsAssetIdFavoritePost: function (e, t, r) {
            var a = ct(n).v1FavoritesUsersUserIdAssetsAssetIdFavoritePost(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete: function (
            e,
            t,
            r,
          ) {
            var a = ct(n).v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet: function (e, t, r) {
            var a = ct(n).v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1FavoritesUsersUserIdBundlesBundleIdFavoritePost: function (
            e,
            t,
            r,
          ) {
            var a = ct(n).v1FavoritesUsersUserIdBundlesBundleIdFavoritePost(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var pt;
      (We(ht, (pt = a)),
        (ht.prototype.v1FavoritesAssetsAssetIdCountGet = function (e, t) {
          return vt(this.configuration).v1FavoritesAssetsAssetIdCountGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (ht.prototype.v1FavoritesBundlesBundleIdCountGet = function (e, t) {
          return vt(this.configuration).v1FavoritesBundlesBundleIdCountGet(
            e,
            t,
          )(this.axios, this.basePath);
        }),
        (ht.prototype.v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete =
          function (e, t, r) {
            return vt(
              this.configuration,
            ).v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (ht.prototype.v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet =
          function (e, t, r) {
            return vt(
              this.configuration,
            ).v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (ht.prototype.v1FavoritesUsersUserIdAssetsAssetIdFavoritePost =
          function (e, t, r) {
            return vt(
              this.configuration,
            ).v1FavoritesUsersUserIdAssetsAssetIdFavoritePost(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (ht.prototype.v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete =
          function (e, t, r) {
            return vt(
              this.configuration,
            ).v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (ht.prototype.v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet =
          function (e, t, r) {
            return vt(
              this.configuration,
            ).v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (ht.prototype.v1FavoritesUsersUserIdBundlesBundleIdFavoritePost =
          function (e, t, r) {
            return vt(
              this.configuration,
            ).v1FavoritesUsersUserIdBundlesBundleIdFavoritePost(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }));
      function ht() {
        return (null !== pt && pt.apply(this, arguments)) || this;
      }
      function mt(r) {
        return {
          v1RecommendationsMetadataGet: function (e, t) {
            var a = (function (s) {
              return {
                v1RecommendationsMetadataGet: function (e, t) {
                  void 0 === t && (t = {});
                  var r,
                    a = P.parse("/v1/recommendations/metadata", !0);
                  s && (r = s.baseOptions);
                  var n = Je(Je({ method: "GET" }, r), t),
                    o = {};
                  return (
                    void 0 !== e && (o.page = e),
                    (a.query = Je(Je(Je({}, a.query), o), t.query)),
                    delete a.search,
                    (n.headers = Je(Je({}, {}), t.headers)),
                    { url: P.format(a), options: n }
                  );
                },
              };
            })(r).v1RecommendationsMetadataGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var gt;
      (We(ft, (gt = a)),
        (ft.prototype.v1RecommendationsMetadataGet = function (e, t) {
          return mt(this.configuration).v1RecommendationsMetadataGet(e, t)(
            this.axios,
            this.basePath,
          );
        }));
      function ft() {
        return (null !== gt && gt.apply(this, arguments)) || this;
      }
      function Gt(b) {
        return {
          v1SearchItemsDetailsGet: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
            g,
          ) {
            void 0 === g && (g = {});
            var f,
              G = P.parse("/v1/search/items/details", !0);
            b && (f = b.baseOptions);
            var y = Je(Je({ method: "GET" }, f), g),
              I = {};
            return (
              void 0 !== e && (I["model.category"] = e),
              void 0 !== t && (I["model.subcategory"] = t),
              void 0 !== r && (I["model.sortAggregation"] = r),
              void 0 !== a && (I["model.sortCurrency"] = a),
              n && (I["model.genres"] = n),
              void 0 !== o && (I["model.sortType"] = o),
              void 0 !== s && (I["model.creatorType"] = s),
              void 0 !== i && (I["model.creatorTargetId"] = i),
              void 0 !== u && (I["model.creatorName"] = u),
              void 0 !== l && (I["model.maxPrice"] = l),
              void 0 !== d && (I["model.minPrice"] = d),
              void 0 !== c && (I["model.keyword"] = c),
              void 0 !== v && (I["model.includeNotForSale"] = v),
              void 0 !== p && (I.sortOrder = p),
              void 0 !== h && (I.limit = h),
              void 0 !== m && (I.cursor = m),
              (G.query = Je(Je(Je({}, G.query), I), g.query)),
              delete G.search,
              (y.headers = Je(Je({}, {}), g.headers)),
              { url: P.format(G), options: y }
            );
          },
          v1SearchItemsGet: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
            g,
          ) {
            void 0 === g && (g = {});
            var f,
              G = P.parse("/v1/search/items", !0);
            b && (f = b.baseOptions);
            var y = Je(Je({ method: "GET" }, f), g),
              I = {};
            return (
              void 0 !== e && (I["model.category"] = e),
              void 0 !== t && (I["model.subcategory"] = t),
              void 0 !== r && (I["model.sortAggregation"] = r),
              void 0 !== a && (I["model.sortCurrency"] = a),
              n && (I["model.genres"] = n),
              void 0 !== o && (I["model.sortType"] = o),
              void 0 !== s && (I["model.creatorType"] = s),
              void 0 !== i && (I["model.creatorTargetId"] = i),
              void 0 !== u && (I["model.creatorName"] = u),
              void 0 !== l && (I["model.maxPrice"] = l),
              void 0 !== d && (I["model.minPrice"] = d),
              void 0 !== c && (I["model.keyword"] = c),
              void 0 !== v && (I["model.includeNotForSale"] = v),
              void 0 !== p && (I.sortOrder = p),
              void 0 !== h && (I.limit = h),
              void 0 !== m && (I.cursor = m),
              (G.query = Je(Je(Je({}, G.query), I), g.query)),
              delete G.search,
              (y.headers = Je(Je({}, {}), g.headers)),
              { url: P.format(G), options: y }
            );
          },
          v1SearchNavigationMenuItemsGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/search/navigation-menu-items", !0);
            b && (t = b.baseOptions);
            var a = Je(Je({ method: "GET" }, t), e);
            return (
              (r.query = Je(Je(Je({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Je(Je({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function yt(G) {
        return {
          v1SearchItemsDetailsGet: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
            g,
          ) {
            var f = Gt(G).v1SearchItemsDetailsGet(
              e,
              t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v,
              p,
              h,
              m,
              g,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, f.options), { url: t + f.url });
              return e.request(r);
            };
          },
          v1SearchItemsGet: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
            g,
          ) {
            var f = Gt(G).v1SearchItemsGet(
              e,
              t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v,
              p,
              h,
              m,
              g,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, f.options), { url: t + f.url });
              return e.request(r);
            };
          },
          v1SearchNavigationMenuItemsGet: function (e) {
            var a = Gt(G).v1SearchNavigationMenuItemsGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = I));
              var r = Je(Je({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var It;
      (We(bt, (It = a)),
        (bt.prototype.v1SearchItemsDetailsGet = function (
          e,
          t,
          r,
          a,
          n,
          o,
          s,
          i,
          u,
          l,
          d,
          c,
          v,
          p,
          h,
          m,
          g,
        ) {
          return yt(this.configuration).v1SearchItemsDetailsGet(
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
            g,
          )(this.axios, this.basePath);
        }),
        (bt.prototype.v1SearchItemsGet = function (
          e,
          t,
          r,
          a,
          n,
          o,
          s,
          i,
          u,
          l,
          d,
          c,
          v,
          p,
          h,
          m,
          g,
        ) {
          return yt(this.configuration).v1SearchItemsGet(
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
            g,
          )(this.axios, this.basePath);
        }),
        (bt.prototype.v1SearchNavigationMenuItemsGet = function (e) {
          return yt(this.configuration).v1SearchNavigationMenuItemsGet(e)(
            this.axios,
            this.basePath,
          );
        }));
      function bt() {
        return (null !== It && It.apply(this, arguments)) || this;
      }
      function Pt(e, t, r) {
        (void 0 === t && (t = St),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var wt,
        Ct,
        qt = new Xe(),
        Lt = new rt(),
        At = {
          getRecommendations: function (e, t) {
            return qt.v1BundlesBundleIdRecommendationsGet(e, t, {
              withCredentials: !0,
            });
          },
          postItemDetails: function (e) {
            return Lt.v1CatalogItemsDetailsPost(e, { withCredentials: !0 });
          },
        },
        Tt =
          ((wt = function (e, t) {
            return (wt =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (wt(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        St = i.EnvironmentUrls.gameInternationalizationApi.replace(/\/+$/, ""),
        Rt = ((Ct = Error), Tt(Ut, Ct), Ut);
      function Ut(e, t) {
        var r = Ct.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var Ot,
        Dt,
        Bt,
        xt,
        Et,
        Ft,
        Nt,
        zt,
        jt,
        _t,
        kt,
        Mt,
        Ht,
        Vt,
        Wt,
        Jt,
        Kt,
        $t,
        Qt,
        Xt,
        Yt,
        Zt,
        er,
        tr,
        rr,
        ar,
        nr,
        or,
        sr,
        ir,
        ur,
        lr,
        dr,
        cr,
        vr,
        pr,
        hr,
        mr,
        gr,
        fr,
        Gr,
        yr =
          ((Ot = function (e, t) {
            return (Ot =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Ot(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        Ir = function () {
          return (Ir =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      (((Bt = Dt = Dt || {}).User = "User"),
        (Bt.Group = "Group"),
        ((Et = xt = xt || {}).Asc = "Asc"),
        (Et.Desc = "Desc"),
        ((Nt = Ft = Ft || {}).Approved = "Approved"),
        (Nt.PendingReview = "PendingReview"),
        (Nt.UnAvailable = "UnAvailable"),
        (Nt.Rejected = "Rejected"),
        (Nt.Error = "Error"),
        ((jt = zt = zt || {}).Approved = "Approved"),
        (jt.PendingReview = "PendingReview"),
        (jt.UnAvailable = "UnAvailable"),
        (jt.Rejected = "Rejected"),
        (jt.Error = "Error"),
        ((kt = _t = _t || {}).Approved = "Approved"),
        (kt.PendingReview = "PendingReview"),
        (kt.UnAvailable = "UnAvailable"),
        (kt.Rejected = "Rejected"),
        (kt.Error = "Error"),
        ((Ht = Mt = Mt || {}).Approved = "Approved"),
        (Ht.PendingReview = "PendingReview"),
        (Ht.UnAvailable = "UnAvailable"),
        (Ht.Rejected = "Rejected"),
        (Ht.Error = "Error"),
        ((Wt = Vt = Vt || {}).Name = "Name"),
        (Wt.Description = "Description"),
        ((Kt = Jt = Jt || {}).Asc = "Asc"),
        (Kt.Desc = "Desc"),
        ((Qt = $t = $t || {}).User = "User"),
        (Qt.Group = "Group"),
        ((Yt = Xt = Xt || {}).Language = "Language"),
        (Yt.Locale = "Locale"),
        ((er = Zt = Zt || {}).Language = "Language"),
        (er.Locale = "Locale"),
        ((rr = tr = tr || {}).Language = "Language"),
        (rr.Locale = "Locale"),
        ((nr = ar = ar || {}).Approved = "Approved"),
        (nr.PendingReview = "PendingReview"),
        (nr.UnAvailable = "UnAvailable"),
        (nr.Rejected = "Rejected"),
        (nr.Error = "Error"),
        ((sr = or = or || {}).Language = "Language"),
        (sr.Locale = "Locale"),
        ((ur = ir = ir || {}).GameTranslationStatus = "GameTranslationStatus"),
        (ur.GameTranslationStatusForTranslatorGroup =
          "GameTranslationStatusForTranslatorGroup"),
        (ur.GameTranslationStatusForTranslator =
          "GameTranslationStatusForTranslator"),
        (ur.Test = "Test"),
        ((dr = lr = lr || {}).InProgress = "inProgress"),
        (dr.Ready = "ready"),
        (dr.Unavailable = "unavailable"),
        ((vr = cr = cr || {}).LanguageOrLocaleSupportedForGame =
          "LanguageOrLocaleSupportedForGame"),
        (vr.LanguageOrLocaleNotSupportedForGame =
          "LanguageOrLocaleNotSupportedForGame"),
        (vr.LanguageOrLocaleIsSource = "LanguageOrLocaleIsSource"),
        (vr.InsufficientPermission = "InsufficientPermission"),
        (vr.GameDoesNotExist = "GameDoesNotExist"),
        (vr.GameDoesNotHaveTable = "GameDoesNotHaveTable"),
        (vr.UnknownError = "UnknownError"),
        ((hr = pr = pr || {}).Success = "Success"),
        (hr.LanguageOrLocaleNotSupportedForGame =
          "LanguageOrLocaleNotSupportedForGame"),
        ((gr = mr = mr || {}).Language = "Language"),
        (gr.Locale = "Locale"),
        ((Gr = fr = fr || {}).User = "User"),
        (Gr.Automation = "Automation"));
      function br(u) {
        return {
          v1AutolocalizationGamesGameIdAutolocalizationtablePatch: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdAutolocalizationtablePatch.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdAutolocalizationtablePatch.",
              );
            var a,
              n =
                "/v1/autolocalization/games/{gameId}/autolocalizationtable".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1AutolocalizationGamesGameIdAutolocalizationtablePost: function (
            e,
            t,
          ) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdAutolocalizationtablePost.",
              );
            var r,
              a =
                "/v1/autolocalization/games/{gameId}/autolocalizationtable".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "POST" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost.",
              );
            var a,
              n =
                "/v1/autolocalization/games/{gameId}/autoscrape-cleanup-request".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "POST" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1AutolocalizationGamesGameIdGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdGet.",
              );
            var r,
              a = "/v1/autolocalization/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1AutolocalizationGamesGameIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdPatch.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdPatch.",
              );
            var a,
              n = "/v1/autolocalization/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1AutolocalizationGamesGameIdSettingsPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdSettingsPatch.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdSettingsPatch.",
              );
            var a,
              n = "/v1/autolocalization/games/{gameId}/settings".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1AutolocalizationMetadataGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/autolocalization/metadata", !0);
            u && (t = u.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function Pr(n) {
        return {
          v1AutolocalizationGamesGameIdAutolocalizationtablePatch: function (
            e,
            t,
            r,
          ) {
            var a = br(
              n,
            ).v1AutolocalizationGamesGameIdAutolocalizationtablePatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutolocalizationGamesGameIdAutolocalizationtablePost: function (
            e,
            t,
          ) {
            var a = br(
              n,
            ).v1AutolocalizationGamesGameIdAutolocalizationtablePost(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost: function (
            e,
            t,
            r,
          ) {
            var a = br(
              n,
            ).v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutolocalizationGamesGameIdGet: function (e, t) {
            var a = br(n).v1AutolocalizationGamesGameIdGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutolocalizationGamesGameIdPatch: function (e, t, r) {
            var a = br(n).v1AutolocalizationGamesGameIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutolocalizationGamesGameIdSettingsPatch: function (e, t, r) {
            var a = br(n).v1AutolocalizationGamesGameIdSettingsPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutolocalizationMetadataGet: function (e) {
            var a = br(n).v1AutolocalizationMetadataGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var wr,
        Cr =
          (yr(qr, (wr = Pt)),
          (qr.prototype.v1AutolocalizationGamesGameIdAutolocalizationtablePatch =
            function (e, t, r) {
              return Pr(
                this.configuration,
              ).v1AutolocalizationGamesGameIdAutolocalizationtablePatch(
                e,
                t,
                r,
              )(this.axios, this.basePath);
            }),
          (qr.prototype.v1AutolocalizationGamesGameIdAutolocalizationtablePost =
            function (e, t) {
              return Pr(
                this.configuration,
              ).v1AutolocalizationGamesGameIdAutolocalizationtablePost(e, t)(
                this.axios,
                this.basePath,
              );
            }),
          (qr.prototype.v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost =
            function (e, t, r) {
              return Pr(
                this.configuration,
              ).v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost(
                e,
                t,
                r,
              )(this.axios, this.basePath);
            }),
          (qr.prototype.v1AutolocalizationGamesGameIdGet = function (e, t) {
            return Pr(this.configuration).v1AutolocalizationGamesGameIdGet(
              e,
              t,
            )(this.axios, this.basePath);
          }),
          (qr.prototype.v1AutolocalizationGamesGameIdPatch = function (
            e,
            t,
            r,
          ) {
            return Pr(this.configuration).v1AutolocalizationGamesGameIdPatch(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          (qr.prototype.v1AutolocalizationGamesGameIdSettingsPatch = function (
            e,
            t,
            r,
          ) {
            return Pr(
              this.configuration,
            ).v1AutolocalizationGamesGameIdSettingsPatch(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          (qr.prototype.v1AutolocalizationMetadataGet = function (e) {
            return Pr(this.configuration).v1AutolocalizationMetadataGet(e)(
              this.axios,
              this.basePath,
            );
          }),
          qr);
      function qr() {
        return (null !== wr && wr.apply(this, arguments)) || this;
      }
      function Lr(u) {
        return {
          v1AutomaticTranslationGamesGameIdFeatureStatusGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutomaticTranslationGamesGameIdFeatureStatusGet.",
              );
            var r,
              a =
                "/v1/automatic-translation/games/{gameId}/feature-status".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1AutomaticTranslationGamesGameIdQuotaGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1AutomaticTranslationGamesGameIdQuotaGet.",
              );
            var r,
              a = "/v1/automatic-translation/games/{gameId}/quota".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet:
            function (e, t, r) {
              if ((void 0 === r && (r = {}), null == e))
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet.",
                );
              var a,
                n =
                  "/v1/automatic-translation/languages/{languageCode}/target-languages".replace(
                    "{languageCode}",
                    encodeURIComponent(String(e)),
                  ),
                o = P.parse(n, !0);
              u && (a = u.baseOptions);
              var s = Ir(Ir({ method: "GET" }, a), r),
                i = {};
              return (
                t && (i.targetLanguages = t),
                (o.query = Ir(Ir(Ir({}, o.query), i), r.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, {}), r.headers)),
                { url: P.format(o), options: s }
              );
            },
        };
      }
      function Ar(n) {
        return {
          v1AutomaticTranslationGamesGameIdFeatureStatusGet: function (e, t) {
            var a = Lr(n).v1AutomaticTranslationGamesGameIdFeatureStatusGet(
              e,
              t,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutomaticTranslationGamesGameIdQuotaGet: function (e, t) {
            var a = Lr(n).v1AutomaticTranslationGamesGameIdQuotaGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet:
            function (e, t, r) {
              var a = Lr(
                n,
              ).v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet(
                e,
                t,
                r,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
        };
      }
      var Tr,
        Sr =
          (yr(Rr, (Tr = Pt)),
          (Rr.prototype.v1AutomaticTranslationGamesGameIdFeatureStatusGet =
            function (e, t) {
              return Ar(
                this.configuration,
              ).v1AutomaticTranslationGamesGameIdFeatureStatusGet(e, t)(
                this.axios,
                this.basePath,
              );
            }),
          (Rr.prototype.v1AutomaticTranslationGamesGameIdQuotaGet = function (
            e,
            t,
          ) {
            return Ar(
              this.configuration,
            ).v1AutomaticTranslationGamesGameIdQuotaGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (Rr.prototype.v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet =
            function (e, t, r) {
              return Ar(
                this.configuration,
              ).v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet(
                e,
                t,
                r,
              )(this.axios, this.basePath);
            }),
          Rr);
      function Rr() {
        return (null !== Tr && Tr.apply(this, arguments)) || this;
      }
      function Ur(l) {
        return {
          v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "badgeId",
                "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch.",
              );
            if (null == r)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch.",
              );
            var n,
              o =
                "/v1/badges/{badgeId}/description/language-codes/{languageCode}"
                  .replace("{badgeId}", encodeURIComponent(String(e)))
                  .replace("{languageCode}", encodeURIComponent(String(t))),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "PATCH" }, n), a),
              u = {};
            ((u["Content-Type"] = "application/json"),
              (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, u), a.headers)));
            return (
              (i.data = JSON.stringify(void 0 !== r ? r : {})),
              { url: P.format(s), options: i }
            );
          },
          v1BadgesBadgeIdIconsGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "badgeId",
                "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdIconsGet.",
              );
            var n,
              o = "/v1/badges/{badgeId}/icons".replace(
                "{badgeId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.width = t),
              void 0 !== r && (u.height = r),
              (s.query = Ir(Ir(Ir({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "badgeId",
                "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete.",
              );
            var a,
              n = "/v1/badges/{badgeId}/icons/language-codes/{languageCode}"
                .replace("{badgeId}", encodeURIComponent(String(e)))
                .replace("{languageCode}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            l && (a = l.baseOptions);
            var s = Ir(Ir({ method: "DELETE" }, a), r);
            return (
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "badgeId",
                "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost.",
              );
            var n,
              o = "/v1/badges/{badgeId}/icons/language-codes/{languageCode}"
                .replace("{badgeId}", encodeURIComponent(String(e)))
                .replace("{languageCode}", encodeURIComponent(String(t))),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "POST" }, n), a),
              u = new FormData();
            return (
              void 0 !== r && u.append("request.files", r),
              (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              (i.data = u),
              { url: P.format(s), options: i }
            );
          },
          v1BadgesBadgeIdNameDescriptionGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "badgeId",
                "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameDescriptionGet.",
              );
            var r,
              a = "/v1/badges/{badgeId}/name-description".replace(
                "{badgeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            l && (r = l.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              if ((void 0 === r && (r = {}), null == e))
                throw new Rt(
                  "badgeId",
                  "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete.",
                );
              var a,
                n =
                  "/v1/badges/{badgeId}/name-description/language-codes/{languageCode}"
                    .replace("{badgeId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                o = P.parse(n, !0);
              l && (a = l.baseOptions);
              var s = Ir(Ir({ method: "DELETE" }, a), r);
              return (
                (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, {}), r.headers)),
                { url: P.format(o), options: s }
              );
            },
          v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "badgeId",
                  "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              var n,
                o =
                  "/v1/badges/{badgeId}/name-description/language-codes/{languageCode}"
                    .replace("{badgeId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
          v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "badgeId",
                "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch.",
              );
            if (null == r)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch.",
              );
            var n,
              o = "/v1/badges/{badgeId}/name/language-codes/{languageCode}"
                .replace("{badgeId}", encodeURIComponent(String(e)))
                .replace("{languageCode}", encodeURIComponent(String(t))),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "PATCH" }, n), a),
              u = {};
            ((u["Content-Type"] = "application/json"),
              (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, u), a.headers)));
            return (
              (i.data = JSON.stringify(void 0 !== r ? r : {})),
              { url: P.format(s), options: i }
            );
          },
        };
      }
      function Or(o) {
        return {
          v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch: function (
            e,
            t,
            r,
            a,
          ) {
            var n = Ur(
              o,
            ).v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1BadgesBadgeIdIconsGet: function (e, t, r, a) {
            var n = Ur(o).v1BadgesBadgeIdIconsGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete: function (
            e,
            t,
            r,
          ) {
            var a = Ur(o).v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost: function (
            e,
            t,
            r,
            a,
          ) {
            var n = Ur(o).v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1BadgesBadgeIdNameDescriptionGet: function (e, t) {
            var a = Ur(o).v1BadgesBadgeIdNameDescriptionGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              var a = Ur(
                o,
              ).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete(
                e,
                t,
                r,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
          v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              var n = Ur(
                o,
              ).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch: function (
            e,
            t,
            r,
            a,
          ) {
            var n = Ur(o).v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
        };
      }
      var Dr;
      (yr(Br, (Dr = Pt)),
        (Br.prototype.v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return Or(
              this.configuration,
            ).v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Br.prototype.v1BadgesBadgeIdIconsGet = function (e, t, r, a) {
          return Or(this.configuration).v1BadgesBadgeIdIconsGet(
            e,
            t,
            r,
            a,
          )(this.axios, this.basePath);
        }),
        (Br.prototype.v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return Or(
              this.configuration,
            ).v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (Br.prototype.v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost =
          function (e, t, r, a) {
            return Or(
              this.configuration,
            ).v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Br.prototype.v1BadgesBadgeIdNameDescriptionGet = function (e, t) {
          return Or(this.configuration).v1BadgesBadgeIdNameDescriptionGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (Br.prototype.v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return Or(
              this.configuration,
            ).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (Br.prototype.v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return Or(
              this.configuration,
            ).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Br.prototype.v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return Or(
              this.configuration,
            ).v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }));
      function Br() {
        return (null !== Dr && Dr.apply(this, arguments)) || this;
      }
      function xr(l) {
        return {
          v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "developerProductId",
                  "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch.",
                );
              var n,
                o =
                  "/v1/developer-products/{developerProductId}/description/language-codes/{languageCode}"
                    .replace(
                      "{developerProductId}",
                      encodeURIComponent(String(e)),
                    )
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
          v1DeveloperProductsDeveloperProductIdIconsGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "developerProductId",
                "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsGet.",
              );
            var n,
              o = "/v1/developer-products/{developerProductId}/icons".replace(
                "{developerProductId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.width = t),
              void 0 !== r && (u.height = r),
              (s.query = Ir(Ir(Ir({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              if ((void 0 === r && (r = {}), null == e))
                throw new Rt(
                  "developerProductId",
                  "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete.",
                );
              var a,
                n =
                  "/v1/developer-products/{developerProductId}/icons/language-codes/{languageCode}"
                    .replace(
                      "{developerProductId}",
                      encodeURIComponent(String(e)),
                    )
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                o = P.parse(n, !0);
              l && (a = l.baseOptions);
              var s = Ir(Ir({ method: "DELETE" }, a), r);
              return (
                (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, {}), r.headers)),
                { url: P.format(o), options: s }
              );
            },
          v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "developerProductId",
                  "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost.",
                );
              var n,
                o =
                  "/v1/developer-products/{developerProductId}/icons/language-codes/{languageCode}"
                    .replace(
                      "{developerProductId}",
                      encodeURIComponent(String(e)),
                    )
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "POST" }, n), a),
                u = new FormData();
              return (
                void 0 !== r && u.append("request.files", r),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, {}), a.headers)),
                (i.data = u),
                { url: P.format(s), options: i }
              );
            },
          v1DeveloperProductsDeveloperProductIdNameDescriptionGet: function (
            e,
            t,
          ) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "developerProductId",
                "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionGet.",
              );
            var r,
              a =
                "/v1/developer-products/{developerProductId}/name-description".replace(
                  "{developerProductId}",
                  encodeURIComponent(String(e)),
                ),
              n = P.parse(a, !0);
            l && (r = l.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              if ((void 0 === r && (r = {}), null == e))
                throw new Rt(
                  "developerProductId",
                  "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete.",
                );
              var a,
                n =
                  "/v1/developer-products/{developerProductId}/name-description/language-codes/{languageCode}"
                    .replace(
                      "{developerProductId}",
                      encodeURIComponent(String(e)),
                    )
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                o = P.parse(n, !0);
              l && (a = l.baseOptions);
              var s = Ir(Ir({ method: "DELETE" }, a), r);
              return (
                (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, {}), r.headers)),
                { url: P.format(o), options: s }
              );
            },
          v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "developerProductId",
                  "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              var n,
                o =
                  "/v1/developer-products/{developerProductId}/name-description/language-codes/{languageCode}"
                    .replace(
                      "{developerProductId}",
                      encodeURIComponent(String(e)),
                    )
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
          v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "developerProductId",
                  "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch.",
                );
              var n,
                o =
                  "/v1/developer-products/{developerProductId}/name/language-codes/{languageCode}"
                    .replace(
                      "{developerProductId}",
                      encodeURIComponent(String(e)),
                    )
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
        };
      }
      function Er(o) {
        return {
          v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              var n = xr(
                o,
              ).v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1DeveloperProductsDeveloperProductIdIconsGet: function (e, t, r, a) {
            var n = xr(o).v1DeveloperProductsDeveloperProductIdIconsGet(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              var a = xr(
                o,
              ).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete(
                e,
                t,
                r,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
          v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost:
            function (e, t, r, a) {
              var n = xr(
                o,
              ).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1DeveloperProductsDeveloperProductIdNameDescriptionGet: function (
            e,
            t,
          ) {
            var a = xr(
              o,
            ).v1DeveloperProductsDeveloperProductIdNameDescriptionGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              var a = xr(
                o,
              ).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete(
                e,
                t,
                r,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
          v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              var n = xr(
                o,
              ).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              var n = xr(
                o,
              ).v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
        };
      }
      var Fr;
      (yr(Nr, (Fr = Pt)),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdIconsGet = function (
          e,
          t,
          r,
          a,
        ) {
          return Er(
            this.configuration,
          ).v1DeveloperProductsDeveloperProductIdIconsGet(
            e,
            t,
            r,
            a,
          )(this.axios, this.basePath);
        }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost =
          function (e, t, r, a) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdNameDescriptionGet =
          function (e, t) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdNameDescriptionGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Nr.prototype.v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return Er(
              this.configuration,
            ).v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }));
      function Nr() {
        return (null !== Fr && Fr.apply(this, arguments)) || this;
      }
      function zr(l) {
        return {
          v1GameIconGamesGameIdGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameIconGamesGameIdGet.",
              );
            var n,
              o = "/v1/game-icon/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.width = t),
              void 0 !== r && (u.height = r),
              (s.query = Ir(Ir(Ir({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete.",
              );
            var a,
              n = "/v1/game-icon/games/{gameId}/language-codes/{languageCode}"
                .replace("{gameId}", encodeURIComponent(String(e)))
                .replace("{languageCode}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            l && (a = l.baseOptions);
            var s = Ir(Ir({ method: "DELETE" }, a), r);
            return (
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1GameIconGamesGameIdLanguageCodesLanguageCodePost: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodePost.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodePost.",
              );
            var n,
              o = "/v1/game-icon/games/{gameId}/language-codes/{languageCode}"
                .replace("{gameId}", encodeURIComponent(String(e)))
                .replace("{languageCode}", encodeURIComponent(String(t))),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "POST" }, n), a),
              u = new FormData();
            return (
              void 0 !== r && u.append("request.files", r),
              (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              (i.data = u),
              { url: P.format(s), options: i }
            );
          },
        };
      }
      function jr(o) {
        return {
          v1GameIconGamesGameIdGet: function (e, t, r, a) {
            var n = zr(o).v1GameIconGamesGameIdGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete: function (
            e,
            t,
            r,
          ) {
            var a = zr(o).v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GameIconGamesGameIdLanguageCodesLanguageCodePost: function (
            e,
            t,
            r,
            a,
          ) {
            var n = zr(o).v1GameIconGamesGameIdLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
        };
      }
      var _r;
      (yr(kr, (_r = Pt)),
        (kr.prototype.v1GameIconGamesGameIdGet = function (e, t, r, a) {
          return jr(this.configuration).v1GameIconGamesGameIdGet(
            e,
            t,
            r,
            a,
          )(this.axios, this.basePath);
        }),
        (kr.prototype.v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return jr(
              this.configuration,
            ).v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (kr.prototype.v1GameIconGamesGameIdLanguageCodesLanguageCodePost =
          function (e, t, r, a) {
            return jr(
              this.configuration,
            ).v1GameIconGamesGameIdLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }));
      function kr() {
        return (null !== _r && _r.apply(this, arguments)) || this;
      }
      function Mr(u) {
        return {
          v1GameLocalizationStatusGameIdTranslationCountsGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameLocalizationStatusGameIdTranslationCountsGet.",
              );
            var r,
              a =
                "/v1/game-localization-status/{gameId}/translation-counts".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gameIds",
                  "Required parameter gameIds was null or undefined when calling v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet.",
                );
              if (null == t)
                throw new Rt(
                  "languageOrLocaleCode",
                  "Required parameter languageOrLocaleCode was null or undefined when calling v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet.",
                );
              if (null == r)
                throw new Rt(
                  "languageOrLocaleType",
                  "Required parameter languageOrLocaleType was null or undefined when calling v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet.",
                );
              var n,
                o = P.parse(
                  "/v1/game-localization-status/translation-counts-for-language-or-locale",
                  !0,
                );
              u && (n = u.baseOptions);
              var s = Ir(Ir({ method: "GET" }, n), a),
                i = {};
              return (
                e && (i.gameIds = e),
                void 0 !== t && (i.languageOrLocaleCode = t),
                void 0 !== r && (i.languageOrLocaleType = r),
                (o.query = Ir(Ir(Ir({}, o.query), i), a.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, {}), a.headers)),
                { url: P.format(o), options: s }
              );
            },
        };
      }
      function Hr(o) {
        return {
          v1GameLocalizationStatusGameIdTranslationCountsGet: function (e, t) {
            var a = Mr(o).v1GameLocalizationStatusGameIdTranslationCountsGet(
              e,
              t,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet:
            function (e, t, r, a) {
              var n = Mr(
                o,
              ).v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
        };
      }
      var Vr,
        Wr =
          (yr(Jr, (Vr = Pt)),
          (Jr.prototype.v1GameLocalizationStatusGameIdTranslationCountsGet =
            function (e, t) {
              return Hr(
                this.configuration,
              ).v1GameLocalizationStatusGameIdTranslationCountsGet(e, t)(
                this.axios,
                this.basePath,
              );
            }),
          (Jr.prototype.v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet =
            function (e, t, r, a) {
              return Hr(
                this.configuration,
              ).v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet(
                e,
                t,
                r,
                a,
              )(this.axios, this.basePath);
            }),
          Jr);
      function Jr() {
        return (null !== Vr && Vr.apply(this, arguments)) || this;
      }
      function Kr(l) {
        return {
          v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gamePassId",
                  "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch.",
                );
              var n,
                o =
                  "/v1/game-passes/{gamePassId}/description/language-codes/{languageCode}"
                    .replace("{gamePassId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
          v1GamePassesGamePassIdIconsGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "gamePassId",
                "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdIconsGet.",
              );
            var n,
              o = "/v1/game-passes/{gamePassId}/icons".replace(
                "{gamePassId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.width = t),
              void 0 !== r && (u.height = r),
              (s.query = Ir(Ir(Ir({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gamePassId",
                "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete.",
              );
            var a,
              n =
                "/v1/game-passes/{gamePassId}/icons/language-codes/{languageCode}"
                  .replace("{gamePassId}", encodeURIComponent(String(e)))
                  .replace("{languageCode}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            l && (a = l.baseOptions);
            var s = Ir(Ir({ method: "DELETE" }, a), r);
            return (
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "gamePassId",
                "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost.",
              );
            var n,
              o =
                "/v1/game-passes/{gamePassId}/icons/language-codes/{languageCode}"
                  .replace("{gamePassId}", encodeURIComponent(String(e)))
                  .replace("{languageCode}", encodeURIComponent(String(t))),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "POST" }, n), a),
              u = new FormData();
            return (
              void 0 !== r && u.append("request.files", r),
              (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              (i.data = u),
              { url: P.format(s), options: i }
            );
          },
          v1GamePassesGamePassIdNameDescriptionGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gamePassId",
                "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameDescriptionGet.",
              );
            var r,
              a = "/v1/game-passes/{gamePassId}/name-description".replace(
                "{gamePassId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            l && (r = l.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              if ((void 0 === r && (r = {}), null == e))
                throw new Rt(
                  "gamePassId",
                  "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete.",
                );
              var a,
                n =
                  "/v1/game-passes/{gamePassId}/name-description/language-codes/{languageCode}"
                    .replace("{gamePassId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                o = P.parse(n, !0);
              l && (a = l.baseOptions);
              var s = Ir(Ir({ method: "DELETE" }, a), r);
              return (
                (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, {}), r.headers)),
                { url: P.format(o), options: s }
              );
            },
          v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gamePassId",
                  "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch.",
                );
              var n,
                o =
                  "/v1/game-passes/{gamePassId}/name-description/language-codes/{languageCode}"
                    .replace("{gamePassId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
          v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "gamePassId",
                "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch.",
              );
            if (null == r)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch.",
              );
            var n,
              o =
                "/v1/game-passes/{gamePassId}/name/language-codes/{languageCode}"
                  .replace("{gamePassId}", encodeURIComponent(String(e)))
                  .replace("{languageCode}", encodeURIComponent(String(t))),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "PATCH" }, n), a),
              u = {};
            ((u["Content-Type"] = "application/json"),
              (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, u), a.headers)));
            return (
              (i.data = JSON.stringify(void 0 !== r ? r : {})),
              { url: P.format(s), options: i }
            );
          },
        };
      }
      function $r(o) {
        return {
          v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              var n = Kr(
                o,
              ).v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1GamePassesGamePassIdIconsGet: function (e, t, r, a) {
            var n = Kr(o).v1GamePassesGamePassIdIconsGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete: function (
            e,
            t,
            r,
          ) {
            var a = Kr(
              o,
            ).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost: function (
            e,
            t,
            r,
            a,
          ) {
            var n = Kr(
              o,
            ).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GamePassesGamePassIdNameDescriptionGet: function (e, t) {
            var a = Kr(o).v1GamePassesGamePassIdNameDescriptionGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete:
            function (e, t, r) {
              var a = Kr(
                o,
              ).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete(
                e,
                t,
                r,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
          v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch:
            function (e, t, r, a) {
              var n = Kr(
                o,
              ).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch: function (
            e,
            t,
            r,
            a,
          ) {
            var n = Kr(
              o,
            ).v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
        };
      }
      var Qr;
      (yr(Xr, (Qr = Pt)),
        (Xr.prototype.v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return $r(
              this.configuration,
            ).v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Xr.prototype.v1GamePassesGamePassIdIconsGet = function (e, t, r, a) {
          return $r(this.configuration).v1GamePassesGamePassIdIconsGet(
            e,
            t,
            r,
            a,
          )(this.axios, this.basePath);
        }),
        (Xr.prototype.v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return $r(
              this.configuration,
            ).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (Xr.prototype.v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost =
          function (e, t, r, a) {
            return $r(
              this.configuration,
            ).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Xr.prototype.v1GamePassesGamePassIdNameDescriptionGet = function (
          e,
          t,
        ) {
          return $r(
            this.configuration,
          ).v1GamePassesGamePassIdNameDescriptionGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (Xr.prototype.v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete =
          function (e, t, r) {
            return $r(
              this.configuration,
            ).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (Xr.prototype.v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return $r(
              this.configuration,
            ).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (Xr.prototype.v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch =
          function (e, t, r, a) {
            return $r(
              this.configuration,
            ).v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }));
      function Xr() {
        return (null !== Qr && Qr.apply(this, arguments)) || this;
      }
      function Yr(l) {
        return {
          v1GameThumbnailsGamesGameIdImagesGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdImagesGet.",
              );
            var n,
              o = "/v1/game-thumbnails/games/{gameId}/images".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Ir(Ir({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.width = t),
              void 0 !== r && (u.height = r),
              (s.query = Ir(Ir(Ir({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost.",
                );
              var n,
                o =
                  "/v1/game-thumbnails/games/{gameId}/language-codes/{languageCode}/image"
                    .replace("{gameId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "POST" }, n), a),
                u = new FormData();
              return (
                void 0 !== r && u.append("gameThumbnailRequest.files", r),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, {}), a.headers)),
                (i.data = u),
                { url: P.format(s), options: i }
              );
            },
          v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete.",
                );
              if (null == r)
                throw new Rt(
                  "imageId",
                  "Required parameter imageId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete.",
                );
              var n,
                o =
                  "/v1/game-thumbnails/games/{gameId}/language-codes/{languageCode}/images/{imageId}"
                    .replace("{gameId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t)))
                    .replace("{imageId}", encodeURIComponent(String(r))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "DELETE" }, n), a);
              return (
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, {}), a.headers)),
                { url: P.format(s), options: i }
              );
            },
          v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost.",
                );
              if (null == r)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost.",
                );
              var n,
                o =
                  "/v1/game-thumbnails/games/{gameId}/language-codes/{languageCode}/images/order"
                    .replace("{gameId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "POST" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
        };
      }
      function Zr(o) {
        return {
          v1GameThumbnailsGamesGameIdImagesGet: function (e, t, r, a) {
            var n = Yr(o).v1GameThumbnailsGamesGameIdImagesGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost:
            function (e, t, r, a) {
              var n = Yr(
                o,
              ).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete:
            function (e, t, r, a) {
              var n = Yr(
                o,
              ).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost:
            function (e, t, r, a) {
              var n = Yr(
                o,
              ).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
        };
      }
      var ea;
      (yr(ta, (ea = Pt)),
        (ta.prototype.v1GameThumbnailsGamesGameIdImagesGet = function (
          e,
          t,
          r,
          a,
        ) {
          return Zr(this.configuration).v1GameThumbnailsGamesGameIdImagesGet(
            e,
            t,
            r,
            a,
          )(this.axios, this.basePath);
        }),
        (ta.prototype.v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost =
          function (e, t, r, a) {
            return Zr(
              this.configuration,
            ).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (ta.prototype.v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete =
          function (e, t, r, a) {
            return Zr(
              this.configuration,
            ).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        (ta.prototype.v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost =
          function (e, t, r, a) {
            return Zr(
              this.configuration,
            ).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }));
      function ta() {
        return (null !== ea && ea.apply(this, arguments)) || this;
      }
      function ra(d) {
        return {
          v1LocalizationtableAvailableLanguagesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/localizationtable/available-languages", !0);
            d && (t = d.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1LocalizationtableGamesGameIdAssetsGenerationRequestPost: function (
            e,
            t,
          ) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1LocalizationtableGamesGameIdAssetsGenerationRequestPost.",
              );
            var r,
              a =
                "/v1/localizationtable/games/{gameId}/assets-generation-request".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              n = P.parse(a, !0);
            d && (r = d.baseOptions);
            var o = Ir(Ir({ method: "POST" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1LocalizationtableGametablesGameIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1LocalizationtableGametablesGameIdPatch.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1LocalizationtableGametablesGameIdPatch.",
              );
            var a,
              n = "/v1/localizationtable/gametables/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            d && (a = d.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1LocalizationtableTablesGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "assetId",
                "Required parameter assetId was null or undefined when calling v1LocalizationtableTablesGet.",
              );
            var r,
              a = P.parse("/v1/localizationtable/tables", !0);
            d && (r = d.baseOptions);
            var n = Ir(Ir({ method: "GET" }, r), t),
              o = {};
            return (
              void 0 !== e && (o.assetId = e),
              (a.query = Ir(Ir(Ir({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1LocalizationtableTablesPost: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1LocalizationtableTablesPost.",
              );
            var r,
              a = P.parse("/v1/localizationtable/tables", !0);
            d && (r = d.baseOptions);
            var n = Ir(Ir({ method: "POST" }, r), t),
              o = {};
            ((o["Content-Type"] = "application/json"),
              (a.query = Ir(Ir(Ir({}, a.query), {}), t.query)),
              delete a.search,
              (n.headers = Ir(Ir({}, o), t.headers)));
            return (
              (n.data = JSON.stringify(void 0 !== e ? e : {})),
              { url: P.format(a), options: n }
            );
          },
          v1LocalizationtableTablesTableIdEntriesGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "tableId",
                "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdEntriesGet.",
              );
            var n,
              o = "/v1/localizationtable/tables/{tableId}/entries".replace(
                "{tableId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            d && (n = d.baseOptions);
            var i = Ir(Ir({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.cursor = t),
              void 0 !== r && (u.gameId = r),
              (s.query = Ir(Ir(Ir({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "tableId",
                  "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost.",
                );
              if (null == t)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost.",
                );
              var n,
                o =
                  "/v1/localizationtable/tables/{tableId}/entries/translation-history".replace(
                    "{tableId}",
                    encodeURIComponent(String(e)),
                  ),
                s = P.parse(o, !0);
              d && (n = d.baseOptions);
              var i = Ir(Ir({ method: "POST" }, n), a),
                u = {},
                l = {};
              (void 0 !== r && (l.gameId = r),
                (u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), l), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== t ? t : {})),
                { url: P.format(s), options: i }
              );
            },
          v1LocalizationtableTablesTableIdEntryCountGet: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "tableId",
                "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdEntryCountGet.",
              );
            var a,
              n = "/v1/localizationtable/tables/{tableId}/entry-count".replace(
                "{tableId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            d && (a = d.baseOptions);
            var s = Ir(Ir({ method: "GET" }, a), r),
              i = {};
            return (
              void 0 !== t && (i.gameId = t),
              (o.query = Ir(Ir(Ir({}, o.query), i), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1LocalizationtableTablesTableIdGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "tableId",
                "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdGet.",
              );
            var r,
              a = "/v1/localizationtable/tables/{tableId}".replace(
                "{tableId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            d && (r = d.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1LocalizationtableTablesTableIdPatch: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "tableId",
                "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdPatch.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1LocalizationtableTablesTableIdPatch.",
              );
            var n,
              o = "/v1/localizationtable/tables/{tableId}".replace(
                "{tableId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            d && (n = d.baseOptions);
            var i = Ir(Ir({ method: "PATCH" }, n), a),
              u = {},
              l = {};
            (void 0 !== r && (l.gameId = r),
              (u["Content-Type"] = "application/json"),
              (s.query = Ir(Ir(Ir({}, s.query), l), a.query)),
              delete s.search,
              (i.headers = Ir(Ir({}, u), a.headers)));
            return (
              (i.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(s), options: i }
            );
          },
        };
      }
      function aa(o) {
        return {
          v1LocalizationtableAvailableLanguagesGet: function (e) {
            var a = ra(o).v1LocalizationtableAvailableLanguagesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableGamesGameIdAssetsGenerationRequestPost: function (
            e,
            t,
          ) {
            var a = ra(
              o,
            ).v1LocalizationtableGamesGameIdAssetsGenerationRequestPost(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableGametablesGameIdPatch: function (e, t, r) {
            var a = ra(o).v1LocalizationtableGametablesGameIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableTablesGet: function (e, t) {
            var a = ra(o).v1LocalizationtableTablesGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableTablesPost: function (e, t) {
            var a = ra(o).v1LocalizationtableTablesPost(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableTablesTableIdEntriesGet: function (e, t, r, a) {
            var n = ra(o).v1LocalizationtableTablesTableIdEntriesGet(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost:
            function (e, t, r, a) {
              var n = ra(
                o,
              ).v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1LocalizationtableTablesTableIdEntryCountGet: function (e, t, r) {
            var a = ra(o).v1LocalizationtableTablesTableIdEntryCountGet(
              e,
              t,
              r,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableTablesTableIdGet: function (e, t) {
            var a = ra(o).v1LocalizationtableTablesTableIdGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalizationtableTablesTableIdPatch: function (e, t, r, a) {
            var n = ra(o).v1LocalizationtableTablesTableIdPatch(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
        };
      }
      var na,
        oa =
          (yr(sa, (na = Pt)),
          (sa.prototype.v1LocalizationtableAvailableLanguagesGet = function (
            e,
          ) {
            return aa(
              this.configuration,
            ).v1LocalizationtableAvailableLanguagesGet(e)(
              this.axios,
              this.basePath,
            );
          }),
          (sa.prototype.v1LocalizationtableGamesGameIdAssetsGenerationRequestPost =
            function (e, t) {
              return aa(
                this.configuration,
              ).v1LocalizationtableGamesGameIdAssetsGenerationRequestPost(e, t)(
                this.axios,
                this.basePath,
              );
            }),
          (sa.prototype.v1LocalizationtableGametablesGameIdPatch = function (
            e,
            t,
            r,
          ) {
            return aa(
              this.configuration,
            ).v1LocalizationtableGametablesGameIdPatch(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          (sa.prototype.v1LocalizationtableTablesGet = function (e, t) {
            return aa(this.configuration).v1LocalizationtableTablesGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (sa.prototype.v1LocalizationtableTablesPost = function (e, t) {
            return aa(this.configuration).v1LocalizationtableTablesPost(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (sa.prototype.v1LocalizationtableTablesTableIdEntriesGet = function (
            e,
            t,
            r,
            a,
          ) {
            return aa(
              this.configuration,
            ).v1LocalizationtableTablesTableIdEntriesGet(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
          (sa.prototype.v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost =
            function (e, t, r, a) {
              return aa(
                this.configuration,
              ).v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost(
                e,
                t,
                r,
                a,
              )(this.axios, this.basePath);
            }),
          (sa.prototype.v1LocalizationtableTablesTableIdEntryCountGet =
            function (e, t, r) {
              return aa(
                this.configuration,
              ).v1LocalizationtableTablesTableIdEntryCountGet(
                e,
                t,
                r,
              )(this.axios, this.basePath);
            }),
          (sa.prototype.v1LocalizationtableTablesTableIdGet = function (e, t) {
            return aa(this.configuration).v1LocalizationtableTablesTableIdGet(
              e,
              t,
            )(this.axios, this.basePath);
          }),
          (sa.prototype.v1LocalizationtableTablesTableIdPatch = function (
            e,
            t,
            r,
            a,
          ) {
            return aa(this.configuration).v1LocalizationtableTablesTableIdPatch(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
          sa);
      function sa() {
        return (null !== na && na.apply(this, arguments)) || this;
      }
      function ia(u) {
        return {
          v1NameDescriptionGamesGameIdGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1NameDescriptionGamesGameIdGet.",
              );
            var r,
              a = "/v1/name-description/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1NameDescriptionGamesGameIdHistoryPost: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1NameDescriptionGamesGameIdHistoryPost.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1NameDescriptionGamesGameIdHistoryPost.",
              );
            var a,
              n = "/v1/name-description/games/{gameId}/history".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "POST" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1NameDescriptionGamesGameIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1NameDescriptionGamesGameIdPatch.",
              );
            if (null == t)
              throw new Rt(
                "request",
                "Required parameter request was null or undefined when calling v1NameDescriptionGamesGameIdPatch.",
              );
            var a,
              n = "/v1/name-description/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1NameDescriptionMetadataGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/name-description/metadata", !0);
            u && (t = u.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function ua(n) {
        return {
          v1NameDescriptionGamesGameIdGet: function (e, t) {
            var a = ia(n).v1NameDescriptionGamesGameIdGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1NameDescriptionGamesGameIdHistoryPost: function (e, t, r) {
            var a = ia(n).v1NameDescriptionGamesGameIdHistoryPost(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1NameDescriptionGamesGameIdPatch: function (e, t, r) {
            var a = ia(n).v1NameDescriptionGamesGameIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1NameDescriptionMetadataGet: function (e) {
            var a = ia(n).v1NameDescriptionMetadataGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var la;
      (yr(da, (la = Pt)),
        (da.prototype.v1NameDescriptionGamesGameIdGet = function (e, t) {
          return ua(this.configuration).v1NameDescriptionGamesGameIdGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (da.prototype.v1NameDescriptionGamesGameIdHistoryPost = function (
          e,
          t,
          r,
        ) {
          return ua(this.configuration).v1NameDescriptionGamesGameIdHistoryPost(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (da.prototype.v1NameDescriptionGamesGameIdPatch = function (e, t, r) {
          return ua(this.configuration).v1NameDescriptionGamesGameIdPatch(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (da.prototype.v1NameDescriptionMetadataGet = function (e) {
          return ua(this.configuration).v1NameDescriptionMetadataGet(e)(
            this.axios,
            this.basePath,
          );
        }));
      function da() {
        return (null !== la && la.apply(this, arguments)) || this;
      }
      function ca(u) {
        return {
          v1PlayerPoliciesAllValuesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/player-policies/all-values", !0);
            u && (t = u.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1PlayerPoliciesClientGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/player-policies-client", !0);
            u && (t = u.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1PlayerPoliciesRccGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Rt(
                "userId",
                "Required parameter userId was null or undefined when calling v1PlayerPoliciesRccGet.",
              );
            if (null == t)
              throw new Rt(
                "ipAddress",
                "Required parameter ipAddress was null or undefined when calling v1PlayerPoliciesRccGet.",
              );
            if (null == r)
              throw new Rt(
                "userAgent",
                "Required parameter userAgent was null or undefined when calling v1PlayerPoliciesRccGet.",
              );
            var n,
              o = P.parse("/v1/player-policies-rcc", !0);
            u && (n = u.baseOptions);
            var s = Ir(Ir({ method: "GET" }, n), a),
              i = {};
            return (
              void 0 !== e && (i.userId = e),
              void 0 !== t && (i.ipAddress = t),
              void 0 !== r && (i.userAgent = r),
              (o.query = Ir(Ir(Ir({}, o.query), i), a.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, {}), a.headers)),
              { url: P.format(o), options: s }
            );
          },
        };
      }
      function va(o) {
        return {
          v1PlayerPoliciesAllValuesGet: function (e) {
            var a = ca(o).v1PlayerPoliciesAllValuesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1PlayerPoliciesClientGet: function (e) {
            var a = ca(o).v1PlayerPoliciesClientGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1PlayerPoliciesRccGet: function (e, t, r, a) {
            var n = ca(o).v1PlayerPoliciesRccGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
        };
      }
      var pa;
      (yr(ha, (pa = Pt)),
        (ha.prototype.v1PlayerPoliciesAllValuesGet = function (e) {
          return va(this.configuration).v1PlayerPoliciesAllValuesGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (ha.prototype.v1PlayerPoliciesClientGet = function (e) {
          return va(this.configuration).v1PlayerPoliciesClientGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (ha.prototype.v1PlayerPoliciesRccGet = function (e, t, r, a) {
          return va(this.configuration).v1PlayerPoliciesRccGet(
            e,
            t,
            r,
            a,
          )(this.axios, this.basePath);
        }));
      function ha() {
        return (null !== pa && pa.apply(this, arguments)) || this;
      }
      function ma(u) {
        return {
          v1SourceLanguageGamesGameIdGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1SourceLanguageGamesGameIdGet.",
              );
            var r,
              a = "/v1/source-language/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1SourceLanguageGamesGameIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1SourceLanguageGamesGameIdPatch.",
              );
            if (null == t)
              throw new Rt(
                "languageCode",
                "Required parameter languageCode was null or undefined when calling v1SourceLanguageGamesGameIdPatch.",
              );
            var a,
              n = "/v1/source-language/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            return (
              void 0 !== t && (i.languageCode = t),
              (o.query = Ir(Ir(Ir({}, o.query), i), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
        };
      }
      function ga(n) {
        return {
          v1SourceLanguageGamesGameIdGet: function (e, t) {
            var a = ma(n).v1SourceLanguageGamesGameIdGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1SourceLanguageGamesGameIdPatch: function (e, t, r) {
            var a = ma(n).v1SourceLanguageGamesGameIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var fa,
        Ga =
          (yr(ya, (fa = Pt)),
          (ya.prototype.v1SourceLanguageGamesGameIdGet = function (e, t) {
            return ga(this.configuration).v1SourceLanguageGamesGameIdGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (ya.prototype.v1SourceLanguageGamesGameIdPatch = function (e, t, r) {
            return ga(this.configuration).v1SourceLanguageGamesGameIdPatch(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          ya);
      function ya() {
        return (null !== fa && fa.apply(this, arguments)) || this;
      }
      function Ia(l) {
        return {
          v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet:
            function (e, t) {
              if ((void 0 === t && (t = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet.",
                );
              var r,
                a =
                  "/v1/supported-languages/games/{gameId}/automatic-translation-status".replace(
                    "{gameId}",
                    encodeURIComponent(String(e)),
                  ),
                n = P.parse(a, !0);
              l && (r = l.baseOptions);
              var o = Ir(Ir({ method: "GET" }, r), t);
              return (
                (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
                delete n.search,
                (o.headers = Ir(Ir({}, {}), t.headers)),
                { url: P.format(n), options: o }
              );
            },
          v1SupportedLanguagesGamesGameIdGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdGet.",
              );
            var r,
              a = "/v1/supported-languages/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            l && (r = l.baseOptions);
            var o = Ir(Ir({ method: "GET" }, r), t);
            return (
              (n.query = Ir(Ir(Ir({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Ir(Ir({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch:
            function (e, t, r, a) {
              if ((void 0 === a && (a = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch.",
                );
              if (null == t)
                throw new Rt(
                  "languageCode",
                  "Required parameter languageCode was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch.",
                );
              if (null == r)
                throw new Rt(
                  "enableAutomaticTranslation",
                  "Required parameter enableAutomaticTranslation was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch.",
                );
              var n,
                o =
                  "/v1/supported-languages/games/{gameId}/languages/{languageCode}/automatic-translation-status"
                    .replace("{gameId}", encodeURIComponent(String(e)))
                    .replace("{languageCode}", encodeURIComponent(String(t))),
                s = P.parse(o, !0);
              l && (n = l.baseOptions);
              var i = Ir(Ir({ method: "PATCH" }, n), a),
                u = {};
              ((u["Content-Type"] = "application/json"),
                (s.query = Ir(Ir(Ir({}, s.query), {}), a.query)),
                delete s.search,
                (i.headers = Ir(Ir({}, u), a.headers)));
              return (
                (i.data = JSON.stringify(void 0 !== r ? r : {})),
                { url: P.format(s), options: i }
              );
            },
          v1SupportedLanguagesGamesGameIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Rt(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdPatch.",
              );
            if (null == t)
              throw new Rt(
                "languages",
                "Required parameter languages was null or undefined when calling v1SupportedLanguagesGamesGameIdPatch.",
              );
            var a,
              n = "/v1/supported-languages/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            l && (a = l.baseOptions);
            var s = Ir(Ir({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Ir(Ir({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1SupportedLanguagesMetadataGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/supported-languages/metadata", !0);
            l && (t = l.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function ba(o) {
        return {
          v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet:
            function (e, t) {
              var a = Ia(
                o,
              ).v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet(
                e,
                t,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
          v1SupportedLanguagesGamesGameIdGet: function (e, t) {
            var a = Ia(o).v1SupportedLanguagesGamesGameIdGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch:
            function (e, t, r, a) {
              var n = Ia(
                o,
              ).v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch(
                e,
                t,
                r,
                a,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, n.options), { url: t + n.url });
                return e.request(r);
              };
            },
          v1SupportedLanguagesGamesGameIdPatch: function (e, t, r) {
            var a = Ia(o).v1SupportedLanguagesGamesGameIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1SupportedLanguagesMetadataGet: function (e) {
            var a = Ia(o).v1SupportedLanguagesMetadataGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var Pa,
        wa =
          (yr(Ca, (Pa = Pt)),
          (Ca.prototype.v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet =
            function (e, t) {
              return ba(
                this.configuration,
              ).v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet(
                e,
                t,
              )(this.axios, this.basePath);
            }),
          (Ca.prototype.v1SupportedLanguagesGamesGameIdGet = function (e, t) {
            return ba(this.configuration).v1SupportedLanguagesGamesGameIdGet(
              e,
              t,
            )(this.axios, this.basePath);
          }),
          (Ca.prototype.v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch =
            function (e, t, r, a) {
              return ba(
                this.configuration,
              ).v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch(
                e,
                t,
                r,
                a,
              )(this.axios, this.basePath);
            }),
          (Ca.prototype.v1SupportedLanguagesGamesGameIdPatch = function (
            e,
            t,
            r,
          ) {
            return ba(this.configuration).v1SupportedLanguagesGamesGameIdPatch(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          (Ca.prototype.v1SupportedLanguagesMetadataGet = function (e) {
            return ba(this.configuration).v1SupportedLanguagesMetadataGet(e)(
              this.axios,
              this.basePath,
            );
          }),
          Ca);
      function Ca() {
        return (null !== Pa && Pa.apply(this, arguments)) || this;
      }
      function qa(c) {
        return {
          v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet:
            function (e, t, r, a, n, o) {
              if ((void 0 === o && (o = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.",
                );
              if (null == t)
                throw new Rt(
                  "startDateTime",
                  "Required parameter startDateTime was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.",
                );
              if (null == r)
                throw new Rt(
                  "endDateTime",
                  "Required parameter endDateTime was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.",
                );
              if (null == a)
                throw new Rt(
                  "reportType",
                  "Required parameter reportType was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.",
                );
              if (null == n)
                throw new Rt(
                  "reportSubjectTargetId",
                  "Required parameter reportSubjectTargetId was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.",
                );
              var s,
                i =
                  "/v1/translation-analytics/games/{gameId}/download-translation-analytics-report".replace(
                    "{gameId}",
                    encodeURIComponent(String(e)),
                  ),
                u = P.parse(i, !0);
              c && (s = c.baseOptions);
              var l = Ir(Ir({ method: "GET" }, s), o),
                d = {};
              return (
                void 0 !== t && (d.startDateTime = t),
                void 0 !== r && (d.endDateTime = r),
                void 0 !== a && (d.reportType = a),
                void 0 !== n && (d.reportSubjectTargetId = n),
                (u.query = Ir(Ir(Ir({}, u.query), d), o.query)),
                delete u.search,
                (l.headers = Ir(Ir({}, {}), o.headers)),
                { url: P.format(u), options: l }
              );
            },
          v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost:
            function (e, t, r) {
              if ((void 0 === r && (r = {}), null == e))
                throw new Rt(
                  "gameId",
                  "Required parameter gameId was null or undefined when calling v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost.",
                );
              if (null == t)
                throw new Rt(
                  "request",
                  "Required parameter request was null or undefined when calling v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost.",
                );
              var a,
                n =
                  "/v1/translation-analytics/games/{gameId}/request-translation-analytics-report".replace(
                    "{gameId}",
                    encodeURIComponent(String(e)),
                  ),
                o = P.parse(n, !0);
              c && (a = c.baseOptions);
              var s = Ir(Ir({ method: "POST" }, a), r),
                i = {};
              ((i["Content-Type"] = "application/json"),
                (o.query = Ir(Ir(Ir({}, o.query), {}), r.query)),
                delete o.search,
                (s.headers = Ir(Ir({}, i), r.headers)));
              return (
                (s.data = JSON.stringify(void 0 !== t ? t : {})),
                { url: P.format(o), options: s }
              );
            },
          v1TranslationAnalyticsMetadataGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/translation-analytics/metadata", !0);
            c && (t = c.baseOptions);
            var a = Ir(Ir({ method: "GET" }, t), e);
            return (
              (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = Ir(Ir({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function La(i) {
        return {
          v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet:
            function (e, t, r, a, n, o) {
              var s = qa(
                i,
              ).v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet(
                e,
                t,
                r,
                a,
                n,
                o,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, s.options), { url: t + s.url });
                return e.request(r);
              };
            },
          v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost:
            function (e, t, r) {
              var a = qa(
                i,
              ).v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost(
                e,
                t,
                r,
              );
              return function (e, t) {
                (void 0 === e && (e = y.a), void 0 === t && (t = St));
                var r = Ir(Ir({}, a.options), { url: t + a.url });
                return e.request(r);
              };
            },
          v1TranslationAnalyticsMetadataGet: function (e) {
            var a = qa(i).v1TranslationAnalyticsMetadataGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var Aa,
        Ta =
          (yr(Sa, (Aa = Pt)),
          (Sa.prototype.v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet =
            function (e, t, r, a, n, o) {
              return La(
                this.configuration,
              ).v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet(
                e,
                t,
                r,
                a,
                n,
                o,
              )(this.axios, this.basePath);
            }),
          (Sa.prototype.v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost =
            function (e, t, r) {
              return La(
                this.configuration,
              ).v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost(
                e,
                t,
                r,
              )(this.axios, this.basePath);
            }),
          (Sa.prototype.v1TranslationAnalyticsMetadataGet = function (e) {
            return La(this.configuration).v1TranslationAnalyticsMetadataGet(e)(
              this.axios,
              this.basePath,
            );
          }),
          Sa);
      function Sa() {
        return (null !== Aa && Aa.apply(this, arguments)) || this;
      }
      function Ra(t) {
        return {
          v1UiConfigurationsGet: function (e) {
            var a = (function (n) {
              return {
                v1UiConfigurationsGet: function (e) {
                  void 0 === e && (e = {});
                  var t,
                    r = P.parse("/v1/ui-configurations", !0);
                  n && (t = n.baseOptions);
                  var a = Ir(Ir({ method: "GET" }, t), e);
                  return (
                    (r.query = Ir(Ir(Ir({}, r.query), {}), e.query)),
                    delete r.search,
                    (a.headers = Ir(Ir({}, {}), e.headers)),
                    { url: P.format(r), options: a }
                  );
                },
              };
            })(t).v1UiConfigurationsGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = St));
              var r = Ir(Ir({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var Ua;
      (yr(Oa, (Ua = Pt)),
        (Oa.prototype.v1UiConfigurationsGet = function (e) {
          return Ra(this.configuration).v1UiConfigurationsGet(e)(
            this.axios,
            this.basePath,
          );
        }));
      function Oa() {
        return (null !== Ua && Ua.apply(this, arguments)) || this;
      }
      function Da(e, t, r) {
        (void 0 === t && (t = _a),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var Ba,
        xa,
        Ea = new Cr(),
        Fa = {
          getAutolocalizationConfiguration: function (e) {
            return Ea.v1AutolocalizationGamesGameIdAutolocalizationtablePost(
              e,
              { withCredentials: !0 },
            );
          },
          setAutolocalizationConfiguration: function (e, t) {
            var r = { isAutolocalizationEnabled: t };
            return Ea.v1AutolocalizationGamesGameIdSettingsPatch(e, r, {
              withCredentials: !0,
            });
          },
          setUseAutoLocalizationTable: function (e, t) {
            var r = { shouldUseLocalizationTable: t };
            return Ea.v1AutolocalizationGamesGameIdSettingsPatch(e, r, {
              withCredentials: !0,
            });
          },
          flushAutoLocalizationTable: function (e, t) {
            var r = { maxAgeForFlush: t };
            return Ea.v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost(
              e,
              r,
              { withCredentials: !0 },
            );
          },
          getMetadata: function () {
            return Ea.v1AutolocalizationMetadataGet({ withCredentials: !0 });
          },
        },
        Na = new Sr(),
        za = {
          getGameFeatureStatus: function (e) {
            return Na.v1AutomaticTranslationGamesGameIdFeatureStatusGet(e, {
              withCredentials: !0,
            });
          },
          getTargetLanguages: function (e, t) {
            return Na.v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet(
              e,
              t,
              { withCredentials: !0 },
            );
          },
          getGameAutoLocalizationQuota: function (e) {
            return Na.v1AutomaticTranslationGamesGameIdQuotaGet(e, {
              withCredentials: !0,
            });
          },
        },
        ja =
          ((Ba = function (e, t) {
            return (Ba =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Ba(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        _a = i.EnvironmentUrls.gameInternationalizationApi.replace(/\/+$/, ""),
        ka = ((xa = Error), ja(Ma, xa), Ma);
      function Ma(e, t) {
        var r = xa.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var Ha,
        Va,
        Wa,
        Ja =
          ((Ha = function (e, t) {
            return (Ha =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Ha(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        Ka = function () {
          return (Ka =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        },
        $a = function (e, s, i, u) {
          return new (i = i || Promise)(function (t, r) {
            function a(e) {
              try {
                o(u.next(e));
              } catch (e) {
                r(e);
              }
            }
            function n(e) {
              try {
                o(u.throw(e));
              } catch (e) {
                r(e);
              }
            }
            function o(e) {
              e.done
                ? t(e.value)
                : (function (t) {
                    return t instanceof i
                      ? t
                      : new i(function (e) {
                          e(t);
                        });
                  })(e.value).then(a, n);
            }
            o((u = u.apply(e, s || [])).next());
          });
        },
        Qa = function (r, a) {
          var n,
            o,
            s,
            e,
            i = {
              label: 0,
              sent: function () {
                if (1 & s[0]) throw s[1];
                return s[1];
              },
              trys: [],
              ops: [],
            };
          return (
            (e = { next: t(0), throw: t(1), return: t(2) }),
            "function" == typeof Symbol &&
              (e[Symbol.iterator] = function () {
                return this;
              }),
            e
          );
          function t(t) {
            return function (e) {
              return (function (t) {
                if (n) throw new TypeError("Generator is already executing.");
                for (; i; )
                  try {
                    if (
                      ((n = 1),
                      o &&
                        (s =
                          2 & t[0]
                            ? o.return
                            : t[0]
                              ? o.throw || ((s = o.return) && s.call(o), 0)
                              : o.next) &&
                        !(s = s.call(o, t[1])).done)
                    )
                      return s;
                    switch (((o = 0), s && (t = [2 & t[0], s.value]), t[0])) {
                      case 0:
                      case 1:
                        s = t;
                        break;
                      case 4:
                        return (i.label++, { value: t[1], done: !1 });
                      case 5:
                        (i.label++, (o = t[1]), (t = [0]));
                        continue;
                      case 7:
                        ((t = i.ops.pop()), i.trys.pop());
                        continue;
                      default:
                        if (
                          !(s = 0 < (s = i.trys).length && s[s.length - 1]) &&
                          (6 === t[0] || 2 === t[0])
                        ) {
                          i = 0;
                          continue;
                        }
                        if (
                          3 === t[0] &&
                          (!s || (t[1] > s[0] && t[1] < s[3]))
                        ) {
                          i.label = t[1];
                          break;
                        }
                        if (6 === t[0] && i.label < s[1]) {
                          ((i.label = s[1]), (s = t));
                          break;
                        }
                        if (s && i.label < s[2]) {
                          ((i.label = s[2]), i.ops.push(t));
                          break;
                        }
                        (s[2] && i.ops.pop(), i.trys.pop());
                        continue;
                    }
                    t = a.call(r, i);
                  } catch (e) {
                    ((t = [6, e]), (o = 0));
                  } finally {
                    n = s = 0;
                  }
                if (5 & t[0]) throw t[1];
                return { value: t[0] ? t[1] : void 0, done: !0 };
              })([t, e]);
            };
          }
        };
      (((Wa = Va = Va || {}).EnUs = "en_us"),
        (Wa.EsEs = "es_es"),
        (Wa.FrFr = "fr_fr"),
        (Wa.IdId = "id_id"),
        (Wa.ItIt = "it_it"),
        (Wa.JaJp = "ja_jp"),
        (Wa.KoKr = "ko_kr"),
        (Wa.RuRu = "ru_ru"),
        (Wa.ThTh = "th_th"),
        (Wa.TrTr = "tr_tr"),
        (Wa.ViVn = "vi_vn"),
        (Wa.PtBr = "pt_br"),
        (Wa.DeDe = "de_de"),
        (Wa.ZhCn = "zh_cn"),
        (Wa.ZhTw = "zh_tw"),
        (Wa.BgBg = "bg_bg"),
        (Wa.BnBd = "bn_bd"),
        (Wa.CsCz = "cs_cz"),
        (Wa.DaDk = "da_dk"),
        (Wa.ElGr = "el_gr"),
        (Wa.EtEe = "et_ee"),
        (Wa.FiFi = "fi_fi"),
        (Wa.HiIn = "hi_in"),
        (Wa.HrHr = "hr_hr"),
        (Wa.HuHu = "hu_hu"),
        (Wa.KaGe = "ka_ge"),
        (Wa.KkKz = "kk_kz"),
        (Wa.KmKh = "km_kh"),
        (Wa.LtLt = "lt_lt"),
        (Wa.LvLv = "lv_lv"),
        (Wa.MsMy = "ms_my"),
        (Wa.MyMm = "my_mm"),
        (Wa.NbNo = "nb_no"),
        (Wa.NlNl = "nl_nl"),
        (Wa.FilPh = "fil_ph"),
        (Wa.PlPl = "pl_pl"),
        (Wa.RoRo = "ro_ro"),
        (Wa.UkUa = "uk_ua"),
        (Wa.SiLk = "si_lk"),
        (Wa.SkSk = "sk_sk"),
        (Wa.SlSl = "sl_sl"),
        (Wa.SqAl = "sq_al"),
        (Wa.BsBa = "bs_ba"),
        (Wa.SrRs = "sr_rs"),
        (Wa.SvSe = "sv_se"),
        (Wa.ZhCjv = "zh_cjv"));
      function Xa(n) {
        return {
          v2SupportedLanguagesGamesGameIdGet: function (t, r) {
            return $a(this, void 0, Promise, function () {
              var a;
              return Qa(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (d) {
                        var e = this;
                        return {
                          v2SupportedLanguagesGamesGameIdGet: function (u, l) {
                            return (
                              void 0 === l && (l = {}),
                              $a(e, void 0, Promise, function () {
                                var t, r, a, n, o, s, i;
                                return Qa(this, function (e) {
                                  if (null == u)
                                    throw new ka(
                                      "gameId",
                                      "Required parameter gameId was null or undefined when calling v2SupportedLanguagesGamesGameIdGet.",
                                    );
                                  return (
                                    (t =
                                      "/v2/supported-languages/games/{gameId}".replace(
                                        "{gameId}",
                                        encodeURIComponent(String(u)),
                                      )),
                                    (r = P.parse(t, !0)),
                                    d && (a = d.baseOptions),
                                    (n = Ka(Ka({ method: "GET" }, a), l)),
                                    (o = {}),
                                    (s = {}),
                                    (r.query = Ka(
                                      Ka(Ka({}, r.query), s),
                                      l.query,
                                    )),
                                    delete r.search,
                                    (i = a && a.headers ? a.headers : {}),
                                    (n.headers = Ka(
                                      Ka(Ka({}, o), i),
                                      l.headers,
                                    )),
                                    [2, { url: P.format(r), options: n }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(n).v2SupportedLanguagesGamesGameIdGet(t, r),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = _a));
                          var r = Ka(Ka({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Ya,
        Za =
          (Ja(en, (Ya = Da)),
          (en.prototype.v2SupportedLanguagesGamesGameIdGet = function (e, t) {
            var r = this;
            return Xa(this.configuration)
              .v2SupportedLanguagesGamesGameIdGet(e, t)
              .then(function (e) {
                return e(r.axios, r.basePath);
              });
          }),
          en);
      function en() {
        return (null !== Ya && Ya.apply(this, arguments)) || this;
      }
      function tn(e, t, r) {
        (void 0 === t && (t = vn),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var rn,
        an,
        nn = new wa(),
        on = new Za(),
        sn = new oa(),
        un = {
          getGameLanguageRolloutSettings: function () {
            return nn.v1SupportedLanguagesMetadataGet({ withCredentials: !0 });
          },
          getGameLanguages: function (e) {
            return nn.v1SupportedLanguagesGamesGameIdGet(e, {
              withCredentials: !0,
            });
          },
          getGameLanguagesV2: function (e) {
            return on.v2SupportedLanguagesGamesGameIdGet(e, {
              withCredentials: !0,
            });
          },
          addLanguages: function (e, t) {
            var r = t.map(function (e) {
              return { languageCodeType: or.Language, languageCode: e };
            });
            return nn.v1SupportedLanguagesGamesGameIdPatch(e, r, {
              withCredentials: !0,
            });
          },
          deleteLanguages: function (e, t) {
            var r = t.map(function (e) {
              return {
                languageCodeType: or.Language,
                languageCode: e,
                delete: !0,
              };
            });
            return nn.v1SupportedLanguagesGamesGameIdPatch(e, r, {
              withCredentials: !0,
            });
          },
          getAvailableLanguages: function () {
            return sn.v1LocalizationtableAvailableLanguagesGet();
          },
          getAutomaticTranslationStatus: function (e) {
            return nn.v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet(
              e,
              { withCredentials: !0 },
            );
          },
          setAutomaticTranslationStatus: function (e, t, r) {
            return nn.v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch(
              e,
              r,
              t,
              { withCredentials: !0 },
            );
          },
        },
        ln = new Ga(),
        dn = {
          getSourceLanguage: function (e) {
            return ln.v1SourceLanguageGamesGameIdGet(e, {
              withCredentials: !0,
            });
          },
          updateSourceLanguage: function (e, t) {
            return ln.v1SourceLanguageGamesGameIdPatch(e, t, {
              withCredentials: !0,
            });
          },
        },
        cn =
          ((rn = function (e, t) {
            return (rn =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (rn(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        vn = i.EnvironmentUrls.thumbnailsApi.replace(/\/+$/, ""),
        pn = ",",
        hn = ((an = Error), cn(mn, an), mn);
      function mn(e, t) {
        var r = an.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var gn,
        fn,
        Gn,
        yn,
        In,
        bn,
        Pn,
        wn =
          ((gn = function (e, t) {
            return (gn =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (gn(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        Cn = function () {
          return (Cn =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        },
        qn = function (e, s, i, u) {
          return new (i = i || Promise)(function (t, r) {
            function a(e) {
              try {
                o(u.next(e));
              } catch (e) {
                r(e);
              }
            }
            function n(e) {
              try {
                o(u.throw(e));
              } catch (e) {
                r(e);
              }
            }
            function o(e) {
              e.done
                ? t(e.value)
                : (function (t) {
                    return t instanceof i
                      ? t
                      : new i(function (e) {
                          e(t);
                        });
                  })(e.value).then(a, n);
            }
            o((u = u.apply(e, s || [])).next());
          });
        },
        Ln = function (r, a) {
          var n,
            o,
            s,
            e,
            i = {
              label: 0,
              sent: function () {
                if (1 & s[0]) throw s[1];
                return s[1];
              },
              trys: [],
              ops: [],
            };
          return (
            (e = { next: t(0), throw: t(1), return: t(2) }),
            "function" == typeof Symbol &&
              (e[Symbol.iterator] = function () {
                return this;
              }),
            e
          );
          function t(t) {
            return function (e) {
              return (function (t) {
                if (n) throw new TypeError("Generator is already executing.");
                for (; i; )
                  try {
                    if (
                      ((n = 1),
                      o &&
                        (s =
                          2 & t[0]
                            ? o.return
                            : t[0]
                              ? o.throw || ((s = o.return) && s.call(o), 0)
                              : o.next) &&
                        !(s = s.call(o, t[1])).done)
                    )
                      return s;
                    switch (((o = 0), s && (t = [2 & t[0], s.value]), t[0])) {
                      case 0:
                      case 1:
                        s = t;
                        break;
                      case 4:
                        return (i.label++, { value: t[1], done: !1 });
                      case 5:
                        (i.label++, (o = t[1]), (t = [0]));
                        continue;
                      case 7:
                        ((t = i.ops.pop()), i.trys.pop());
                        continue;
                      default:
                        if (
                          !(s = 0 < (s = i.trys).length && s[s.length - 1]) &&
                          (6 === t[0] || 2 === t[0])
                        ) {
                          i = 0;
                          continue;
                        }
                        if (
                          3 === t[0] &&
                          (!s || (t[1] > s[0] && t[1] < s[3]))
                        ) {
                          i.label = t[1];
                          break;
                        }
                        if (6 === t[0] && i.label < s[1]) {
                          ((i.label = s[1]), (s = t));
                          break;
                        }
                        if (s && i.label < s[2]) {
                          ((i.label = s[2]), i.ops.push(t));
                          break;
                        }
                        (s[2] && i.ops.pop(), i.trys.pop());
                        continue;
                    }
                    t = a.call(r, i);
                  } catch (e) {
                    ((t = [6, e]), (o = 0));
                  } finally {
                    n = s = 0;
                  }
                if (5 & t[0]) throw t[1];
                return { value: t[0] ? t[1] : void 0, done: !0 };
              })([t, e]);
            };
          }
        };
      (((Gn = fn = fn || {}).Avatar = "Avatar"),
        (Gn.AvatarHeadShot = "AvatarHeadShot"),
        (Gn.GameIcon = "GameIcon"),
        (Gn.BadgeIcon = "BadgeIcon"),
        (Gn.GameThumbnail = "GameThumbnail"),
        (Gn.GamePass = "GamePass"),
        (Gn.Asset = "Asset"),
        (Gn.BundleThumbnail = "BundleThumbnail"),
        (Gn.Outfit = "Outfit"),
        (Gn.GroupIcon = "GroupIcon"),
        (Gn.DeveloperProduct = "DeveloperProduct"),
        ((In = yn = yn || {}).Error = "Error"),
        (In.Completed = "Completed"),
        (In.InReview = "InReview"),
        (In.Pending = "Pending"),
        (In.Blocked = "Blocked"),
        ((Pn = bn = bn || {}).Error = "Error"),
        (Pn.Completed = "Completed"),
        (Pn.InReview = "InReview"),
        (Pn.Pending = "Pending"),
        (Pn.Blocked = "Blocked"));
      function An(u) {
        return {
          v1AssetsGet: function (t, r, n, o, s, i) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (p) {
                        var e = this;
                        return {
                          v1AssetsGet: function (i, u, l, d, c, v) {
                            return (
                              void 0 === v && (v = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "assetIds",
                                      "Required parameter assetIds was null or undefined when calling v1AssetsGet.",
                                    );
                                  return (
                                    "/v1/assets",
                                    (t = P.parse("/v1/assets", !0)),
                                    p && (r = p.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), v)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.assetIds = i.join(pn)),
                                    void 0 !== u && (o.returnPolicy = u),
                                    void 0 !== l && (o.size = l),
                                    void 0 !== d && (o.format = d),
                                    void 0 !== c && (o.isCircular = c),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      v.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      v.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(u).v1AssetsGet(t, r, n, o, s, i),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Tn,
        Sn =
          (wn(Rn, (Tn = tn)),
          (Rn.prototype.v1AssetsGet = function (e, t, r, a, n, o) {
            var s = this;
            return An(this.configuration)
              .v1AssetsGet(e, t, r, a, n, o)
              .then(function (e) {
                return e(s.axios, s.basePath);
              });
          }),
          Rn);
      function Rn() {
        return (null !== Tn && Tn.apply(this, arguments)) || this;
      }
      function Un(v) {
        var e = this;
        return {
          v1UsersAvatarGet: function (i, u, l, d, c) {
            return (
              void 0 === c && (c = {}),
              qn(e, void 0, Promise, function () {
                var t, r, a, n, o, s;
                return Ln(this, function (e) {
                  if (null == i)
                    throw new hn(
                      "userIds",
                      "Required parameter userIds was null or undefined when calling v1UsersAvatarGet.",
                    );
                  return (
                    "/v1/users/avatar",
                    (t = P.parse("/v1/users/avatar", !0)),
                    v && (r = v.baseOptions),
                    (a = Cn(Cn({ method: "GET" }, r), c)),
                    (n = {}),
                    (o = {}),
                    i && (o.userIds = i.join(pn)),
                    void 0 !== u && (o.size = u),
                    void 0 !== l && (o.format = l),
                    void 0 !== d && (o.isCircular = d),
                    (t.query = Cn(Cn(Cn({}, t.query), o), c.query)),
                    delete t.search,
                    (s = r && r.headers ? r.headers : {}),
                    (a.headers = Cn(Cn(Cn({}, n), s), c.headers)),
                    [2, { url: P.format(t), options: a }]
                  );
                });
              })
            );
          },
          v1UsersAvatarHeadshotGet: function (i, u, l, d, c) {
            return (
              void 0 === c && (c = {}),
              qn(e, void 0, Promise, function () {
                var t, r, a, n, o, s;
                return Ln(this, function (e) {
                  if (null == i)
                    throw new hn(
                      "userIds",
                      "Required parameter userIds was null or undefined when calling v1UsersAvatarHeadshotGet.",
                    );
                  return (
                    "/v1/users/avatar-headshot",
                    (t = P.parse("/v1/users/avatar-headshot", !0)),
                    v && (r = v.baseOptions),
                    (a = Cn(Cn({ method: "GET" }, r), c)),
                    (n = {}),
                    (o = {}),
                    i && (o.userIds = i.join(pn)),
                    void 0 !== u && (o.size = u),
                    void 0 !== l && (o.format = l),
                    void 0 !== d && (o.isCircular = d),
                    (t.query = Cn(Cn(Cn({}, t.query), o), c.query)),
                    delete t.search,
                    (s = r && r.headers ? r.headers : {}),
                    (a.headers = Cn(Cn(Cn({}, n), s), c.headers)),
                    [2, { url: P.format(t), options: a }]
                  );
                });
              })
            );
          },
        };
      }
      function On(i) {
        return {
          v1UsersAvatarGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [4, Un(i).v1UsersAvatarGet(t, r, n, o, s)];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
          v1UsersAvatarHeadshotGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [4, Un(i).v1UsersAvatarHeadshotGet(t, r, n, o, s)];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Dn,
        Bn =
          (wn(xn, (Dn = tn)),
          (xn.prototype.v1UsersAvatarGet = function (e, t, r, a, n) {
            var o = this;
            return On(this.configuration)
              .v1UsersAvatarGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          (xn.prototype.v1UsersAvatarHeadshotGet = function (e, t, r, a, n) {
            var o = this;
            return On(this.configuration)
              .v1UsersAvatarHeadshotGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          xn);
      function xn() {
        return (null !== Dn && Dn.apply(this, arguments)) || this;
      }
      function En(i) {
        return {
          v1BadgesIconsGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (v) {
                        var e = this;
                        return {
                          v1BadgesIconsGet: function (i, u, l, d, c) {
                            return (
                              void 0 === c && (c = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "badgeIds",
                                      "Required parameter badgeIds was null or undefined when calling v1BadgesIconsGet.",
                                    );
                                  return (
                                    "/v1/badges/icons",
                                    (t = P.parse("/v1/badges/icons", !0)),
                                    v && (r = v.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), c)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.badgeIds = i.join(pn)),
                                    void 0 !== u && (o.size = u),
                                    void 0 !== l && (o.format = l),
                                    void 0 !== d && (o.isCircular = d),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      c.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      c.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(i).v1BadgesIconsGet(t, r, n, o, s),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Fn,
        Nn =
          (wn(zn, (Fn = tn)),
          (zn.prototype.v1BadgesIconsGet = function (e, t, r, a, n) {
            var o = this;
            return En(this.configuration)
              .v1BadgesIconsGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          zn);
      function zn() {
        return (null !== Fn && Fn.apply(this, arguments)) || this;
      }
      function jn(n) {
        return {
          v1BatchPost: function (t, r) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (d) {
                        var e = this;
                        return {
                          v1BatchPost: function (u, l) {
                            return (
                              void 0 === l && (l = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s, i;
                                return Ln(this, function (e) {
                                  if (null == u)
                                    throw new hn(
                                      "requests",
                                      "Required parameter requests was null or undefined when calling v1BatchPost.",
                                    );
                                  return (
                                    "/v1/batch",
                                    (t = P.parse("/v1/batch", !0)),
                                    d && (r = d.baseOptions),
                                    (a = Cn(Cn({ method: "POST" }, r), l)),
                                    (o = {}),
                                    ((n = {})["Content-Type"] =
                                      "application/json"),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      l.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      l.headers,
                                    )),
                                    (i =
                                      "string" != typeof u ||
                                      "application/json" ===
                                        a.headers["Content-Type"]),
                                    (a.data = i
                                      ? JSON.stringify(void 0 !== u ? u : {})
                                      : u || ""),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(n).v1BatchPost(t, r),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var _n;
      (wn(kn, (_n = tn)),
        (kn.prototype.v1BatchPost = function (e, t) {
          var r = this;
          return jn(this.configuration)
            .v1BatchPost(e, t)
            .then(function (e) {
              return e(r.axios, r.basePath);
            });
        }));
      function kn() {
        return (null !== _n && _n.apply(this, arguments)) || this;
      }
      function Mn(i) {
        return {
          v1BundlesThumbnailsGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (v) {
                        var e = this;
                        return {
                          v1BundlesThumbnailsGet: function (i, u, l, d, c) {
                            return (
                              void 0 === c && (c = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "bundleIds",
                                      "Required parameter bundleIds was null or undefined when calling v1BundlesThumbnailsGet.",
                                    );
                                  return (
                                    "/v1/bundles/thumbnails",
                                    (t = P.parse("/v1/bundles/thumbnails", !0)),
                                    v && (r = v.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), c)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.bundleIds = i.join(pn)),
                                    void 0 !== u && (o.size = u),
                                    void 0 !== l && (o.format = l),
                                    void 0 !== d && (o.isCircular = d),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      c.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      c.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(i).v1BundlesThumbnailsGet(t, r, n, o, s),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Hn,
        Vn =
          (wn(Wn, (Hn = tn)),
          (Wn.prototype.v1BundlesThumbnailsGet = function (e, t, r, a, n) {
            var o = this;
            return Mn(this.configuration)
              .v1BundlesThumbnailsGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          Wn);
      function Wn() {
        return (null !== Hn && Hn.apply(this, arguments)) || this;
      }
      function Jn(i) {
        return {
          v1DeveloperProductsIconsGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (v) {
                        var e = this;
                        return {
                          v1DeveloperProductsIconsGet: function (
                            i,
                            u,
                            l,
                            d,
                            c,
                          ) {
                            return (
                              void 0 === c && (c = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "developerProductIds",
                                      "Required parameter developerProductIds was null or undefined when calling v1DeveloperProductsIconsGet.",
                                    );
                                  return (
                                    "/v1/developer-products/icons",
                                    (t = P.parse(
                                      "/v1/developer-products/icons",
                                      !0,
                                    )),
                                    v && (r = v.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), c)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.developerProductIds = i.join(pn)),
                                    void 0 !== u && (o.size = u),
                                    void 0 !== l && (o.format = l),
                                    void 0 !== d && (o.isCircular = d),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      c.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      c.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(i).v1DeveloperProductsIconsGet(t, r, n, o, s),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Kn,
        $n =
          (wn(Qn, (Kn = tn)),
          (Qn.prototype.v1DeveloperProductsIconsGet = function (e, t, r, a, n) {
            var o = this;
            return Jn(this.configuration)
              .v1DeveloperProductsIconsGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          Qn);
      function Qn() {
        return (null !== Kn && Kn.apply(this, arguments)) || this;
      }
      function Xn(i) {
        return {
          v1GamePassesGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (v) {
                        var e = this;
                        return {
                          v1GamePassesGet: function (i, u, l, d, c) {
                            return (
                              void 0 === c && (c = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "gamePassIds",
                                      "Required parameter gamePassIds was null or undefined when calling v1GamePassesGet.",
                                    );
                                  return (
                                    "/v1/game-passes",
                                    (t = P.parse("/v1/game-passes", !0)),
                                    v && (r = v.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), c)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.gamePassIds = i.join(pn)),
                                    void 0 !== u && (o.size = u),
                                    void 0 !== l && (o.format = l),
                                    void 0 !== d && (o.isCircular = d),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      c.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      c.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(i).v1GamePassesGet(t, r, n, o, s),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var Yn,
        Zn =
          (wn(eo, (Yn = tn)),
          (eo.prototype.v1GamePassesGet = function (e, t, r, a, n) {
            var o = this;
            return Xn(this.configuration)
              .v1GamePassesGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          eo);
      function eo() {
        return (null !== Yn && Yn.apply(this, arguments)) || this;
      }
      function to(h) {
        var e = this;
        return {
          v1GamesIconsGet: function (i, u, l, d, c, v) {
            return (
              void 0 === v && (v = {}),
              qn(e, void 0, Promise, function () {
                var t, r, a, n, o, s;
                return Ln(this, function (e) {
                  if (null == i)
                    throw new hn(
                      "universeIds",
                      "Required parameter universeIds was null or undefined when calling v1GamesIconsGet.",
                    );
                  return (
                    "/v1/games/icons",
                    (t = P.parse("/v1/games/icons", !0)),
                    h && (r = h.baseOptions),
                    (a = Cn(Cn({ method: "GET" }, r), v)),
                    (n = {}),
                    (o = {}),
                    i && (o.universeIds = i.join(pn)),
                    void 0 !== u && (o.returnPolicy = u),
                    void 0 !== l && (o.size = l),
                    void 0 !== d && (o.format = d),
                    void 0 !== c && (o.isCircular = c),
                    (t.query = Cn(Cn(Cn({}, t.query), o), v.query)),
                    delete t.search,
                    (s = r && r.headers ? r.headers : {}),
                    (a.headers = Cn(Cn(Cn({}, n), s), v.headers)),
                    [2, { url: P.format(t), options: a }]
                  );
                });
              })
            );
          },
          v1GamesMultigetThumbnailsGet: function (i, u, l, d, c, v, p) {
            return (
              void 0 === p && (p = {}),
              qn(e, void 0, Promise, function () {
                var t, r, a, n, o, s;
                return Ln(this, function (e) {
                  if (null == i)
                    throw new hn(
                      "universeIds",
                      "Required parameter universeIds was null or undefined when calling v1GamesMultigetThumbnailsGet.",
                    );
                  return (
                    "/v1/games/multiget/thumbnails",
                    (t = P.parse("/v1/games/multiget/thumbnails", !0)),
                    h && (r = h.baseOptions),
                    (a = Cn(Cn({ method: "GET" }, r), p)),
                    (n = {}),
                    (o = {}),
                    i && (o.universeIds = i.join(pn)),
                    void 0 !== u && (o.countPerUniverse = u),
                    void 0 !== l && (o.defaults = l),
                    void 0 !== d && (o.size = d),
                    void 0 !== c && (o.format = c),
                    void 0 !== v && (o.isCircular = v),
                    (t.query = Cn(Cn(Cn({}, t.query), o), p.query)),
                    delete t.search,
                    (s = r && r.headers ? r.headers : {}),
                    (a.headers = Cn(Cn(Cn({}, n), s), p.headers)),
                    [2, { url: P.format(t), options: a }]
                  );
                });
              })
            );
          },
          v1GamesUniverseIdThumbnailsGet: function (u, l, d, c, v, p) {
            return (
              void 0 === p && (p = {}),
              qn(e, void 0, Promise, function () {
                var t, r, a, n, o, s, i;
                return Ln(this, function (e) {
                  if (null == u)
                    throw new hn(
                      "universeId",
                      "Required parameter universeId was null or undefined when calling v1GamesUniverseIdThumbnailsGet.",
                    );
                  if (null == l)
                    throw new hn(
                      "thumbnailIds",
                      "Required parameter thumbnailIds was null or undefined when calling v1GamesUniverseIdThumbnailsGet.",
                    );
                  return (
                    (t = "/v1/games/{universeId}/thumbnails".replace(
                      "{universeId}",
                      encodeURIComponent(String(u)),
                    )),
                    (r = P.parse(t, !0)),
                    h && (a = h.baseOptions),
                    (n = Cn(Cn({ method: "GET" }, a), p)),
                    (o = {}),
                    (s = {}),
                    l && (s.thumbnailIds = l.join(pn)),
                    void 0 !== d && (s.size = d),
                    void 0 !== c && (s.format = c),
                    void 0 !== v && (s.isCircular = v),
                    (r.query = Cn(Cn(Cn({}, r.query), s), p.query)),
                    delete r.search,
                    (i = a && a.headers ? a.headers : {}),
                    (n.headers = Cn(Cn(Cn({}, o), i), p.headers)),
                    [2, { url: P.format(r), options: n }]
                  );
                });
              })
            );
          },
        };
      }
      function ro(l) {
        return {
          v1GamesIconsGet: function (t, r, n, o, s, i) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [4, to(l).v1GamesIconsGet(t, r, n, o, s, i)];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
          v1GamesMultigetThumbnailsGet: function (t, r, n, o, s, i, u) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      to(l).v1GamesMultigetThumbnailsGet(t, r, n, o, s, i, u),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
          v1GamesUniverseIdThumbnailsGet: function (t, r, n, o, s, i) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      to(l).v1GamesUniverseIdThumbnailsGet(t, r, n, o, s, i),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var ao,
        no =
          (wn(oo, (ao = tn)),
          (oo.prototype.v1GamesIconsGet = function (e, t, r, a, n, o) {
            var s = this;
            return ro(this.configuration)
              .v1GamesIconsGet(e, t, r, a, n, o)
              .then(function (e) {
                return e(s.axios, s.basePath);
              });
          }),
          (oo.prototype.v1GamesMultigetThumbnailsGet = function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
          ) {
            var i = this;
            return ro(this.configuration)
              .v1GamesMultigetThumbnailsGet(e, t, r, a, n, o, s)
              .then(function (e) {
                return e(i.axios, i.basePath);
              });
          }),
          (oo.prototype.v1GamesUniverseIdThumbnailsGet = function (
            e,
            t,
            r,
            a,
            n,
            o,
          ) {
            var s = this;
            return ro(this.configuration)
              .v1GamesUniverseIdThumbnailsGet(e, t, r, a, n, o)
              .then(function (e) {
                return e(s.axios, s.basePath);
              });
          }),
          oo);
      function oo() {
        return (null !== ao && ao.apply(this, arguments)) || this;
      }
      function so(i) {
        return {
          v1GroupsIconsGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (v) {
                        var e = this;
                        return {
                          v1GroupsIconsGet: function (i, u, l, d, c) {
                            return (
                              void 0 === c && (c = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "groupIds",
                                      "Required parameter groupIds was null or undefined when calling v1GroupsIconsGet.",
                                    );
                                  return (
                                    "/v1/groups/icons",
                                    (t = P.parse("/v1/groups/icons", !0)),
                                    v && (r = v.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), c)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.groupIds = i.join(pn)),
                                    void 0 !== u && (o.size = u),
                                    void 0 !== l && (o.format = l),
                                    void 0 !== d && (o.isCircular = d),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      c.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      c.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(i).v1GroupsIconsGet(t, r, n, o, s),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var io,
        uo =
          (wn(lo, (io = tn)),
          (lo.prototype.v1GroupsIconsGet = function (e, t, r, a, n) {
            var o = this;
            return so(this.configuration)
              .v1GroupsIconsGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          lo);
      function lo() {
        return (null !== io && io.apply(this, arguments)) || this;
      }
      function co(i) {
        return {
          v1UsersOutfitsGet: function (t, r, n, o, s) {
            return qn(this, void 0, Promise, function () {
              var a;
              return Ln(this, function (e) {
                switch (e.label) {
                  case 0:
                    return [
                      4,
                      (function (v) {
                        var e = this;
                        return {
                          v1UsersOutfitsGet: function (i, u, l, d, c) {
                            return (
                              void 0 === c && (c = {}),
                              qn(e, void 0, Promise, function () {
                                var t, r, a, n, o, s;
                                return Ln(this, function (e) {
                                  if (null == i)
                                    throw new hn(
                                      "userOutfitIds",
                                      "Required parameter userOutfitIds was null or undefined when calling v1UsersOutfitsGet.",
                                    );
                                  return (
                                    "/v1/users/outfits",
                                    (t = P.parse("/v1/users/outfits", !0)),
                                    v && (r = v.baseOptions),
                                    (a = Cn(Cn({ method: "GET" }, r), c)),
                                    (n = {}),
                                    (o = {}),
                                    i && (o.userOutfitIds = i.join(pn)),
                                    void 0 !== u && (o.size = u),
                                    void 0 !== l && (o.format = l),
                                    void 0 !== d && (o.isCircular = d),
                                    (t.query = Cn(
                                      Cn(Cn({}, t.query), o),
                                      c.query,
                                    )),
                                    delete t.search,
                                    (s = r && r.headers ? r.headers : {}),
                                    (a.headers = Cn(
                                      Cn(Cn({}, n), s),
                                      c.headers,
                                    )),
                                    [2, { url: P.format(t), options: a }]
                                  );
                                });
                              })
                            );
                          },
                        };
                      })(i).v1UsersOutfitsGet(t, r, n, o, s),
                    ];
                  case 1:
                    return (
                      (a = e.sent()),
                      [
                        2,
                        function (e, t) {
                          (void 0 === e && (e = y.a), void 0 === t && (t = vn));
                          var r = Cn(Cn({}, a.options), { url: t + a.url });
                          return e.request(r);
                        },
                      ]
                    );
                }
              });
            });
          },
        };
      }
      var vo,
        po =
          (wn(ho, (vo = tn)),
          (ho.prototype.v1UsersOutfitsGet = function (e, t, r, a, n) {
            var o = this;
            return co(this.configuration)
              .v1UsersOutfitsGet(e, t, r, a, n)
              .then(function (e) {
                return e(o.axios, o.basePath);
              });
          }),
          ho);
      function ho() {
        return (null !== vo && vo.apply(this, arguments)) || this;
      }
      var mo,
        go,
        fo,
        Go,
        yo,
        Io,
        bo,
        Po = new no(),
        wo = new Zn();
      (((go = mo = mo || {}).PlaceHolder = "PlaceHolder"),
        (go.AutoGenerated = "AutoGenerated"),
        (go.ForceAutoGenerated = "ForceAutoGenerated"),
        ((Go = fo = fo || {}).Large = "150x150"),
        (Go.Default = "50x50"),
        ((Io = yo = yo || {}).width768 = "768x432"),
        (Io.width576 = "576x324"),
        (Io.width480 = "480x270"),
        (Io.width384 = "384x216"),
        (Io.width256 = "256x144"),
        ((bo = bo || {}).Png = "Png"));
      function Co(e, t, r) {
        (void 0 === t && (t = Uo),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var qo,
        Lo,
        Ao = {
          getIcons: function (e, t, r, a, n) {
            return Po.v1GamesIconsGet(e, t, r, a, n, { withCredentials: !0 });
          },
          getGameThumbnails: function (e, t, r, a, n, o) {
            return Po.v1GamesMultigetThumbnailsGet(e, t, r, a, n, o, {
              withCredentials: !0,
            });
          },
          getGamePassIcons: function (e, t, r, a) {
            return wo.v1GamePassesGet(e, t, r, a, { withCredentials: !0 });
          },
          getThumbnailsByThumbnailIds: function (e, t, r, a, n) {
            return Po.v1GamesUniverseIdThumbnailsGet(e, t, r, a, n, {
              withCredentials: !0,
            });
          },
          ReturnPolicy: mo,
          Size: fo,
          GameThumbnailSize: yo,
          FileType: bo,
        },
        To = new Ta(),
        So = {
          getMetadata: function () {
            return To.v1TranslationAnalyticsMetadataGet({
              withCredentials: !0,
            });
          },
          requestReport: function (e, t, r, a, n) {
            var o = {
              startDateTime: t,
              endDateTime: r,
              reportType: a,
              reportSubjectTargetId: n,
            };
            return To.v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost(
              e,
              o,
              { withCredentials: !0 },
            );
          },
          downloadReport: function (e, t, r, a, n) {
            return To.v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet(
              e,
              t,
              r,
              a,
              n,
              { withCredentials: !0, responseType: "arraybuffer" },
            );
          },
        },
        Ro =
          ((qo = function (e, t) {
            return (qo =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (qo(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        Uo = i.EnvironmentUrls.gamesApi.replace(/\/+$/, ""),
        Oo = ",",
        Do = ((Lo = Error), Ro(Bo, Lo), Bo);
      function Bo(e, t) {
        var r = Lo.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var xo,
        Eo,
        Fo,
        No,
        zo,
        jo,
        _o,
        ko,
        Mo,
        Ho,
        Vo,
        Wo,
        Jo,
        Ko =
          ((xo = function (e, t) {
            return (xo =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (xo(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        $o = function () {
          return ($o =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      (((Fo = Eo = Eo || {}).GamesDefaultSorts = "GamesDefaultSorts"),
        (Fo.GamesAllSorts = "GamesAllSorts"),
        (Fo.HomeSorts = "HomeSorts"),
        (Fo.ChatSorts = "ChatSorts"),
        (Fo.UnifiedHomeSorts = "UnifiedHomeSorts"),
        (Fo.AbTestSorts = "AbTestSorts"),
        (Fo.GamesPageAbTestSorts1 = "GamesPageAbTestSorts1"),
        (Fo.GamesPageAbTestSorts2 = "GamesPageAbTestSorts2"),
        ((zo = No = No || {}).MorphToR6 = "MorphToR6"),
        (zo.PlayerChoice = "PlayerChoice"),
        (zo.MorphToR15 = "MorphToR15"),
        ((_o = jo = jo || {}).UnplayableOtherReason = "UnplayableOtherReason"),
        (_o.Playable = "Playable"),
        (_o.GuestProhibited = "GuestProhibited"),
        (_o.GameUnapproved = "GameUnapproved"),
        (_o.IncorrectConfiguration = "IncorrectConfiguration"),
        (_o.UniverseRootPlaceIsPrivate = "UniverseRootPlaceIsPrivate"),
        (_o.InsufficientPermissionFriendsOnly =
          "InsufficientPermissionFriendsOnly"),
        (_o.InsufficientPermissionGroupOnly =
          "InsufficientPermissionGroupOnly"),
        (_o.DeviceRestricted = "DeviceRestricted"),
        (_o.UnderReview = "UnderReview"),
        (_o.PurchaseRequired = "PurchaseRequired"),
        (_o.AccountRestricted = "AccountRestricted"),
        (_o.TemporarilyUnavailable = "TemporarilyUnavailable"),
        ((Mo = ko = ko || {}).Facebook = "Facebook"),
        (Mo.Twitter = "Twitter"),
        (Mo.YouTube = "YouTube"),
        (Mo.Twitch = "Twitch"),
        (Mo.GooglePlus = "GooglePlus"),
        (Mo.Discord = "Discord"),
        (Mo.RobloxGroup = "RobloxGroup"),
        ((Vo = Ho = Ho || {}).Asc = "Asc"),
        (Vo.Desc = "Desc"),
        ((Jo = Wo = Wo || {}).Forward = "Forward"),
        (Jo.Backward = "Backward"));
      function Qo(u) {
        return {
          v1GamesUniverseIdFavoritesCountGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdFavoritesCountGet.",
              );
            var r,
              a = "/v1/games/{universeId}/favorites/count".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GamesUniverseIdFavoritesGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdFavoritesGet.",
              );
            var r,
              a = "/v1/games/{universeId}/favorites".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GamesUniverseIdFavoritesPost: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdFavoritesPost.",
              );
            if (null == t)
              throw new Do(
                "request",
                "Required parameter request was null or undefined when calling v1GamesUniverseIdFavoritesPost.",
              );
            var a,
              n = "/v1/games/{universeId}/favorites".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = $o($o({ method: "POST" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
        };
      }
      function Xo(n) {
        return {
          v1GamesUniverseIdFavoritesCountGet: function (e, t) {
            var a = Qo(n).v1GamesUniverseIdFavoritesCountGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesUniverseIdFavoritesGet: function (e, t) {
            var a = Qo(n).v1GamesUniverseIdFavoritesGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesUniverseIdFavoritesPost: function (e, t, r) {
            var a = Qo(n).v1GamesUniverseIdFavoritesPost(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var Yo;
      (Ko(Zo, (Yo = Co)),
        (Zo.prototype.v1GamesUniverseIdFavoritesCountGet = function (e, t) {
          return Xo(this.configuration).v1GamesUniverseIdFavoritesCountGet(
            e,
            t,
          )(this.axios, this.basePath);
        }),
        (Zo.prototype.v1GamesUniverseIdFavoritesGet = function (e, t) {
          return Xo(this.configuration).v1GamesUniverseIdFavoritesGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (Zo.prototype.v1GamesUniverseIdFavoritesPost = function (e, t, r) {
          return Xo(this.configuration).v1GamesUniverseIdFavoritesPost(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }));
      function Zo() {
        return (null !== Yo && Yo.apply(this, arguments)) || this;
      }
      function es(s) {
        return {
          v1GamesUniverseIdGamePassesGet: function (e, t, r, a, n) {
            var o = (function (d) {
              return {
                v1GamesUniverseIdGamePassesGet: function (e, t, r, a, n) {
                  if ((void 0 === n && (n = {}), null == e))
                    throw new Do(
                      "universeId",
                      "Required parameter universeId was null or undefined when calling v1GamesUniverseIdGamePassesGet.",
                    );
                  var o,
                    s = "/v1/games/{universeId}/game-passes".replace(
                      "{universeId}",
                      encodeURIComponent(String(e)),
                    ),
                    i = P.parse(s, !0);
                  d && (o = d.baseOptions);
                  var u = $o($o({ method: "GET" }, o), n),
                    l = {};
                  return (
                    void 0 !== t && (l.sortOrder = t),
                    void 0 !== r && (l.limit = r),
                    void 0 !== a && (l.cursor = a),
                    (i.query = $o($o($o({}, i.query), l), n.query)),
                    delete i.search,
                    (u.headers = $o($o({}, {}), n.headers)),
                    { url: P.format(i), options: u }
                  );
                },
              };
            })(s).v1GamesUniverseIdGamePassesGet(e, t, r, a, n);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, o.options), { url: t + o.url });
              return e.request(r);
            };
          },
        };
      }
      var ts,
        rs =
          (Ko(as, (ts = Co)),
          (as.prototype.v1GamesUniverseIdGamePassesGet = function (
            e,
            t,
            r,
            a,
            n,
          ) {
            return es(this.configuration).v1GamesUniverseIdGamePassesGet(
              e,
              t,
              r,
              a,
              n,
            )(this.axios, this.basePath);
          }),
          as);
      function as() {
        return (null !== ts && ts.apply(this, arguments)) || this;
      }
      function ns(I) {
        return {
          v1GamesGameThumbnailGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Do(
                "imageToken",
                "Required parameter imageToken was null or undefined when calling v1GamesGameThumbnailGet.",
              );
            var n,
              o = P.parse("/v1/games/game-thumbnail", !0);
            I && (n = I.baseOptions);
            var s = $o($o({ method: "GET" }, n), a),
              i = {};
            return (
              void 0 !== e && (i.imageToken = e),
              void 0 !== t && (i.height = t),
              void 0 !== r && (i.width = r),
              (o.query = $o($o($o({}, o.query), i), a.query)),
              delete o.search,
              (s.headers = $o($o({}, {}), a.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1GamesGameThumbnailsGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Do(
                "imageTokens",
                "Required parameter imageTokens was null or undefined when calling v1GamesGameThumbnailsGet.",
              );
            var n,
              o = P.parse("/v1/games/game-thumbnails", !0);
            I && (n = I.baseOptions);
            var s = $o($o({ method: "GET" }, n), a),
              i = {};
            return (
              e && (i.imageTokens = e),
              void 0 !== t && (i.height = t),
              void 0 !== r && (i.width = r),
              (o.query = $o($o($o({}, o.query), i), a.query)),
              delete o.search,
              (s.headers = $o($o({}, {}), a.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1GamesGamesProductInfoGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeIds",
                "Required parameter universeIds was null or undefined when calling v1GamesGamesProductInfoGet.",
              );
            var r,
              a = P.parse("/v1/games/games-product-info", !0);
            I && (r = I.baseOptions);
            var n = $o($o({ method: "GET" }, r), t),
              o = {};
            return (
              e && (o.universeIds = e.join(Oo)),
              (a.query = $o($o($o({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = $o($o({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1GamesGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeIds",
                "Required parameter universeIds was null or undefined when calling v1GamesGet.",
              );
            var r,
              a = P.parse("/v1/games", !0);
            I && (r = I.baseOptions);
            var n = $o($o({ method: "GET" }, r), t),
              o = {};
            return (
              e && (o.universeIds = e.join(Oo)),
              (a.query = $o($o($o({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = $o($o({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1GamesListGet: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
          ) {
            void 0 === m && (m = {});
            var g,
              f = P.parse("/v1/games/list", !0);
            I && (g = I.baseOptions);
            var G = $o($o({ method: "GET" }, g), m),
              y = {};
            return (
              void 0 !== e && (y["model.sortToken"] = e),
              void 0 !== t && (y["model.gameFilter"] = t),
              void 0 !== r && (y["model.timeFilter"] = r),
              void 0 !== a && (y["model.genreFilter"] = a),
              void 0 !== n && (y["model.exclusiveStartId"] = n),
              void 0 !== o && (y["model.sortOrder"] = o),
              void 0 !== s && (y["model.gameSetTargetId"] = s),
              void 0 !== i && (y["model.keyword"] = i),
              void 0 !== u && (y["model.startRows"] = u),
              void 0 !== l && (y["model.maxRows"] = l),
              void 0 !== d && (y["model.isKeywordSuggestionEnabled"] = d),
              void 0 !== c && (y["model.contextCountryRegionId"] = c),
              void 0 !== v && (y["model.contextUniverseId"] = v),
              void 0 !== p && (y["model.pageId"] = p),
              void 0 !== h && (y["model.sortPosition"] = h),
              (f.query = $o($o($o({}, f.query), y), m.query)),
              delete f.search,
              (G.headers = $o($o({}, {}), m.headers)),
              { url: P.format(f), options: G }
            );
          },
          v1GamesMultigetPlaceDetailsGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "placeIds",
                "Required parameter placeIds was null or undefined when calling v1GamesMultigetPlaceDetailsGet.",
              );
            var r,
              a = P.parse("/v1/games/multiget-place-details", !0);
            I && (r = I.baseOptions);
            var n = $o($o({ method: "GET" }, r), t),
              o = {};
            return (
              e && (o.placeIds = e),
              (a.query = $o($o($o({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = $o($o({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1GamesMultigetPlayabilityStatusGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeIds",
                "Required parameter universeIds was null or undefined when calling v1GamesMultigetPlayabilityStatusGet.",
              );
            var r,
              a = P.parse("/v1/games/multiget-playability-status", !0);
            I && (r = I.baseOptions);
            var n = $o($o({ method: "GET" }, r), t),
              o = {};
            return (
              e && (o.universeIds = e.join(Oo)),
              (a.query = $o($o($o({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = $o($o({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1GamesPlaceIdServersServerTypeGet: function (e, t, r, a, n, o) {
            if ((void 0 === o && (o = {}), null == e))
              throw new Do(
                "placeId",
                "Required parameter placeId was null or undefined when calling v1GamesPlaceIdServersServerTypeGet.",
              );
            if (null == t)
              throw new Do(
                "serverType",
                "Required parameter serverType was null or undefined when calling v1GamesPlaceIdServersServerTypeGet.",
              );
            var s,
              i = "/v1/games/{placeId}/servers/{serverType}"
                .replace("{placeId}", encodeURIComponent(String(e)))
                .replace("{serverType}", encodeURIComponent(String(t))),
              u = P.parse(i, !0);
            I && (s = I.baseOptions);
            var l = $o($o({ method: "GET" }, s), o),
              d = {};
            return (
              void 0 !== r && (d.sortOrder = r),
              void 0 !== a && (d.limit = a),
              void 0 !== n && (d.cursor = n),
              (u.query = $o($o($o({}, u.query), d), o.query)),
              delete u.search,
              (l.headers = $o($o({}, {}), o.headers)),
              { url: P.format(u), options: l }
            );
          },
          v1GamesPlacesPlaceIdMetadataPost: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "placeId",
                "Required parameter placeId was null or undefined when calling v1GamesPlacesPlaceIdMetadataPost.",
              );
            if (null == t)
              throw new Do(
                "request",
                "Required parameter request was null or undefined when calling v1GamesPlacesPlaceIdMetadataPost.",
              );
            var a,
              n = "/v1/games/places/{placeId}/metadata".replace(
                "{placeId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            I && (a = I.baseOptions);
            var s = $o($o({ method: "POST" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1GamesRecommendationsAlgorithmAlgorithmNameGet: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Do(
                "algorithmName",
                "Required parameter algorithmName was null or undefined when calling v1GamesRecommendationsAlgorithmAlgorithmNameGet.",
              );
            var n,
              o = "/v1/games/recommendations/algorithm/{algorithmName}".replace(
                "{algorithmName}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            I && (n = I.baseOptions);
            var i = $o($o({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u["model.paginationKey"] = t),
              void 0 !== r && (u["model.maxRows"] = r),
              (s.query = $o($o($o({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = $o($o({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1GamesRecommendationsGameUniverseIdGet: function (e, t, r, a) {
            if ((void 0 === a && (a = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesRecommendationsGameUniverseIdGet.",
              );
            var n,
              o = "/v1/games/recommendations/game/{universeId}".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              s = P.parse(o, !0);
            I && (n = I.baseOptions);
            var i = $o($o({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u["model.paginationKey"] = t),
              void 0 !== r && (u["model.maxRows"] = r),
              (s.query = $o($o($o({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = $o($o({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
          v1GamesSortsGet: function (e, t) {
            void 0 === t && (t = {});
            var r,
              a = P.parse("/v1/games/sorts", !0);
            I && (r = I.baseOptions);
            var n = $o($o({ method: "GET" }, r), t),
              o = {};
            return (
              void 0 !== e && (o["model.gameSortsContext"] = e),
              (a.query = $o($o($o({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = $o($o({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
          v1GamesUniverseIdIconGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdIconGet.",
              );
            var r,
              a = "/v1/games/{universeId}/icon".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            I && (r = I.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GamesUniverseIdMediaGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdMediaGet.",
              );
            var r,
              a = "/v1/games/{universeId}/media".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            I && (r = I.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
        };
      }
      function os(f) {
        return {
          v1GamesGameThumbnailGet: function (e, t, r, a) {
            var n = ns(f).v1GamesGameThumbnailGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GamesGameThumbnailsGet: function (e, t, r, a) {
            var n = ns(f).v1GamesGameThumbnailsGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GamesGamesProductInfoGet: function (e, t) {
            var a = ns(f).v1GamesGamesProductInfoGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesGet: function (e, t) {
            var a = ns(f).v1GamesGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesListGet: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
          ) {
            var g = ns(f).v1GamesListGet(
              e,
              t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v,
              p,
              h,
              m,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, g.options), { url: t + g.url });
              return e.request(r);
            };
          },
          v1GamesMultigetPlaceDetailsGet: function (e, t) {
            var a = ns(f).v1GamesMultigetPlaceDetailsGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesMultigetPlayabilityStatusGet: function (e, t) {
            var a = ns(f).v1GamesMultigetPlayabilityStatusGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesPlaceIdServersServerTypeGet: function (e, t, r, a, n, o) {
            var s = ns(f).v1GamesPlaceIdServersServerTypeGet(e, t, r, a, n, o);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, s.options), { url: t + s.url });
              return e.request(r);
            };
          },
          v1GamesPlacesPlaceIdMetadataPost: function (e, t, r) {
            var a = ns(f).v1GamesPlacesPlaceIdMetadataPost(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesRecommendationsAlgorithmAlgorithmNameGet: function (
            e,
            t,
            r,
            a,
          ) {
            var n = ns(f).v1GamesRecommendationsAlgorithmAlgorithmNameGet(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GamesRecommendationsGameUniverseIdGet: function (e, t, r, a) {
            var n = ns(f).v1GamesRecommendationsGameUniverseIdGet(e, t, r, a);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
          v1GamesSortsGet: function (e, t) {
            var a = ns(f).v1GamesSortsGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesUniverseIdIconGet: function (e, t) {
            var a = ns(f).v1GamesUniverseIdIconGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesUniverseIdMediaGet: function (e, t) {
            var a = ns(f).v1GamesUniverseIdMediaGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var ss,
        is =
          (Ko(us, (ss = Co)),
          (us.prototype.v1GamesGameThumbnailGet = function (e, t, r, a) {
            return os(this.configuration).v1GamesGameThumbnailGet(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesGameThumbnailsGet = function (e, t, r, a) {
            return os(this.configuration).v1GamesGameThumbnailsGet(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesGamesProductInfoGet = function (e, t) {
            return os(this.configuration).v1GamesGamesProductInfoGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (us.prototype.v1GamesGet = function (e, t) {
            return os(this.configuration).v1GamesGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (us.prototype.v1GamesListGet = function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
          ) {
            return os(this.configuration).v1GamesListGet(
              e,
              t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v,
              p,
              h,
              m,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesMultigetPlaceDetailsGet = function (e, t) {
            return os(this.configuration).v1GamesMultigetPlaceDetailsGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (us.prototype.v1GamesMultigetPlayabilityStatusGet = function (e, t) {
            return os(this.configuration).v1GamesMultigetPlayabilityStatusGet(
              e,
              t,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesPlaceIdServersServerTypeGet = function (
            e,
            t,
            r,
            a,
            n,
            o,
          ) {
            return os(this.configuration).v1GamesPlaceIdServersServerTypeGet(
              e,
              t,
              r,
              a,
              n,
              o,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesPlacesPlaceIdMetadataPost = function (e, t, r) {
            return os(this.configuration).v1GamesPlacesPlaceIdMetadataPost(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesRecommendationsAlgorithmAlgorithmNameGet =
            function (e, t, r, a) {
              return os(
                this.configuration,
              ).v1GamesRecommendationsAlgorithmAlgorithmNameGet(
                e,
                t,
                r,
                a,
              )(this.axios, this.basePath);
            }),
          (us.prototype.v1GamesRecommendationsGameUniverseIdGet = function (
            e,
            t,
            r,
            a,
          ) {
            return os(
              this.configuration,
            ).v1GamesRecommendationsGameUniverseIdGet(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
          (us.prototype.v1GamesSortsGet = function (e, t) {
            return os(this.configuration).v1GamesSortsGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (us.prototype.v1GamesUniverseIdIconGet = function (e, t) {
            return os(this.configuration).v1GamesUniverseIdIconGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          (us.prototype.v1GamesUniverseIdMediaGet = function (e, t) {
            return os(this.configuration).v1GamesUniverseIdMediaGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
          us);
      function us() {
        return (null !== ss && ss.apply(this, arguments)) || this;
      }
      function ls(r) {
        return {
          v1GamesUniverseIdSocialLinksListGet: function (e, t) {
            var a = (function (s) {
              return {
                v1GamesUniverseIdSocialLinksListGet: function (e, t) {
                  if ((void 0 === t && (t = {}), null == e))
                    throw new Do(
                      "universeId",
                      "Required parameter universeId was null or undefined when calling v1GamesUniverseIdSocialLinksListGet.",
                    );
                  var r,
                    a = "/v1/games/{universeId}/social-links/list".replace(
                      "{universeId}",
                      encodeURIComponent(String(e)),
                    ),
                    n = P.parse(a, !0);
                  s && (r = s.baseOptions);
                  var o = $o($o({ method: "GET" }, r), t);
                  return (
                    (n.query = $o($o($o({}, n.query), {}), t.query)),
                    delete n.search,
                    (o.headers = $o($o({}, {}), t.headers)),
                    { url: P.format(n), options: o }
                  );
                },
              };
            })(r).v1GamesUniverseIdSocialLinksListGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var ds;
      (Ko(cs, (ds = Co)),
        (cs.prototype.v1GamesUniverseIdSocialLinksListGet = function (e, t) {
          return ls(this.configuration).v1GamesUniverseIdSocialLinksListGet(
            e,
            t,
          )(this.axios, this.basePath);
        }));
      function cs() {
        return (null !== ds && ds.apply(this, arguments)) || this;
      }
      function vs(u) {
        return {
          v1GamesVipServersUniverseIdPost: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesVipServersUniverseIdPost.",
              );
            if (null == t)
              throw new Do(
                "requestBody",
                "Required parameter requestBody was null or undefined when calling v1GamesVipServersUniverseIdPost.",
              );
            var a,
              n = "/v1/games/vip-servers/{universeId}".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = $o($o({ method: "POST" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1VipServersIdGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "id",
                "Required parameter id was null or undefined when calling v1VipServersIdGet.",
              );
            var r,
              a = "/v1/vip-servers/{id}".replace(
                "{id}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1VipServersIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "id",
                "Required parameter id was null or undefined when calling v1VipServersIdPatch.",
              );
            if (null == t)
              throw new Do(
                "request",
                "Required parameter request was null or undefined when calling v1VipServersIdPatch.",
              );
            var a,
              n = "/v1/vip-servers/{id}".replace(
                "{id}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = $o($o({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1VipServersIdPermissionsPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "id",
                "Required parameter id was null or undefined when calling v1VipServersIdPermissionsPatch.",
              );
            if (null == t)
              throw new Do(
                "request",
                "Required parameter request was null or undefined when calling v1VipServersIdPermissionsPatch.",
              );
            var a,
              n = "/v1/vip-servers/{id}/permissions".replace(
                "{id}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = $o($o({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1VipServersIdSubscriptionPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "id",
                "Required parameter id was null or undefined when calling v1VipServersIdSubscriptionPatch.",
              );
            if (null == t)
              throw new Do(
                "request",
                "Required parameter request was null or undefined when calling v1VipServersIdSubscriptionPatch.",
              );
            var a,
              n = "/v1/vip-servers/{id}/subscription".replace(
                "{id}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = $o($o({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
        };
      }
      function ps(n) {
        return {
          v1GamesVipServersUniverseIdPost: function (e, t, r) {
            var a = vs(n).v1GamesVipServersUniverseIdPost(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1VipServersIdGet: function (e, t) {
            var a = vs(n).v1VipServersIdGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1VipServersIdPatch: function (e, t, r) {
            var a = vs(n).v1VipServersIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1VipServersIdPermissionsPatch: function (e, t, r) {
            var a = vs(n).v1VipServersIdPermissionsPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1VipServersIdSubscriptionPatch: function (e, t, r) {
            var a = vs(n).v1VipServersIdSubscriptionPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var hs;
      (Ko(ms, (hs = Co)),
        (ms.prototype.v1GamesVipServersUniverseIdPost = function (e, t, r) {
          return ps(this.configuration).v1GamesVipServersUniverseIdPost(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (ms.prototype.v1VipServersIdGet = function (e, t) {
          return ps(this.configuration).v1VipServersIdGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (ms.prototype.v1VipServersIdPatch = function (e, t, r) {
          return ps(this.configuration).v1VipServersIdPatch(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (ms.prototype.v1VipServersIdPermissionsPatch = function (e, t, r) {
          return ps(this.configuration).v1VipServersIdPermissionsPatch(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (ms.prototype.v1VipServersIdSubscriptionPatch = function (e, t, r) {
          return ps(this.configuration).v1VipServersIdSubscriptionPatch(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }));
      function ms() {
        return (null !== hs && hs.apply(this, arguments)) || this;
      }
      function gs(u) {
        return {
          v1GamesUniverseIdUserVotesPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdUserVotesPatch.",
              );
            if (null == t)
              throw new Do(
                "requestBody",
                "Required parameter requestBody was null or undefined when calling v1GamesUniverseIdUserVotesPatch.",
              );
            var a,
              n = "/v1/games/{universeId}/user-votes".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            u && (a = u.baseOptions);
            var s = $o($o({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = $o($o($o({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = $o($o({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1GamesUniverseIdVotesGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdVotesGet.",
              );
            var r,
              a = "/v1/games/{universeId}/votes".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GamesUniverseIdVotesUserGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeId",
                "Required parameter universeId was null or undefined when calling v1GamesUniverseIdVotesUserGet.",
              );
            var r,
              a = "/v1/games/{universeId}/votes/user".replace(
                "{universeId}",
                encodeURIComponent(String(e)),
              ),
              n = P.parse(a, !0);
            u && (r = u.baseOptions);
            var o = $o($o({ method: "GET" }, r), t);
            return (
              (n.query = $o($o($o({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = $o($o({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GamesVotesGet: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new Do(
                "universeIds",
                "Required parameter universeIds was null or undefined when calling v1GamesVotesGet.",
              );
            var r,
              a = P.parse("/v1/games/votes", !0);
            u && (r = u.baseOptions);
            var n = $o($o({ method: "GET" }, r), t),
              o = {};
            return (
              e && (o.universeIds = e.join(Oo)),
              (a.query = $o($o($o({}, a.query), o), t.query)),
              delete a.search,
              (n.headers = $o($o({}, {}), t.headers)),
              { url: P.format(a), options: n }
            );
          },
        };
      }
      function fs(n) {
        return {
          v1GamesUniverseIdUserVotesPatch: function (e, t, r) {
            var a = gs(n).v1GamesUniverseIdUserVotesPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesUniverseIdVotesGet: function (e, t) {
            var a = gs(n).v1GamesUniverseIdVotesGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesUniverseIdVotesUserGet: function (e, t) {
            var a = gs(n).v1GamesUniverseIdVotesUserGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GamesVotesGet: function (e, t) {
            var a = gs(n).v1GamesVotesGet(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = Uo));
              var r = $o($o({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var Gs;
      (Ko(ys, (Gs = Co)),
        (ys.prototype.v1GamesUniverseIdUserVotesPatch = function (e, t, r) {
          return fs(this.configuration).v1GamesUniverseIdUserVotesPatch(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (ys.prototype.v1GamesUniverseIdVotesGet = function (e, t) {
          return fs(this.configuration).v1GamesUniverseIdVotesGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (ys.prototype.v1GamesUniverseIdVotesUserGet = function (e, t) {
          return fs(this.configuration).v1GamesUniverseIdVotesUserGet(e, t)(
            this.axios,
            this.basePath,
          );
        }),
        (ys.prototype.v1GamesVotesGet = function (e, t) {
          return fs(this.configuration).v1GamesVotesGet(e, t)(
            this.axios,
            this.basePath,
          );
        }));
      function ys() {
        return (null !== Gs && Gs.apply(this, arguments)) || this;
      }
      function Is(e, t, r) {
        (void 0 === t && (t = As),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var bs,
        Ps,
        ws = new is(),
        Cs = new rs(),
        qs = {
          getGameDetails: function (e) {
            return ws.v1GamesGet(e, { withCredentials: !0 });
          },
          getGamePasses: function (e, t, r, a) {
            return Cs.v1GamesUniverseIdGamePassesGet(e, t, r, a);
          },
          getGamesSorts: function (e) {
            return ws.v1GamesSortsGet(e);
          },
          getGamesList: function (
            e,
            t,
            r,
            a,
            n,
            o,
            s,
            i,
            u,
            l,
            d,
            c,
            v,
            p,
            h,
            m,
          ) {
            return ws.v1GamesListGet(
              e,
              t,
              r,
              a,
              n,
              o,
              s,
              i,
              u,
              l,
              d,
              c,
              v,
              p,
              h,
              m,
            );
          },
        },
        Ls =
          ((bs = function (e, t) {
            return (bs =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (bs(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        As = i.EnvironmentUrls.inventoryApi.replace(/\/+$/, ""),
        Ts = ((Ps = Error), Ls(Ss, Ps), Ss);
      function Ss(e, t) {
        var r = Ps.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var Rs,
        Us,
        Os,
        Ds,
        Bs,
        xs,
        Es,
        Fs,
        Ns,
        zs =
          ((Rs = function (e, t) {
            return (Rs =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Rs(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        js = function () {
          return (js =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      (((Os = Us = Us || {}).Asc = "Asc"),
        (Os.Desc = "Desc"),
        ((Bs = Ds = Ds || {}).Forward = "Forward"),
        (Bs.Backward = "Backward"),
        ((Es = xs = xs || {}).User = "User"),
        (Es.Group = "Group"),
        ((Ns = Fs = Fs || {}).None = "None"),
        (Ns.BC = "BC"),
        (Ns.TBC = "TBC"),
        (Ns.OBC = "OBC"),
        (Ns.RobloxPremium = "RobloxPremium"));
      function _s(c) {
        return {
          v2AssetsAssetIdOwnersGet: function (e, t, r, a, n) {
            if ((void 0 === n && (n = {}), null == e))
              throw new Ts(
                "assetId",
                "Required parameter assetId was null or undefined when calling v2AssetsAssetIdOwnersGet.",
              );
            var o,
              s = "/v2/assets/{assetId}/owners".replace(
                "{assetId}",
                encodeURIComponent(String(e)),
              ),
              i = P.parse(s, !0);
            c && (o = c.baseOptions);
            var u = js(js({ method: "GET" }, o), n),
              l = {};
            return (
              void 0 !== t && (l.sortOrder = t),
              void 0 !== r && (l.limit = r),
              void 0 !== a && (l.cursor = a),
              (i.query = js(js(js({}, i.query), l), n.query)),
              delete i.search,
              (u.headers = js(js({}, {}), n.headers)),
              { url: P.format(i), options: u }
            );
          },
          v2RecommendationsAssetTypeIdGet: function (e, t, r, a, n, o) {
            if ((void 0 === o && (o = {}), null == e))
              throw new Ts(
                "assetTypeId",
                "Required parameter assetTypeId was null or undefined when calling v2RecommendationsAssetTypeIdGet.",
              );
            var s,
              i = "/v2/recommendations/{assetTypeId}".replace(
                "{assetTypeId}",
                encodeURIComponent(String(e)),
              ),
              u = P.parse(i, !0);
            c && (s = c.baseOptions);
            var l = js(js({ method: "GET" }, s), o),
              d = {};
            return (
              void 0 !== t && (d.numItems = t),
              void 0 !== r && (d.contextAssetId = r),
              void 0 !== a && (d.thumbWidth = a),
              void 0 !== n && (d.thumbHeight = n),
              (u.query = js(js(js({}, u.query), d), o.query)),
              delete u.search,
              (l.headers = js(js({}, {}), o.headers)),
              { url: P.format(u), options: l }
            );
          },
        };
      }
      function ks(i) {
        return {
          v2AssetsAssetIdOwnersGet: function (e, t, r, a, n) {
            var o = _s(i).v2AssetsAssetIdOwnersGet(e, t, r, a, n);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = As));
              var r = js(js({}, o.options), { url: t + o.url });
              return e.request(r);
            };
          },
          v2RecommendationsAssetTypeIdGet: function (e, t, r, a, n, o) {
            var s = _s(i).v2RecommendationsAssetTypeIdGet(e, t, r, a, n, o);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = As));
              var r = js(js({}, s.options), { url: t + s.url });
              return e.request(r);
            };
          },
        };
      }
      var Ms,
        Hs =
          (zs(Vs, (Ms = Is)),
          (Vs.prototype.v2AssetsAssetIdOwnersGet = function (e, t, r, a, n) {
            return ks(this.configuration).v2AssetsAssetIdOwnersGet(
              e,
              t,
              r,
              a,
              n,
            )(this.axios, this.basePath);
          }),
          (Vs.prototype.v2RecommendationsAssetTypeIdGet = function (
            e,
            t,
            r,
            a,
            n,
            o,
          ) {
            return ks(this.configuration).v2RecommendationsAssetTypeIdGet(
              e,
              t,
              r,
              a,
              n,
              o,
            )(this.axios, this.basePath);
          }),
          Vs);
      function Vs() {
        return (null !== Ms && Ms.apply(this, arguments)) || this;
      }
      function Ws(i) {
        return {
          v2UsersUserIdInventoryAssetTypeIdGet: function (e, t, r, a, n, o) {
            var s = (function (c) {
              return {
                v2UsersUserIdInventoryAssetTypeIdGet: function (
                  e,
                  t,
                  r,
                  a,
                  n,
                  o,
                ) {
                  if ((void 0 === o && (o = {}), null == e))
                    throw new Ts(
                      "userId",
                      "Required parameter userId was null or undefined when calling v2UsersUserIdInventoryAssetTypeIdGet.",
                    );
                  if (null == t)
                    throw new Ts(
                      "assetTypeId",
                      "Required parameter assetTypeId was null or undefined when calling v2UsersUserIdInventoryAssetTypeIdGet.",
                    );
                  var s,
                    i = "/v2/users/{userId}/inventory/{assetTypeId}"
                      .replace("{userId}", encodeURIComponent(String(e)))
                      .replace("{assetTypeId}", encodeURIComponent(String(t))),
                    u = P.parse(i, !0);
                  c && (s = c.baseOptions);
                  var l = js(js({ method: "GET" }, s), o),
                    d = {};
                  return (
                    void 0 !== r && (d.sortOrder = r),
                    void 0 !== a && (d.limit = a),
                    void 0 !== n && (d.cursor = n),
                    (u.query = js(js(js({}, u.query), d), o.query)),
                    delete u.search,
                    (l.headers = js(js({}, {}), o.headers)),
                    { url: P.format(u), options: l }
                  );
                },
              };
            })(i).v2UsersUserIdInventoryAssetTypeIdGet(e, t, r, a, n, o);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = As));
              var r = js(js({}, s.options), { url: t + s.url });
              return e.request(r);
            };
          },
        };
      }
      var Js;
      (zs(Ks, (Js = Is)),
        (Ks.prototype.v2UsersUserIdInventoryAssetTypeIdGet = function (
          e,
          t,
          r,
          a,
          n,
          o,
        ) {
          return Ws(this.configuration).v2UsersUserIdInventoryAssetTypeIdGet(
            e,
            t,
            r,
            a,
            n,
            o,
          )(this.axios, this.basePath);
        }));
      function Ks() {
        return (null !== Js && Js.apply(this, arguments)) || this;
      }
      var $s = new Hs(),
        Qs = {
          getRecommendations: function (e, t, r) {
            return $s.v2RecommendationsAssetTypeIdGet(e, t, r);
          },
        };
      function Xs(e, t, r) {
        (void 0 === t && (t = ri),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var Ys,
        Zs,
        ei = {
          getUserKey: function (e) {
            return "user_" + e;
          },
          storage: function () {
            return i.LocalStorage ? i.LocalStorage.isAvailable() : localStorage;
          },
          getLength: function () {
            return this.storage() ? localStorage.length : 0;
          },
          getKey: function (e) {
            return this.storage() ? localStorage.key(e) : "";
          },
          setLocalStorage: function (e, t) {
            this.storage() && localStorage.setItem(e, JSON.stringify(t));
          },
          getLocalStorage: function (e) {
            if (this.storage()) return JSON.parse(localStorage.getItem(e));
          },
          listenLocalStorage: function (e) {
            this.storage() &&
              void 0 !== e &&
              (window.addEventListener
                ? window.addEventListener("storage", e, !1)
                : window.attachEvent("onstorage", e));
          },
          removeLocalStorage: function (e) {
            this.storage() && localStorage.removeItem(e);
          },
          saveDataByTimeStamp: function (e, t) {
            var r = new Date().getTime(),
              a = this.getLocalStorage(e);
            (((a = a || {}).data = t),
              (a.timeStamp = r),
              this.setLocalStorage(e, a));
          },
          fetchNonExpiredCachedData: function (e, t) {
            var r = new Date().getTime(),
              a = this.getLocalStorage(e);
            if (a && a.timeStamp && r - a.timeStamp < (t = t || 3e4)) return a;
            return null;
          },
        },
        ti =
          ((Ys = function (e, t) {
            return (Ys =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Ys(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        ri = i.EnvironmentUrls.localeApi.replace(/\/+$/, ""),
        ai = ((Zs = Error), ti(ni, Zs), ni);
      function ni(e, t) {
        var r = Zs.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      function oi(s) {
        return {
          v1CountryRegionsGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/country-regions", !0);
            s && (t = s.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1CountryRegionsUserCountryRegionGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/country-regions/user-country-region", !0);
            s && (t = s.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1CountryRegionsUserCountryRegionPatch: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new ai(
                "userRequest",
                "Required parameter userRequest was null or undefined when calling v1CountryRegionsUserCountryRegionPatch.",
              );
            var r,
              a = P.parse("/v1/country-regions/user-country-region", !0);
            s && (r = s.baseOptions);
            var n = di(di({ method: "PATCH" }, r), t),
              o = {};
            ((o["Content-Type"] = "application/json"),
              (a.query = di(di(di({}, a.query), {}), t.query)),
              delete a.search,
              (n.headers = di(di({}, o), t.headers)));
            return (
              (n.data = JSON.stringify(void 0 !== e ? e : {})),
              { url: P.format(a), options: n }
            );
          },
        };
      }
      function si(r) {
        return {
          v1CountryRegionsGet: function (e) {
            var a = oi(r).v1CountryRegionsGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1CountryRegionsUserCountryRegionGet: function (e) {
            var a = oi(r).v1CountryRegionsUserCountryRegionGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1CountryRegionsUserCountryRegionPatch: function (e, t) {
            var a = oi(r).v1CountryRegionsUserCountryRegionPatch(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var ii,
        ui,
        li =
          ((ii = function (e, t) {
            return (ii =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (ii(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        di = function () {
          return (di =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      (li(ci, (ui = Xs)),
        (ci.prototype.v1CountryRegionsGet = function (e) {
          return si(this.configuration).v1CountryRegionsGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (ci.prototype.v1CountryRegionsUserCountryRegionGet = function (e) {
          return si(this.configuration).v1CountryRegionsUserCountryRegionGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (ci.prototype.v1CountryRegionsUserCountryRegionPatch = function (e, t) {
          return si(this.configuration).v1CountryRegionsUserCountryRegionPatch(
            e,
            t,
          )(this.axios, this.basePath);
        }));
      function ci() {
        return (null !== ui && ui.apply(this, arguments)) || this;
      }
      function vi(n) {
        return {
          v1LanguagesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/languages", !0);
            n && (t = n.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1LanguagesUserGeneratedContentGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/languages/user-generated-content", !0);
            n && (t = n.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function pi(t) {
        return {
          v1LanguagesGet: function (e) {
            var a = vi(t).v1LanguagesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LanguagesUserGeneratedContentGet: function (e) {
            var a = vi(t).v1LanguagesUserGeneratedContentGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var hi;
      (li(mi, (hi = Xs)),
        (mi.prototype.v1LanguagesGet = function (e) {
          return pi(this.configuration).v1LanguagesGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (mi.prototype.v1LanguagesUserGeneratedContentGet = function (e) {
          return pi(this.configuration).v1LanguagesUserGeneratedContentGet(e)(
            this.axios,
            this.basePath,
          );
        }));
      function mi() {
        return (null !== hi && hi.apply(this, arguments)) || this;
      }
      function gi(s) {
        return {
          v1LocalesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/locales", !0);
            s && (t = s.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1LocalesSetUserSupportedLocalePost: function (e, t) {
            if ((void 0 === t && (t = {}), null == e))
              throw new ai(
                "userRequest",
                "Required parameter userRequest was null or undefined when calling v1LocalesSetUserSupportedLocalePost.",
              );
            var r,
              a = P.parse("/v1/locales/set-user-supported-locale", !0);
            s && (r = s.baseOptions);
            var n = di(di({ method: "POST" }, r), t),
              o = {};
            ((o["Content-Type"] = "application/json"),
              (a.query = di(di(di({}, a.query), {}), t.query)),
              delete a.search,
              (n.headers = di(di({}, o), t.headers)));
            return (
              (n.data = JSON.stringify(void 0 !== e ? e : {})),
              { url: P.format(a), options: n }
            );
          },
          v1LocalesSupportedLocalesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/locales/supported-locales", !0);
            s && (t = s.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1LocalesUserLocaleGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse("/v1/locales/user-locale", !0);
            s && (t = s.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
          v1LocalesUserLocalizationLocusSupportedLocalesGet: function (e) {
            void 0 === e && (e = {});
            var t,
              r = P.parse(
                "/v1/locales/user-localization-locus-supported-locales",
                !0,
              );
            s && (t = s.baseOptions);
            var a = di(di({ method: "GET" }, t), e);
            return (
              (r.query = di(di(di({}, r.query), {}), e.query)),
              delete r.search,
              (a.headers = di(di({}, {}), e.headers)),
              { url: P.format(r), options: a }
            );
          },
        };
      }
      function fi(r) {
        return {
          v1LocalesGet: function (e) {
            var a = gi(r).v1LocalesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalesSetUserSupportedLocalePost: function (e, t) {
            var a = gi(r).v1LocalesSetUserSupportedLocalePost(e, t);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalesSupportedLocalesGet: function (e) {
            var a = gi(r).v1LocalesSupportedLocalesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalesUserLocaleGet: function (e) {
            var a = gi(r).v1LocalesUserLocaleGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1LocalesUserLocalizationLocusSupportedLocalesGet: function (e) {
            var a = gi(r).v1LocalesUserLocalizationLocusSupportedLocalesGet(e);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ri));
              var r = di(di({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
        };
      }
      var Gi;
      function yi() {
        return (null !== Gi && Gi.apply(this, arguments)) || this;
      }
      var Ii,
        bi = new (li(yi, (Gi = Xs)),
        (yi.prototype.v1LocalesGet = function (e) {
          return fi(this.configuration).v1LocalesGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (yi.prototype.v1LocalesSetUserSupportedLocalePost = function (e, t) {
          return fi(this.configuration).v1LocalesSetUserSupportedLocalePost(
            e,
            t,
          )(this.axios, this.basePath);
        }),
        (yi.prototype.v1LocalesSupportedLocalesGet = function (e) {
          return fi(this.configuration).v1LocalesSupportedLocalesGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (yi.prototype.v1LocalesUserLocaleGet = function (e) {
          return fi(this.configuration).v1LocalesUserLocaleGet(e)(
            this.axios,
            this.basePath,
          );
        }),
        (yi.prototype.v1LocalesUserLocalizationLocusSupportedLocalesGet =
          function (e) {
            return fi(
              this.configuration,
            ).v1LocalesUserLocalizationLocusSupportedLocalesGet(e)(
              this.axios,
              this.basePath,
            );
          }),
        yi)();
      (Ii = Ii || {}).getLocales = "Roblox.Api.Locales.getLocales";
      function Pi() {
        return bi.v1LocalesGet({ withCredentials: !0 });
      }
      var wi,
        Ci,
        qi = {
          getLocales: Pi,
          getUserLocale: function () {
            return bi.v1LocalesUserLocalizationLocusSupportedLocalesGet({
              withCredentials: !0,
            });
          },
          setUserLocale: function (e) {
            var t = { supportedLocaleCode: e };
            return bi.v1LocalesSetUserSupportedLocalePost(t, {
              withCredentials: !0,
            });
          },
          getLocalesWithCache: function (e) {
            return (function (a, n, o) {
              return new Promise(function (t, r) {
                var e = ei.fetchNonExpiredCachedData(n, o);
                e
                  ? t(e.data)
                  : a().then(
                      function (e) {
                        (ei.saveDataByTimeStamp(n, e.data), t(e.data));
                      },
                      function (e) {
                        return r(e);
                      },
                    );
              });
            })(Pi, Ii.getLocales, e);
          },
        },
        Li = new Sn(),
        Ai = new Vn(),
        Ti = new Bn(),
        Si = new uo(),
        Ri = new Nn(),
        Ui = new $n(),
        Oi = new po(),
        Di = {
          getAssets: function (e, t, r, a, n) {
            return Li.v1AssetsGet(e, t, r, a, n, { withCredentials: !0 });
          },
          getAvatars: function (e, t, r, a) {
            return Ti.v1UsersAvatarGet(e, t, r, a, { withCredentials: !0 });
          },
          getAvatarHeadshots: function (e, t, r, a) {
            return Ti.v1UsersAvatarHeadshotGet(e, t, r, a, {
              withCredentials: !0,
            });
          },
          getGroupIcons: function (e, t, r, a) {
            return Si.v1GroupsIconsGet(e, t, r, a, { withCredentials: !0 });
          },
          getBadgeIcons: function (e, t, r, a) {
            return Ri.v1BadgesIconsGet(e, t, r, a, { withCredentials: !0 });
          },
          getDeveloperProductIcons: function (e, t, r, a) {
            return Ui.v1DeveloperProductsIconsGet(e, t, r, a, {
              withCredentials: !0,
            });
          },
          getBundles: function (e, t, r, a) {
            return Ai.v1BundlesThumbnailsGet(e, t, r, a, {
              withCredentials: !0,
            });
          },
          getUserOutfits: function (e, t, r, a) {
            return Oi.v1UsersOutfitsGet(e, t, r, a, { withCredentials: !0 });
          },
        },
        Bi = new Wr();
      (((Ci = wi = wi || {}).Language = "Language"), (Ci.Locale = "Locale"));
      function xi(e, t, r) {
        (void 0 === t && (t = ji),
          void 0 === r && (r = y.a),
          (this.basePath = t),
          (this.axios = r),
          e &&
            ((this.configuration = e),
            (this.basePath = e.basePath || this.basePath)));
      }
      var Ei,
        Fi,
        Ni = {
          getTranslationProgress: function (e, t) {
            return Bi.v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet(
              e,
              t,
              wi.Language,
              { withCredentials: !0 },
            );
          },
        },
        zi =
          ((Ei = function (e, t) {
            return (Ei =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Ei(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        ji = i.EnvironmentUrls.translationRolesApi.replace(/\/+$/, ""),
        _i = ((Fi = Error), zi(ki, Fi), ki);
      function ki(e, t) {
        var r = Fi.call(this, t) || this;
        return ((r.field = e), (r.name = "RequiredError"), r);
      }
      var Mi,
        Hi,
        Vi,
        Wi,
        Ji,
        Ki,
        $i,
        Qi =
          ((Mi = function (e, t) {
            return (Mi =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Mi(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          }),
        Xi = function () {
          return (Xi =
            Object.assign ||
            function (e) {
              for (var t, r = 1, a = arguments.length; r < a; r++)
                for (var n in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              return e;
            }).apply(this, arguments);
        };
      (((Vi = Hi = Hi || {}).User = "user"),
        (Vi.Group = "group"),
        (Vi.GroupRole = "groupRole"),
        ((Ji = Wi = Wi || {}).User = "user"),
        (Ji.Group = "group"),
        (Ji.GroupRole = "groupRole"),
        (($i = Ki = Ki || {}).User = "user"),
        ($i.Group = "group"),
        ($i.GroupRole = "groupRole"));
      function Yi(l) {
        return {
          v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet: function (
            e,
            t,
          ) {
            if ((void 0 === t && (t = {}), null == e))
              throw new _i(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet.",
              );
            var r,
              a =
                "/v1/game-localization-roles/games/{gameId}/current-user/roles".replace(
                  "{gameId}",
                  encodeURIComponent(String(e)),
                ),
              n = P.parse(a, !0);
            l && (r = l.baseOptions);
            var o = Xi(Xi({ method: "GET" }, r), t);
            return (
              (n.query = Xi(Xi(Xi({}, n.query), {}), t.query)),
              delete n.search,
              (o.headers = Xi(Xi({}, {}), t.headers)),
              { url: P.format(n), options: o }
            );
          },
          v1GameLocalizationRolesGamesGameIdPatch: function (e, t, r) {
            if ((void 0 === r && (r = {}), null == e))
              throw new _i(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameLocalizationRolesGamesGameIdPatch.",
              );
            if (null == t)
              throw new _i(
                "request",
                "Required parameter request was null or undefined when calling v1GameLocalizationRolesGamesGameIdPatch.",
              );
            var a,
              n = "/v1/game-localization-roles/games/{gameId}".replace(
                "{gameId}",
                encodeURIComponent(String(e)),
              ),
              o = P.parse(n, !0);
            l && (a = l.baseOptions);
            var s = Xi(Xi({ method: "PATCH" }, a), r),
              i = {};
            ((i["Content-Type"] = "application/json"),
              (o.query = Xi(Xi(Xi({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Xi(Xi({}, i), r.headers)));
            return (
              (s.data = JSON.stringify(void 0 !== t ? t : {})),
              { url: P.format(o), options: s }
            );
          },
          v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet: function (
            e,
            t,
            r,
          ) {
            if ((void 0 === r && (r = {}), null == e))
              throw new _i(
                "gameId",
                "Required parameter gameId was null or undefined when calling v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet.",
              );
            if (null == t)
              throw new _i(
                "role",
                "Required parameter role was null or undefined when calling v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet.",
              );
            var a,
              n =
                "/v1/game-localization-roles/games/{gameId}/roles/{role}/assignees"
                  .replace("{gameId}", encodeURIComponent(String(e)))
                  .replace("{role}", encodeURIComponent(String(t))),
              o = P.parse(n, !0);
            l && (a = l.baseOptions);
            var s = Xi(Xi({ method: "GET" }, a), r);
            return (
              (o.query = Xi(Xi(Xi({}, o.query), {}), r.query)),
              delete o.search,
              (s.headers = Xi(Xi({}, {}), r.headers)),
              { url: P.format(o), options: s }
            );
          },
          v1GameLocalizationRolesRolesRoleCurrentUserGet: function (
            e,
            t,
            r,
            a,
          ) {
            if ((void 0 === a && (a = {}), null == e))
              throw new _i(
                "role",
                "Required parameter role was null or undefined when calling v1GameLocalizationRolesRolesRoleCurrentUserGet.",
              );
            var n,
              o =
                "/v1/game-localization-roles/roles/{role}/current-user".replace(
                  "{role}",
                  encodeURIComponent(String(e)),
                ),
              s = P.parse(o, !0);
            l && (n = l.baseOptions);
            var i = Xi(Xi({ method: "GET" }, n), a),
              u = {};
            return (
              void 0 !== t && (u.exclusiveStartKey = t),
              void 0 !== r && (u.pageSize = r),
              (s.query = Xi(Xi(Xi({}, s.query), u), a.query)),
              delete s.search,
              (i.headers = Xi(Xi({}, {}), a.headers)),
              { url: P.format(s), options: i }
            );
          },
        };
      }
      function Zi(o) {
        return {
          v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet: function (
            e,
            t,
          ) {
            var a = Yi(o).v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet(
              e,
              t,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ji));
              var r = Xi(Xi({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GameLocalizationRolesGamesGameIdPatch: function (e, t, r) {
            var a = Yi(o).v1GameLocalizationRolesGamesGameIdPatch(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ji));
              var r = Xi(Xi({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet: function (
            e,
            t,
            r,
          ) {
            var a = Yi(
              o,
            ).v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet(e, t, r);
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ji));
              var r = Xi(Xi({}, a.options), { url: t + a.url });
              return e.request(r);
            };
          },
          v1GameLocalizationRolesRolesRoleCurrentUserGet: function (
            e,
            t,
            r,
            a,
          ) {
            var n = Yi(o).v1GameLocalizationRolesRolesRoleCurrentUserGet(
              e,
              t,
              r,
              a,
            );
            return function (e, t) {
              (void 0 === e && (e = y.a), void 0 === t && (t = ji));
              var r = Xi(Xi({}, n.options), { url: t + n.url });
              return e.request(r);
            };
          },
        };
      }
      var eu;
      function tu() {
        return (null !== eu && eu.apply(this, arguments)) || this;
      }
      var ru,
        au = new (Qi(tu, (eu = xi)),
        (tu.prototype.v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet =
          function (e, t) {
            return Zi(
              this.configuration,
            ).v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet(e, t)(
              this.axios,
              this.basePath,
            );
          }),
        (tu.prototype.v1GameLocalizationRolesGamesGameIdPatch = function (
          e,
          t,
          r,
        ) {
          return Zi(this.configuration).v1GameLocalizationRolesGamesGameIdPatch(
            e,
            t,
            r,
          )(this.axios, this.basePath);
        }),
        (tu.prototype.v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet =
          function (e, t, r) {
            return Zi(
              this.configuration,
            ).v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet(
              e,
              t,
              r,
            )(this.axios, this.basePath);
          }),
        (tu.prototype.v1GameLocalizationRolesRolesRoleCurrentUserGet =
          function (e, t, r, a) {
            return Zi(
              this.configuration,
            ).v1GameLocalizationRolesRolesRoleCurrentUserGet(
              e,
              t,
              r,
              a,
            )(this.axios, this.basePath);
          }),
        tu)();
      (ru = ru || {}).Translator = "translator";
      var nu,
        ou,
        su,
        iu,
        uu = {
          getGamesListForTranslator: function (e, t) {
            return au.v1GameLocalizationRolesRolesRoleCurrentUserGet(
              ru.Translator,
              t,
              e,
              { withCredentials: !0 },
            );
          },
        };
      (((ou = nu = nu || {})[(ou.LocalStorage = 0)] = "LocalStorage"),
        (ou[(ou.IndexedDb = 1)] = "IndexedDb"),
        (ou[(ou.ServiceWorker = 2)] = "ServiceWorker"),
        ((iu = su = su || {}).Get = "get"),
        (iu.Post = "post"),
        (iu.Delete = "delete"),
        (iu.Patch = "patch"));
      var lu = {
          isCacheEnabled: !0,
          expirationWindowsMS: 3e4,
          cacheType: nu.LocalStorage,
        },
        du = { isBatchEnabled: !1, limit: 50, key: "" },
        cu = r(36);
      function vu() {
        ((this.CacheType = nu),
          (this.RequestType = su),
          (this.callbacks = new Map()),
          (this.dataStore = new Map()),
          (this.pendingCalls = new Map()));
      }
      function pu(e) {
        return fu + "/v1/my/friends/requests";
      }
      function hu(t) {
        return function (e) {
          return fu + "/v1/users/" + e + "/" + t;
        };
      }
      function mu(e, t, r, a, n) {
        var o = {};
        return (
          r && Object.assign(o, { cursor: r }),
          a && Object.assign(o, { sortOrder: a }),
          n && Object.assign(o, { limit: n }),
          {
            url: e(t),
            method: gu.RequestType.Get,
            retryable: !0,
            withCredentials: !0,
            params: o,
          }
        );
      }
      var gu = new ((vu.prototype.tryFetchFromCache = function (e, t) {
          var r,
            a = t.expirationWindowsMS;
          return (
            t.cacheType === nu.LocalStorage &&
              (r = ei.fetchNonExpiredCachedData(e, a)),
            r ? r.data : null
          );
        }),
        (vu.prototype.handleError = function (e, t) {
          (this.callbacks.has(e) &&
            (this.callbacks.get(e).forEach(function (e) {
              e(null, t);
            }),
            this.callbacks.delete(e)),
            this.pendingCalls.delete(e));
        }),
        (vu.prototype.handleCallback = function (e, t, r) {
          (this.dataStore.set(e, t),
            this.callbacks.has(e) &&
              (this.callbacks.get(e).forEach(function (e) {
                e(t);
              }),
              this.callbacks.delete(e)),
            r && ei.saveDataByTimeStamp(e, t),
            this.pendingCalls.delete(e));
        }),
        (vu.prototype.batchFromNetwork = function (e, t) {
          for (
            var r = t.limit,
              a = t.key,
              n = e.data,
              o = e.params,
              s = e.method,
              i = [],
              u = 0,
              l = s === this.RequestType.Get ? o[a] : n[a],
              d = l.slice(u, r);
            0 < d.length;
          ) {
            var c = Object.assign({}, e);
            if (s === this.RequestType.Get)
              ((Object.assign({}, c.params)[a] = d.slice()), (c.params = n));
            else {
              var v = Object.assign({}, c.data);
              ((v[a] = d.slice()), (c.data = v));
            }
            (i.push(y.a.request(c)), u++, (d = l.slice(u * r, u * r + r)));
          }
          return Promise.all(i);
        }),
        (vu.prototype.fetchFromNetwork = function (e, t, r) {
          var a = this,
            n = t.isCacheEnabled,
            o = r.isBatchEnabled,
            s = this.buildResourceKey(e);
          return (
            this.pendingCalls.set(s, !0),
            o
              ? this.batchFromNetwork(e, r)
                  .then(function (e) {
                    return (a.handleCallback(s, e, n), e);
                  })
                  .catch(function (e) {
                    a.handleError(s, { error: e });
                  })
              : y.a
                  .request(e)
                  .then(function (e) {
                    return (a.handleCallback(s, e, n), e);
                  })
                  .catch(function (e) {
                    a.handleError(s, { error: e });
                  })
          );
        }),
        (vu.prototype.fetchFromCache = function (e, t) {
          var r = this,
            a = this.buildResourceKey(e);
          return new Promise(function (e) {
            e(r.dataStore.get(a) || r.tryFetchFromCache(a, t));
          });
        }),
        (vu.prototype.buildResourceKey = function (e) {
          var t = e.url,
            r = e.params,
            a = e.method,
            n = e.data;
          return (
            "" + a + t + cu.a.composeQueryString(r) + cu.a.composeQueryString(n)
          );
        }),
        (vu.prototype.buildCacheCriteria = function (e) {
          return Object.assign(lu, e);
        }),
        (vu.prototype.subscribe = function (t, r, a, n) {
          var o = this;
          (void 0 === a && (a = lu),
            void 0 === n && (n = du),
            (a = this.buildCacheCriteria(a)));
          var s = "function" == typeof t,
            i = a.isCacheEnabled,
            u = this.buildResourceKey(r),
            l = this.pendingCalls.has(u);
          return (
            this.fetchFromCache(r, a).then(function (e) {
              (i && e && s && t(e),
                ((e || l) && i) ||
                  (s &&
                    (l
                      ? o.callbacks.get(u).add(t)
                      : o.callbacks.set(u, new Set([t]))),
                  o.fetchFromNetwork(r, a, n)));
            }),
            this.getUnsubscribeMethod(u, t)
          );
        }),
        (vu.prototype.getUnsubscribeMethod = function (e, t) {
          var r = this;
          return function () {
            r.callbacks.get(e) && r.callbacks.get(e).delete(t);
          };
        }),
        (vu.prototype.refresh = function (e, t, r) {
          return (
            void 0 === t && (t = lu),
            void 0 === r && (r = du),
            this.fetchFromNetwork(e, this.buildCacheCriteria(t), r)
          );
        }),
        vu)(),
        fu = i.EnvironmentUrls.friendsApi;
      function Gu(s) {
        return function (e, t, r, a, n, o) {
          return gu.subscribe(e, mu(s, t, r, a, n), o);
        };
      }
      function yu(o) {
        return function (e, t, r, a, n) {
          return gu.refresh(mu(o, e, t, r, a), n);
        };
      }
      var Iu = {
          getFriends: Gu(hu("friends")),
          getFollowers: Gu(hu("followers")),
          getFollowings: Gu(hu("followings")),
          getFriendsRequests: Gu(pu),
          refreshFriends: yu(hu("friends")),
          refreshFollowers: yu(hu("followers")),
          refreshFollowings: yu(hu("followings")),
          refreshFriendsRequests: yu(pu),
        },
        bu = i.EnvironmentUrls.presenceApi;
      function Pu() {}
      function wu(e) {
        var t = {};
        return (
          e.forEach(function (e) {
            ((t[e.id] = e), (t[e.id].presence = {}));
          }),
          t
        );
      }
      function Cu(t, e) {
        if (!e || 0 === e.length) return t;
        e.reduce(function (e, t) {
          var r = t.data.userPresences;
          return e.concat(r);
        }, []).forEach(function (e) {
          t[e.userId].presence = e;
        });
      }
      function qu(d) {
        return function (e) {
          var s,
            i = e.callback,
            t = e.userId,
            r = e.cursor,
            a = e.sortOrder,
            n = e.limit,
            u = e.isGuest,
            l = e.cacheCriteria,
            o = Iu[d](
              function (e) {
                var t;
                if (!(null === (t = e) || void 0 === t ? void 0 : t.data))
                  return i([], null, null);
                var r = e.data.data,
                  a = wu(r),
                  n = e.data.previousPageCursor,
                  o = e.data.nextPageCursor;
                u
                  ? i(r, n, o)
                  : (s = Au.getUserPresence(
                      Object.keys(a).map(function (e) {
                        return parseInt(e);
                      }),
                      function (e) {
                        (Cu(a, e), i(r, n, o));
                      },
                      l,
                    ));
              },
              t,
              r,
              a,
              n,
              l,
            );
          return function () {
            (o(), "function" == typeof s && s());
          };
        };
      }
      function Lu(o) {
        return function (e) {
          var t = e.userId,
            r = e.cursor,
            a = e.sortOrder,
            n = e.limit,
            s = e.isGuest,
            i = e.cacheCriteria;
          return Iu[o](t, r, a, n, i).then(function (e) {
            var t;
            if (!(null === (t = e) || void 0 === t ? void 0 : t.data))
              return {};
            var r = e.data.data,
              a = wu(r),
              n = e.data.previousPageCursor,
              o = e.data.nextPageCursor;
            return s
              ? { userData: r, prev: n, next: o }
              : Au.refreshUserPresence(
                  Object.keys(a).map(function (e) {
                    return parseInt(e);
                  }),
                  i,
                ).then(function (e) {
                  return (Cu(a, e), { userData: r, prev: n, next: o });
                });
          });
        };
      }
      var Au =
          ((Pu.getUserPresence = function (e, t, r) {
            var a = {
              url: bu + "/v1/presence/users",
              method: gu.RequestType.Post,
              retryable: !0,
              withCredentials: !0,
              data: { userIds: e },
            };
            return gu.subscribe(t, a, r, {
              key: "userIds",
              limit: 100,
              isBatchEnabled: !0,
            });
          }),
          (Pu.refreshUserPresence = function (e, t) {
            var r = {
              url: bu + "/v1/presence/users",
              method: gu.RequestType.Post,
              retryable: !0,
              withCredentials: !0,
              data: { userIds: e },
            };
            return gu.refresh(r, t, {
              key: "userIds",
              limit: 100,
              isBatchEnabled: !0,
            });
          }),
          Pu),
        Tu = s.a.EnvironmentUrls,
        Su = {
          catalogDataStore: At,
          gameAutoLocalizationDataStore: Fa,
          gameAutomaticTranslationDataStore: za,
          gameLanguagesDataStore: un,
          gameSourceLanguageDataStore: dn,
          gameThumbnailsDataStore: Ao,
          gameTranslationAnalyticsDataStore: So,
          gamesDataStore: qs,
          inventoryDataStore: Qs,
          localeDataStore: qi,
          thumbnailsDataStore: Di,
          translationProgressDataStore: Ni,
          translationRolesDataStore: uu,
          userDataStore: {
            DATA_URL: { presence: Tu.presenceApi, friends: Tu.friendsApi },
            subscribeToFriends: qu("getFriends"),
            subscribeToFollowers: qu("getFollowers"),
            subscribeToFollowings: qu("getFollowings"),
            subscribeToFriendsRequests: qu("getFriendsRequests"),
            refreshFriends: Lu("refreshFriends"),
            refreshFollowers: Lu("refreshFollowers"),
            refreshFollowings: Lu("refreshFollowings"),
            refreshFriendsRequests: Lu("refreshFriendsRequests"),
            clearUserDataStoreCache: function () {
              for (var e = [], t = 0; t < arguments.length; t++)
                e[t] = arguments[t];
              if (localStorage) {
                for (
                  var r = 0 < e.length ? e : [Tu.friendsApi, Tu.presenceApi],
                    a = [],
                    n = 0;
                  n < localStorage.length;
                  n++
                )
                  for (var o = localStorage.key(n), s = 0; s < r.length; s++) {
                    var i = r[s];
                    -1 < o.indexOf(i) && a.push(o);
                  }
                for (var u = 0; u < a.length; u++)
                  localStorage.removeItem(a[u]);
              }
            },
          },
        };
      function Ru() {}
      var Uu,
        Ou,
        Du =
          ((Ru.prototype.getAbsoluteUrl = function (e) {
            if ("number" != typeof e) return null;
            var t = i.EnvironmentUrls.websiteUrl,
              r = cu.a.formatUrl({ pathname: this.getRelativePath(e) });
            return cu.a.resolveUrl(t, r);
          }),
          (Ru.prototype.navigateTo = function (e) {
            var t = this.getAbsoluteUrl(e);
            t && window.location.assign(t);
          }),
          Ru);
      function Bu() {
        return (null !== Ou && Ou.apply(this, arguments)) || this;
      }
      var xu,
        Eu,
        Fu =
          (((Uu = function (e, t) {
            return (Uu =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (Uu(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          })(Bu, (Ou = Du)),
          (Bu.prototype.getRelativePath = function (e) {
            return "/games/" + e;
          }),
          (Bu.prototype.getReferralPath = function () {
            return "/games/refer";
          }),
          Bu);
      function Nu() {
        return (null !== Eu && Eu.apply(this, arguments)) || this;
      }
      var zu,
        ju,
        _u =
          (((xu = function (e, t) {
            return (xu =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (xu(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          })(Nu, (Eu = Du)),
          (Nu.prototype.getRelativePath = function (e) {
            return "/groups/" + e;
          }),
          (Nu.prototype.getReferralPath = function () {
            return "/groups/refer";
          }),
          Nu);
      function ku() {
        return (null !== ju && ju.apply(this, arguments)) || this;
      }
      var Mu =
          (((zu = function (e, t) {
            return (zu =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
              })(e, t);
          }),
          function (e, t) {
            function r() {
              this.constructor = e;
            }
            (zu(e, t),
              (e.prototype =
                null === t
                  ? Object.create(t)
                  : ((r.prototype = t.prototype), new r())));
          })(ku, (ju = Du)),
          (ku.prototype.getRelativePath = function (e) {
            return "/users/" + e + "/profile";
          }),
          (ku.prototype.getReferralPath = function () {
            return "/users/refer";
          }),
          ku),
        Hu = { game: new Fu(), group: new _u(), user: new Mu() };
      function Vu(t) {
        for (var e = 1; e < arguments.length; e++) {
          var r = null != arguments[e] ? arguments[e] : {},
            a = Object.keys(r);
          ("function" == typeof Object.getOwnPropertySymbols &&
            (a = a.concat(
              Object.getOwnPropertySymbols(r).filter(function (e) {
                return Object.getOwnPropertyDescriptor(r, e).enumerable;
              }),
            )),
            a.forEach(function (e) {
              Wu(t, e, r[e]);
            }));
        }
        return t;
      }
      function Wu(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function Ju() {
        return void 0 !== i.EventStream;
      }
      function Ku(e, t, r, a) {
        if (Ju() && i.EventStream.SendEventWithTarget) {
          var n = Object.values($u).includes(a) ? a : $u.WWW;
          i.EventStream.SendEventWithTarget(e, t, r, n);
        }
      }
      var $u = Vu(
          {},
          { DEFAULT: 0, WWW: 1, STUDIO: 2, DIAGNOSTIC: 3 },
          Ju() ? i.EventStream.TargetTypes : {},
        ),
        Qu = {
          eventTypes: {
            formInteraction: "formInteraction",
            modalAction: "modalAction",
            pageLoad: "pageLoad",
          },
          targetTypes: $u,
          sendEvent: function (e, t) {
            var r = e.name,
              a = e.type,
              n = e.context,
              o = e.requiredParams,
              s = Vu({ btn: r }, t);
            (Array.isArray(o) &&
              o.forEach(function (e) {
                Object.prototype.hasOwnProperty.call(s, e) ||
                  console.info(
                    "A required event parameter '".concat(
                      e,
                      "' is not provided",
                    ),
                  );
              }),
              Ku(a, n, s));
          },
          sendEventWithTarget: Ku,
        },
        Xu = i.Hybrid || {},
        Yu = Xu.Chat,
        Zu = Xu.Navigation,
        el = Xu.Overlay,
        tl = Xu.Game,
        rl = Xu.Localization;
      function al(e) {
        return void 0 === e ? function () {} : e;
      }
      var nl = {
          startChatConversation: function (e, t) {
            Yu && Yu.startChatConversation(e, al(t));
          },
          startWebChatConversation: function (e, t) {
            Zu && Zu.startWebChatConversation(e, al(t));
          },
          navigateToFeature: function (e, t) {
            Zu && Zu.navigateToFeature(e, al(t));
          },
          openUserProfile: function (e, t) {
            Zu && Zu.openUserProfile(e, al(t));
          },
          close: function (e) {
            el && el.close(al(e));
          },
          launchGame: function (e, t) {
            tl && tl.launchGame(e, al(t));
          },
          localization: function (e, t) {
            rl &&
              rl.languageChangeTrigger &&
              rl.languageChangeTrigger(e, al(t));
          },
        },
        ol = (i.CurrentUser || {}).userId,
        sl = {
          friends: "Friends",
          followers: "Followers",
          requests: "Requests",
          followings: "Followings",
        },
        il = {
          friendsDict: function (e) {
            return "Roblox.".concat(sl[e], "Dict.UserId").concat(ol || 0);
          },
        },
        ul = i.EnvironmentUrls.friendsApi,
        ll = i.EnvironmentUrls.presenceApi,
        dl = i.EnvironmentUrls.websiteUrl,
        cl = function (e) {
          return "".concat(dl, "/users/").concat(e, "/profile");
        },
        vl = function () {
          return "".concat(ll, "/v1/presence/users");
        },
        pl = 100,
        hl = {
          friends: function (e) {
            return "".concat(ul, "/v1/users/").concat(e, "/friends");
          },
          followers: function (e) {
            return "".concat(ul, "/v1/users/").concat(e, "/followers");
          },
          followings: function (e) {
            return "".concat(ul, "/v1/users/").concat(e, "/followings");
          },
          friendrequests: function () {
            return "".concat(ul, "/v1/my/friends/requests");
          },
        };
      function ml(a, n, o) {
        var e = {
            url: hl[n](i.CurrentUser.userId),
            retryable: !0,
            withCredentials: !0,
          },
          s = { url: vl(), retryable: !0, withCredentials: !0 };
        return y.d.get(e).then(function (e) {
          var t = e.data.data || e,
            r = [];
          return (
            (a[n] = {}),
            t.forEach(function (e) {
              var t = e.id;
              (r.push(t), (e.profileUrl = cl(t)), (a[n][t] = e));
            }),
            y.d.buildBatchPromises(r, pl, s, !0).then(function (e) {
              if (e && 0 < e.length) {
                var r = [];
                (e.forEach(function (e) {
                  var t = e.data.userPresences;
                  r = r.concat(t);
                }),
                  r.forEach(function (e) {
                    a[n][e.userId].presence = e;
                  }));
              }
              return (
                o &&
                  (ei.saveDataByTimeStamp(il.friendsDict(n), a[n]),
                  (function (e) {
                    document.addEventListener("Roblox.Logout", function () {
                      ei.removeLocalStorage(il.friendsDict(e));
                    });
                  })(n)),
                a[n]
              );
            })
          );
        });
      }
      function gl(e, t, r) {
        var a = r.expirationMS,
          n = r.isEnabled;
        if (n) {
          var o = (function (e, t) {
            var r = ei.fetchNonExpiredCachedData(il.friendsDict(e), t);
            return r ? r.data : null;
          })(t, a);
          if (o)
            return new Promise(function (e) {
              e(o);
            });
        }
        return ml(e, t, n);
      }
      function fl(e, t) {
        for (var r = 0; r < t.length; r++) {
          var a = t[r];
          ((a.enumerable = a.enumerable || !1),
            (a.configurable = !0),
            "value" in a && (a.writable = !0),
            Object.defineProperty(e, a.key, a));
        }
      }
      var Gl = new ((function () {
        function e() {
          (!(function (e, t) {
            if (!(e instanceof t))
              throw new TypeError("Cannot call a class as a function");
          })(this, e),
            (this.callbacks = new Set()),
            (this.friendsDict = {}));
        }
        return (
          (function (e, t, r) {
            (t && fl(e.prototype, t), r && fl(e, r));
          })(e, [
            {
              key: "unSubscribe",
              value: function (e) {
                this.callbacks.delete(e);
              },
            },
            {
              key: "subscribe",
              value: function (e, r, t) {
                var a = this,
                  n = "function" == typeof e,
                  o = t && t.isEnabled;
                (n && this.callbacks.add(e),
                  o && this.friendsDict[r]
                    ? n && e(this.friendsDict[r])
                    : gl(this.friendsDict, r, t).then(function (t) {
                        (o &&
                          (function (r, a) {
                            a &&
                              document.addEventListener(
                                "Roblox.Presence.Update",
                                function (e, t) {
                                  t &&
                                    setTimeout(function () {
                                      (t.forEach(function (e) {
                                        var t = e.userId;
                                        a[t] && (a[t].presence = e);
                                      }),
                                        ei.saveDataByTimeStamp(
                                          il.friendsDict(r),
                                          a,
                                        ));
                                    });
                                },
                              );
                          })(r, t),
                          (a.friendsDict[r] = t),
                          a.callbacks.forEach(function (e) {
                            e(t);
                          }));
                      }));
              },
            },
            {
              key: "refreshCacheData",
              value: function (e, t) {
                var r = t.isEnabled;
                return ml(this.friendsDict, e, r);
              },
            },
          ]),
          e
        );
      })())();
      Gl.TYPE = {
        FRIENDS: "friends",
        FOLLOWERS: "followers",
        FOLLOWINGS: "followings",
        FRIENDREQUESTS: "friendrequests",
      };
      var yl = Gl;
      window.CoreRobloxUtilities = {
        dataStores: Su,
        entityUrl: Hu,
        eventStreamService: Qu,
        hybridService: nl,
        localStorageService: ei,
        localStorageNames: il,
        userInfoService: yl,
      };
    },
    52: function (e, t) {
      function r(e) {
        return (r =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      var a;
      a = (function () {
        return this;
      })();
      try {
        a = a || new Function("return this")();
      } catch (e) {
        "object" === ("undefined" == typeof window ? "undefined" : r(window)) &&
          (a = window);
      }
      e.exports = a;
    },
    61: function (e, t, r) {
      "use strict";
      e.exports = function (r, a) {
        return function () {
          for (var e = new Array(arguments.length), t = 0; t < e.length; t++)
            e[t] = arguments[t];
          return r.apply(a, e);
        };
      };
    },
    62: function (e, t, d) {
      "use strict";
      var c = d(10),
        v = d(92),
        p = d(94),
        h = d(95),
        m = d(96),
        g = d(63);
      e.exports = function (l) {
        return new Promise(function (r, a) {
          var n = l.data,
            o = l.headers;
          c.isFormData(n) && delete o["Content-Type"];
          var s = new XMLHttpRequest();
          if (l.auth) {
            var e = l.auth.username || "",
              t = l.auth.password || "";
            o.Authorization = "Basic " + btoa(e + ":" + t);
          }
          if (
            (s.open(
              l.method.toUpperCase(),
              p(l.url, l.params, l.paramsSerializer),
              !0,
            ),
            (s.timeout = l.timeout),
            (s.onreadystatechange = function () {
              if (
                s &&
                4 === s.readyState &&
                (0 !== s.status ||
                  (s.responseURL && 0 === s.responseURL.indexOf("file:")))
              ) {
                var e =
                    "getAllResponseHeaders" in s
                      ? h(s.getAllResponseHeaders())
                      : null,
                  t = {
                    data:
                      l.responseType && "text" !== l.responseType
                        ? s.response
                        : s.responseText,
                    status: s.status,
                    statusText: s.statusText,
                    headers: e,
                    config: l,
                    request: s,
                  };
                (v(r, a, t), (s = null));
              }
            }),
            (s.onerror = function () {
              (a(g("Network Error", l, null, s)), (s = null));
            }),
            (s.ontimeout = function () {
              (a(
                g(
                  "timeout of " + l.timeout + "ms exceeded",
                  l,
                  "ECONNABORTED",
                  s,
                ),
              ),
                (s = null));
            }),
            c.isStandardBrowserEnv())
          ) {
            var i = d(97),
              u =
                (l.withCredentials || m(l.url)) && l.xsrfCookieName
                  ? i.read(l.xsrfCookieName)
                  : void 0;
            u && (o[l.xsrfHeaderName] = u);
          }
          if (
            ("setRequestHeader" in s &&
              c.forEach(o, function (e, t) {
                void 0 === n && "content-type" === t.toLowerCase()
                  ? delete o[t]
                  : s.setRequestHeader(t, e);
              }),
            l.withCredentials && (s.withCredentials = !0),
            l.responseType)
          )
            try {
              s.responseType = l.responseType;
            } catch (e) {
              if ("json" !== l.responseType) throw e;
            }
          ("function" == typeof l.onDownloadProgress &&
            s.addEventListener("progress", l.onDownloadProgress),
            "function" == typeof l.onUploadProgress &&
              s.upload &&
              s.upload.addEventListener("progress", l.onUploadProgress),
            l.cancelToken &&
              l.cancelToken.promise.then(function (e) {
                s && (s.abort(), a(e), (s = null));
              }),
            void 0 === n && (n = null),
            s.send(n));
        });
      };
    },
    63: function (e, t, r) {
      "use strict";
      var s = r(93);
      e.exports = function (e, t, r, a, n) {
        var o = new Error(e);
        return s(o, t, r, a, n);
      };
    },
    64: function (e, t, r) {
      "use strict";
      e.exports = function (e) {
        return !(!e || !e.__CANCEL__);
      };
    },
    65: function (e, t, r) {
      "use strict";
      function a(e) {
        this.message = e;
      }
      ((a.prototype.toString = function () {
        return "Cancel" + (this.message ? ": " + this.message : "");
      }),
        (a.prototype.__CANCEL__ = !0),
        (e.exports = a));
    },
    66: function (e, t) {
      e.exports = function (e) {
        return (
          e.webpackPolyfill ||
            ((e.deprecate = function () {}),
            (e.paths = []),
            e.children || (e.children = []),
            Object.defineProperty(e, "loaded", {
              enumerable: !0,
              get: function () {
                return e.l;
              },
            }),
            Object.defineProperty(e, "id", {
              enumerable: !0,
              get: function () {
                return e.i;
              },
            }),
            (e.webpackPolyfill = 1)),
          e
        );
      };
    },
    87: function (e, t, r) {
      "use strict";
      var a = r(10),
        n = r(61),
        o = r(89),
        s = r(40);
      function i(e) {
        var t = new o(e),
          r = n(o.prototype.request, t);
        return (a.extend(r, o.prototype, t), a.extend(r, t), r);
      }
      var u = i(s);
      ((u.Axios = o),
        (u.create = function (e) {
          return i(a.merge(s, e));
        }),
        (u.Cancel = r(65)),
        (u.CancelToken = r(103)),
        (u.isCancel = r(64)),
        (u.all = function (e) {
          return Promise.all(e);
        }),
        (u.spread = r(104)),
        (e.exports = u),
        (e.exports.default = u));
    },
    88: function (e, t) {
      /*!
       * Determine if an object is a Buffer
       *
       * @author   Feross Aboukhadijeh <https://feross.org>
       * @license  MIT
       */
      e.exports = function (e) {
        return (
          null != e &&
          null != e.constructor &&
          "function" == typeof e.constructor.isBuffer &&
          e.constructor.isBuffer(e)
        );
      };
    },
    89: function (e, t, r) {
      "use strict";
      var n = r(40),
        o = r(10),
        a = r(98),
        s = r(99);
      function i(e) {
        ((this.defaults = e),
          (this.interceptors = { request: new a(), response: new a() }));
      }
      ((i.prototype.request = function (e, t) {
        ("string" == typeof e && (e = o.merge({ url: arguments[0] }, t)),
          ((e = o.merge(n, { method: "get" }, this.defaults, e)).method =
            e.method.toLowerCase()));
        var r = [s, void 0],
          a = Promise.resolve(e);
        for (
          this.interceptors.request.forEach(function (e) {
            r.unshift(e.fulfilled, e.rejected);
          }),
            this.interceptors.response.forEach(function (e) {
              r.push(e.fulfilled, e.rejected);
            });
          r.length;
        )
          a = a.then(r.shift(), r.shift());
        return a;
      }),
        o.forEach(["delete", "get", "head", "options"], function (r) {
          i.prototype[r] = function (e, t) {
            return this.request(o.merge(t || {}, { method: r, url: e }));
          };
        }),
        o.forEach(["post", "put", "patch"], function (a) {
          i.prototype[a] = function (e, t, r) {
            return this.request(
              o.merge(r || {}, { method: a, url: e, data: t }),
            );
          };
        }),
        (e.exports = i));
    },
    90: function (e, t) {
      var r,
        a,
        n = (e.exports = {});
      function o() {
        throw new Error("setTimeout has not been defined");
      }
      function s() {
        throw new Error("clearTimeout has not been defined");
      }
      function i(t) {
        if (r === setTimeout) return setTimeout(t, 0);
        if ((r === o || !r) && setTimeout)
          return ((r = setTimeout), setTimeout(t, 0));
        try {
          return r(t, 0);
        } catch (e) {
          try {
            return r.call(null, t, 0);
          } catch (e) {
            return r.call(this, t, 0);
          }
        }
      }
      !(function () {
        try {
          r = "function" == typeof setTimeout ? setTimeout : o;
        } catch (e) {
          r = o;
        }
        try {
          a = "function" == typeof clearTimeout ? clearTimeout : s;
        } catch (e) {
          a = s;
        }
      })();
      var u,
        l = [],
        d = !1,
        c = -1;
      function v() {
        d &&
          u &&
          ((d = !1), u.length ? (l = u.concat(l)) : (c = -1), l.length && p());
      }
      function p() {
        if (!d) {
          var e = i(v);
          d = !0;
          for (var t = l.length; t; ) {
            for (u = l, l = []; ++c < t; ) u && u[c].run();
            ((c = -1), (t = l.length));
          }
          ((u = null),
            (d = !1),
            (function (t) {
              if (a === clearTimeout) return clearTimeout(t);
              if ((a === s || !a) && clearTimeout)
                return ((a = clearTimeout), clearTimeout(t));
              try {
                a(t);
              } catch (e) {
                try {
                  return a.call(null, t);
                } catch (e) {
                  return a.call(this, t);
                }
              }
            })(e));
        }
      }
      function h(e, t) {
        ((this.fun = e), (this.array = t));
      }
      function m() {}
      ((n.nextTick = function (e) {
        var t = new Array(arguments.length - 1);
        if (1 < arguments.length)
          for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
        (l.push(new h(e, t)), 1 !== l.length || d || i(p));
      }),
        (h.prototype.run = function () {
          this.fun.apply(null, this.array);
        }),
        (n.title = "browser"),
        (n.browser = !0),
        (n.env = {}),
        (n.argv = []),
        (n.version = ""),
        (n.versions = {}),
        (n.on = m),
        (n.addListener = m),
        (n.once = m),
        (n.off = m),
        (n.removeListener = m),
        (n.removeAllListeners = m),
        (n.emit = m),
        (n.prependListener = m),
        (n.prependOnceListener = m),
        (n.listeners = function (e) {
          return [];
        }),
        (n.binding = function (e) {
          throw new Error("process.binding is not supported");
        }),
        (n.cwd = function () {
          return "/";
        }),
        (n.chdir = function (e) {
          throw new Error("process.chdir is not supported");
        }),
        (n.umask = function () {
          return 0;
        }));
    },
    91: function (e, t, r) {
      "use strict";
      var n = r(10);
      e.exports = function (r, a) {
        n.forEach(r, function (e, t) {
          t !== a &&
            t.toUpperCase() === a.toUpperCase() &&
            ((r[a] = e), delete r[t]);
        });
      };
    },
    92: function (e, t, r) {
      "use strict";
      var n = r(63);
      e.exports = function (e, t, r) {
        var a = r.config.validateStatus;
        r.status && a && !a(r.status)
          ? t(
              n(
                "Request failed with status code " + r.status,
                r.config,
                null,
                r.request,
                r,
              ),
            )
          : e(r);
      };
    },
    93: function (e, t, r) {
      "use strict";
      e.exports = function (e, t, r, a, n) {
        return (
          (e.config = t),
          r && (e.code = r),
          (e.request = a),
          (e.response = n),
          e
        );
      };
    },
    94: function (e, t, r) {
      "use strict";
      var o = r(10);
      function s(e) {
        return encodeURIComponent(e)
          .replace(/%40/gi, "@")
          .replace(/%3A/gi, ":")
          .replace(/%24/g, "$")
          .replace(/%2C/gi, ",")
          .replace(/%20/g, "+")
          .replace(/%5B/gi, "[")
          .replace(/%5D/gi, "]");
      }
      e.exports = function (e, t, r) {
        if (!t) return e;
        var a;
        if (r) a = r(t);
        else if (o.isURLSearchParams(t)) a = t.toString();
        else {
          var n = [];
          (o.forEach(t, function (e, t) {
            null != e &&
              (o.isArray(e) ? (t += "[]") : (e = [e]),
              o.forEach(e, function (e) {
                (o.isDate(e)
                  ? (e = e.toISOString())
                  : o.isObject(e) && (e = JSON.stringify(e)),
                  n.push(s(t) + "=" + s(e)));
              }));
          }),
            (a = n.join("&")));
        }
        return (a && (e += (-1 === e.indexOf("?") ? "?" : "&") + a), e);
      };
    },
    95: function (e, t, r) {
      "use strict";
      var o = r(10),
        s = [
          "age",
          "authorization",
          "content-length",
          "content-type",
          "etag",
          "expires",
          "from",
          "host",
          "if-modified-since",
          "if-unmodified-since",
          "last-modified",
          "location",
          "max-forwards",
          "proxy-authorization",
          "referer",
          "retry-after",
          "user-agent",
        ];
      e.exports = function (e) {
        var t,
          r,
          a,
          n = {};
        return (
          e &&
            o.forEach(e.split("\n"), function (e) {
              if (
                ((a = e.indexOf(":")),
                (t = o.trim(e.substr(0, a)).toLowerCase()),
                (r = o.trim(e.substr(a + 1))),
                t)
              ) {
                if (n[t] && 0 <= s.indexOf(t)) return;
                n[t] =
                  "set-cookie" === t
                    ? (n[t] ? n[t] : []).concat([r])
                    : n[t]
                      ? n[t] + ", " + r
                      : r;
              }
            }),
          n
        );
      };
    },
    96: function (e, t, r) {
      "use strict";
      var a,
        n,
        o,
        s = r(10);
      function i(e) {
        var t = e;
        return (
          n && (o.setAttribute("href", t), (t = o.href)),
          o.setAttribute("href", t),
          {
            href: o.href,
            protocol: o.protocol ? o.protocol.replace(/:$/, "") : "",
            host: o.host,
            search: o.search ? o.search.replace(/^\?/, "") : "",
            hash: o.hash ? o.hash.replace(/^#/, "") : "",
            hostname: o.hostname,
            port: o.port,
            pathname:
              "/" === o.pathname.charAt(0) ? o.pathname : "/" + o.pathname,
          }
        );
      }
      e.exports = s.isStandardBrowserEnv()
        ? ((n = /(msie|trident)/i.test(navigator.userAgent)),
          (o = document.createElement("a")),
          (a = i(window.location.href)),
          function (e) {
            var t = s.isString(e) ? i(e) : e;
            return t.protocol === a.protocol && t.host === a.host;
          })
        : function () {
            return !0;
          };
    },
    97: function (e, t, r) {
      "use strict";
      var i = r(10);
      e.exports = i.isStandardBrowserEnv()
        ? {
            write: function (e, t, r, a, n, o) {
              var s = [];
              (s.push(e + "=" + encodeURIComponent(t)),
                i.isNumber(r) && s.push("expires=" + new Date(r).toGMTString()),
                i.isString(a) && s.push("path=" + a),
                i.isString(n) && s.push("domain=" + n),
                !0 === o && s.push("secure"),
                (document.cookie = s.join("; ")));
            },
            read: function (e) {
              var t = document.cookie.match(
                new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"),
              );
              return t ? decodeURIComponent(t[3]) : null;
            },
            remove: function (e) {
              this.write(e, "", Date.now() - 864e5);
            },
          }
        : {
            write: function () {},
            read: function () {
              return null;
            },
            remove: function () {},
          };
    },
    98: function (e, t, r) {
      "use strict";
      var a = r(10);
      function n() {
        this.handlers = [];
      }
      ((n.prototype.use = function (e, t) {
        return (
          this.handlers.push({ fulfilled: e, rejected: t }),
          this.handlers.length - 1
        );
      }),
        (n.prototype.eject = function (e) {
          this.handlers[e] && (this.handlers[e] = null);
        }),
        (n.prototype.forEach = function (t) {
          a.forEach(this.handlers, function (e) {
            null !== e && t(e);
          });
        }),
        (e.exports = n));
    },
    99: function (e, t, r) {
      "use strict";
      var a = r(10),
        n = r(100),
        o = r(64),
        s = r(40),
        i = r(101),
        u = r(102);
      function l(e) {
        e.cancelToken && e.cancelToken.throwIfRequested();
      }
      e.exports = function (t) {
        return (
          l(t),
          t.baseURL && !i(t.url) && (t.url = u(t.baseURL, t.url)),
          (t.headers = t.headers || {}),
          (t.data = n(t.data, t.headers, t.transformRequest)),
          (t.headers = a.merge(
            t.headers.common || {},
            t.headers[t.method] || {},
            t.headers || {},
          )),
          a.forEach(
            ["delete", "get", "head", "post", "put", "patch", "common"],
            function (e) {
              delete t.headers[e];
            },
          ),
          (t.adapter || s.adapter)(t).then(
            function (e) {
              return (
                l(t),
                (e.data = n(e.data, e.headers, t.transformResponse)),
                e
              );
            },
            function (e) {
              return (
                o(e) ||
                  (l(t),
                  e &&
                    e.response &&
                    (e.response.data = n(
                      e.response.data,
                      e.response.headers,
                      t.transformResponse,
                    ))),
                Promise.reject(e)
              );
            },
          )
        );
      };
    },
  });
  //# sourceMappingURL=https://js.rbxcdn.com/a32ebe964bd68192f8cc-coreRobloxUtilities.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("CoreRobloxUtilities");
}
