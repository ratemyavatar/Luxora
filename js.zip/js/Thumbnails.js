var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (e) {
    var r = {};
    function i(n) {
      if (r[n]) return r[n].exports;
      var t = (r[n] = { i: n, l: !1, exports: {} });
      return (e[n].call(t.exports, t, t.exports, i), (t.l = !0), t.exports);
    }
    ((i.m = e),
      (i.c = r),
      (i.d = function (n, t, e) {
        i.o(n, t) || Object.defineProperty(n, t, { enumerable: !0, get: e });
      }),
      (i.r = function (n) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(n, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(n, "__esModule", { value: !0 }));
      }),
      (i.t = function (t, n) {
        if ((1 & n && (t = i(t)), 8 & n)) return t;
        if (4 & n && "object" == typeof t && t && t.__esModule) return t;
        var e = Object.create(null);
        if (
          (i.r(e),
          Object.defineProperty(e, "default", { enumerable: !0, value: t }),
          2 & n && "string" != typeof t)
        )
          for (var r in t)
            i.d(
              e,
              r,
              function (n) {
                return t[n];
              }.bind(null, r),
            );
        return e;
      }),
      (i.n = function (n) {
        var t =
          n && n.__esModule
            ? function () {
                return n.default;
              }
            : function () {
                return n;
              };
        return (i.d(t, "a", t), t);
      }),
      (i.o = function (n, t) {
        return Object.prototype.hasOwnProperty.call(n, t);
      }),
      (i.p = ""),
      i((i.s = 50)));
  })([
    function (n, t, e) {
      "use strict";
      var r, i;
      (e.r(t),
        e.d(t, "ThumbnailTypes", function () {
          return r;
        }),
        e.d(t, "DefaultBatchSize", function () {
          return u;
        }),
        e.d(t, "ThumbnailCooldown", function () {
          return a;
        }),
        e.d(t, "DefaultThumbnailSize", function () {
          return P;
        }),
        e.d(t, "DefaultThumbnailFormat", function () {
          return $;
        }),
        e.d(t, "ThumbnailGameIconSize", function () {
          return l;
        }),
        e.d(t, "ThumbnailGamePassIconSize", function () {
          return c;
        }),
        e.d(t, "ThumbnailAssetsSize", function () {
          return m;
        }),
        e.d(t, "ThumbnailAvatarsSize", function () {
          return d;
        }),
        e.d(t, "ThumbnailAvatarHeadshotSize", function () {
          return b;
        }),
        e.d(t, "ThumbnailGroupIconSize", function () {
          return p;
        }),
        e.d(t, "ThumbnailBadgeIconSize", function () {
          return T;
        }),
        e.d(t, "ThumbnailDeveloperProductIconSize", function () {
          return y;
        }),
        e.d(t, "ThumbnailGameThumbnailSize", function () {
          return I;
        }),
        e.d(t, "ThumbnailStates", function () {
          return S;
        }),
        e.d(t, "ThumbnailFormat", function () {
          return O;
        }),
        e.d(t, "ReturnPolicy", function () {
          return x;
        }),
        ((i = r = r || {}).assetThumbnail = "assetThumbnail"),
        (i.avatarHeadshot = "avatarHeadshot"),
        (i.avatar = "avatar"),
        (i.bundleThumbnail = "bundleThumbnail"),
        (i.gameIcon = "gameIcon"),
        (i.groupIcon = "groupIcon"),
        (i.badgeIcon = "badgeIcon"),
        (i.gamePassIcon = "gamePassIcon"),
        (i.developerProductIcon = "developerProductIcon"),
        (i.userOutfit = "userOutfit"),
        (i.gameThumbnail = "gameThumbnail"));
      var a,
        o,
        u = 100;
      (((o = a = a || {})[(o.maxRetryAttempts = 10)] = "maxRetryAttempts"),
        (o[(o.minCooldown = 1e3)] = "minCooldown"),
        (o[(o.maxCooldown = 3e4)] = "maxCooldown"));
      var l,
        s,
        c,
        m,
        f,
        d,
        h,
        b,
        g,
        p,
        v,
        T,
        y,
        I,
        C,
        S,
        w,
        O,
        z,
        x,
        j,
        P = "150x150",
        $ = "png";
      (((s = l = l || {}).size50 = "50x50"),
        (s.size150 = "150x150"),
        ((c = c || {}).size150 = "150x150"),
        ((f = m = m || {}).size150 = "150x150"),
        (f.size420 = "420x420"),
        ((h = d = d || {}).size100 = "100x100"),
        (h.size352 = "352x352"),
        (h.size720 = "720x720"),
        ((g = b = b || {}).size48 = "48x48"),
        (g.size60 = "60x60"),
        (g.size150 = "150x150"),
        ((v = p = p || {}).size150 = "150x150"),
        (v.size420 = "420x420"),
        ((T = T || {}).size150 = "150x150"),
        ((y = y || {}).size150 = "150x150"),
        ((C = I = I || {}).width768 = "768x432"),
        (C.width576 = "576x324"),
        (C.width480 = "480x270"),
        (C.width384 = "384x216"),
        (C.width256 = "256x144"),
        ((w = S = S || {}).error = "Error"),
        (w.complete = "Completed"),
        (w.inReview = "InReview"),
        (w.pending = "Pending"),
        (w.blocked = "Blocked"),
        ((z = O = O || {}).png = "png"),
        (z.jpg = "jpg"),
        (z.jpeg = "jpeg"),
        ((j = x = x || {}).PlaceHolder = "PlaceHolder"),
        (j.AutoGenerated = "AutoGenerated"),
        (j.ForceAutoGenerated = "ForceAutoGenerated"));
    },
    function (n, t) {
      n.exports = Roblox;
    },
    ,
    function (n, t) {
      function a(n) {
        return n.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
      }
      function o(n) {
        return n.split("/").pop().replace(".html", "");
      }
      var e = {
        importFilesUnderPath: function (n) {
          n.keys().forEach(n);
        },
        templateCacheGenerator: function (n, t, r, i) {
          return n.module(t, []).run([
            "$templateCache",
            function (e) {
              (r &&
                r.keys().forEach(function (n) {
                  var t = a(o(n));
                  e.put(t, r(n));
                }),
                i &&
                  i.keys().forEach(function (n) {
                    var t = a(o(n));
                    e.put(
                      t,
                      (function (n) {
                        return n.replace(/<\/?script[^>]*>/gi, "");
                      })(i(n)),
                    );
                  }));
            },
          ]);
        },
      };
      n.exports = e;
    },
    function (n, t, e) {
      "use strict";
      var r = e(9),
        i = e
          .n(r)
          .a.module("thumbnails", [
            "robloxApp",
            "thumbnailsTemplates",
            "angularLazyImg",
          ]);
      t.a = i;
    },
    function (n, t) {
      n.exports = PropTypes;
    },
    ,
    function (n, t, e) {
      "use strict";
      function d(n) {
        var t, e;
        return null !=
          (e = null === (t = n) || void 0 === t ? void 0 : t.toString())
          ? e
          : "";
      }
      function l(a, l, s, c, m) {
        void 0 === m && (m = g.ThumbnailFormat.png);
        var f = (function (n) {
          var t = v[n];
          return (
            t ||
              console.debug(
                "Missing urlConfig implementation for thumbnail type: " + n,
              ),
            t
          );
        })(s);
        return new Promise(function (i, n) {
          var t,
            e = l,
            o = !!(null === (t = l[0]) || void 0 === t ? void 0 : t.itemId);
          if (
            (o &&
              (e = l.map(function (n) {
                return n.itemId;
              })),
            f)
          ) {
            var u = new Date().getTime(),
              r = [];
            ((r =
              s === g.ThumbnailTypes.assetThumbnail ||
              s === g.ThumbnailTypes.gameIcon
                ? [e, g.ReturnPolicy.PlaceHolder, c, m]
                : s === g.ThumbnailTypes.gameThumbnail
                  ? [a, e, c, m]
                  : [e, c, m]),
              f
                .apply(null, r)
                .then(function (n) {
                  var t,
                    e,
                    r,
                    a = {};
                  ((null !=
                  (r =
                    null ===
                      (e =
                        null === (t = n) || void 0 === t ? void 0 : t.data) ||
                    void 0 === e
                      ? void 0
                      : e.data)
                    ? r
                    : []
                  ).forEach(function (n) {
                    a[d(n.targetId)] = n;
                  }),
                    l.forEach(function (n) {
                      var t,
                        e = 0;
                      o ? ((e = n.itemId), (t = n.startTime)) : (e = n);
                      var r = d(e);
                      if (Object.prototype.hasOwnProperty.call(a, r) && a[r]) {
                        if (a[r].state === g.ThumbnailStates.pending)
                          (delete a[r], p[r] || (p[r] = { startTime: u }));
                        else if (a[r].state === g.ThumbnailStates.complete) {
                          var i = new Date().getTime();
                          (p[r] &&
                            h.ThumbnailMetrics &&
                            (h.ThumbnailMetrics.logFinalThumbnailTime(
                              i - p[r].startTime,
                            ),
                            delete p[r]),
                            t &&
                              h.ThumbnailMetrics &&
                              h.ThumbnailMetrics.logFinalThumbnailTime(
                                i - t.getTime(),
                              ));
                        }
                      } else
                        a[r] = { targetId: e, state: g.ThumbnailStates.error };
                    }),
                    i(a));
                })
                .catch(function () {
                  i({});
                }));
          } else n(b.BatchRequestError.unretriableFailure);
        });
      }
      function a(t, e, n, r, i, a) {
        if ((void 0 === i && (i = g.ThumbnailFormat.png), !n))
          return new Promise(function (n, t) {
            t("TargetId can not be empty.");
          });
        if (!t)
          return new Promise(function (n, t) {
            t("ThumbnailType can not be empty.");
          });
        var o = (function (n, t, e, r, i) {
            return (
              void 0 === i && (i = g.ThumbnailFormat.png),
              "thumbnail_type:" +
                n +
                "_baseTargetId:" +
                t +
                "_targetId:" +
                e +
                "_requestedSize:" +
                r +
                "_format:" +
                i
            );
          })(t, e, n, r, i),
          u = (function (n, t, e, r) {
            return (
              void 0 === r && (r = g.ThumbnailFormat.png),
              n + ":" + t + ":" + e + ":" + r
            );
          })(e, t, r, i);
        return m(
          n,
          function (n) {
            return l(e, n, t, r, i);
          },
          u,
          o,
          a,
        );
      }
      var r,
        h = e(1),
        b = e(10),
        i = e(13),
        g = e(0),
        u = {
          getFailureCooldown:
            b.batchRequestFactory.createExponentialBackoffCooldown(
              g.ThumbnailCooldown.minCooldown,
              g.ThumbnailCooldown.maxCooldown,
            ),
          maxRetryAttempts: g.ThumbnailCooldown.maxRetryAttempts,
          batchSize: g.DefaultBatchSize,
        },
        s = {},
        c = {},
        m = function (n, t, e, r, i) {
          if ((i && r && delete c[r], !(r in c))) {
            var a = (function (n, t) {
              if (t in s) return s[t];
              var e = b.batchRequestFactory.createRequestProcessor(n, d, u);
              return (s[t] = e);
            })(t, e);
            i && a.invalidateItem(n);
            var o = a.queueItem(n).catch(function (n) {
              return (
                h.ThumbnailMetrics && h.ThumbnailMetrics.logThumbnailTimeout(),
                Promise.reject(n)
              );
            });
            c[r] = o;
          }
          return c[r];
        },
        p = {},
        o = i.dataStores.thumbnailsDataStore,
        f = i.dataStores.gameThumbnailsDataStore,
        v =
          (((r = {})[g.ThumbnailTypes.assetThumbnail] = o.getAssets),
          (r[g.ThumbnailTypes.avatarHeadshot] = o.getAvatarHeadshots),
          (r[g.ThumbnailTypes.avatar] = o.getAvatars),
          (r[g.ThumbnailTypes.bundleThumbnail] = o.getBundles),
          (r[g.ThumbnailTypes.gameIcon] = f.getIcons),
          (r[g.ThumbnailTypes.groupIcon] = o.getGroupIcons),
          (r[g.ThumbnailTypes.badgeIcon] = o.getBadgeIcons),
          (r[g.ThumbnailTypes.gamePassIcon] = f.getGamePassIcons),
          (r[g.ThumbnailTypes.developerProductIcon] =
            o.getDeveloperProductIcons),
          (r[g.ThumbnailTypes.userOutfit] = o.getUserOutfits),
          (r[g.ThumbnailTypes.gameThumbnail] = f.getThumbnailsByThumbnailIds),
          r);
      t.a = {
        getThumbnailImage: function (n, t, e, r) {
          return (
            void 0 === r && (r = g.ThumbnailFormat.png),
            a(n, null, t, e, r)
          );
        },
        getCssClass: function (n) {
          return {
            "icon-broken": n === g.ThumbnailStates.error,
            "icon-in-review": n === g.ThumbnailStates.inReview,
            "icon-blocked": n === g.ThumbnailStates.blocked,
            "icon-pending": n === g.ThumbnailStates.pending,
          };
        },
        reloadThumbnailImage: function (n, t, e, r) {
          return (
            void 0 === r && (r = g.ThumbnailFormat.png),
            a(n, null, t, e, r, !0)
          );
        },
        getThumbnailImageWithBaseTarget: function (n, t, e, r, i) {
          return (
            void 0 === i && (i = g.ThumbnailFormat.png),
            a(n, t, e, r, i)
          );
        },
      };
    },
    function (n, t) {
      n.exports = React;
    },
    function (n, t) {
      n.exports = angular;
    },
    function (n, t) {
      n.exports = CoreUtilities;
    },
    function (n, t, e) {
      var r;
      function l(n) {
        return (l =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (n) {
                return typeof n;
              }
            : function (n) {
                return n &&
                  "function" == typeof Symbol &&
                  n.constructor === Symbol &&
                  n !== Symbol.prototype
                  ? "symbol"
                  : typeof n;
              })(n);
      }
      /*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
      /*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
      !(function () {
        "use strict";
        var o = {}.hasOwnProperty;
        function u() {
          for (var n = [], t = 0; t < arguments.length; t++) {
            var e = arguments[t];
            if (e) {
              var r = l(e);
              if ("string" === r || "number" === r) n.push(e);
              else if (Array.isArray(e) && e.length) {
                var i = u.apply(null, e);
                i && n.push(i);
              } else if ("object" === r)
                for (var a in e) o.call(e, a) && e[a] && n.push(a);
            }
          }
          return n.join(" ");
        }
        n.exports
          ? ((u.default = u), (n.exports = u))
          : "object" === l(e(14)) && e(14)
            ? void 0 ===
                (r = function () {
                  return u;
                }.apply(t, [])) || (n.exports = r)
            : (window.classNames = u);
      })();
    },
    function (n, t) {
      angular
        .module("angularLazyImg", [])
        .factory("LazyImgMagic", [
          "$window",
          "$rootScope",
          "lazyImgConfig",
          "lazyImgHelpers",
          function (n, e, t, r) {
            "use strict";
            var i, a, o, u, l, s, c, m;
            function f() {
              for (var n = o.length - 1; 0 <= n; n--) {
                var t = o[n];
                t &&
                  r.isElementInView(t.$elem[0], l.offset, i) &&
                  (g(t), o.splice(n, 1));
              }
              0 === o.length && b();
            }
            function d(t) {
              (m.forEach(function (n) {
                (n[t]("scroll", s), n[t]("touchmove", s));
              }),
                a[t]("resize", s),
                a[t]("resize", c));
            }
            function h() {
              ((u = !0),
                setTimeout(function () {
                  (f(), d("on"));
                }, 1));
            }
            function b() {
              ((u = !1), d("off"));
            }
            function g(n) {
              var t = new Image();
              ((t.onerror = function () {
                (l.errorClass && n.$elem.addClass(l.errorClass),
                  e.$emit("lazyImg:error", n),
                  l.onError(n));
              }),
                (t.onload = function () {
                  (!(function (n, t) {
                    "img" === n[0].nodeName.toLowerCase()
                      ? (n[0].src = t)
                      : n.css("background-image", 'url("' + t + '")');
                  })(n.$elem, n.src),
                    n.$elem.removeClass(l.loadingClass),
                    l.successClass && n.$elem.addClass(l.successClass),
                    e.$emit("lazyImg:success", n),
                    l.onSuccess(n));
                }),
                (t.src = n.src));
            }
            function p(n) {
              (n.addClass(l.loadingClass), (this.$elem = n));
            }
            return (
              (u = !(o = [])),
              (l = t.getOptions()),
              (a = angular.element(n)),
              (i = r.getWinDimensions()),
              (c = r.throttle(function () {
                i = r.getWinDimensions();
              }, 60)),
              (m = [l.container || a]),
              (s = r.throttle(f, 30)),
              (p.prototype.setSource = function (n) {
                ((this.src = n), o.unshift(this), u || h());
              }),
              (p.prototype.removeImage = function () {
                (!(function (n) {
                  var t = o.indexOf(n);
                  -1 !== t && o.splice(t, 1);
                })(this),
                  0 === o.length && b());
              }),
              (p.prototype.checkImages = function () {
                f();
              }),
              (p.addContainer = function (n) {
                (b(), m.push(n), h());
              }),
              (p.removeContainer = function (n) {
                (b(), m.splice(m.indexOf(n), 1), h());
              }),
              p
            );
          },
        ])
        .provider("lazyImgConfig", function () {
          "use strict";
          ((this.options = {
            offset: 100,
            errorClass: null,
            successClass: null,
            onError: function () {},
            onSuccess: function () {},
            loadingClass: "icon-placeholder-game",
          }),
            (this.$get = function () {
              var n = this.options;
              return {
                getOptions: function () {
                  return n;
                },
              };
            }),
            (this.setOptions = function (n) {
              angular.extend(this.options, n);
            }));
        })
        .factory("lazyImgHelpers", [
          "$window",
          function (n) {
            "use strict";
            return {
              isElementInView: function (n, t, e) {
                var r = n.getBoundingClientRect(),
                  i = e.height + t;
                return (
                  n.offsetParent &&
                  0 <= r.left &&
                  r.right <= e.width + t &&
                  ((0 <= r.top && r.top <= i) ||
                    (r.bottom <= i && r.bottom >= 0 - t))
                );
              },
              getWinDimensions: function () {
                return { height: n.innerHeight, width: n.innerWidth };
              },
              throttle: function (r, i, a) {
                var o, u;
                return function () {
                  var n = a || this,
                    t = +new Date(),
                    e = arguments;
                  o && t < o + i
                    ? (clearTimeout(u),
                      (u = setTimeout(function () {
                        ((o = t), r.apply(n, e));
                      }, i)))
                    : ((o = t), r.apply(n, e));
                };
              },
            };
          },
        ])
        .directive("lazyImg", [
          "$rootScope",
          "LazyImgMagic",
          function (i, a) {
            "use strict";
            return {
              link: function (n, t, e) {
                var r = new a(t);
                (e.$observe("lazyImg", function (n) {
                  n && r.setSource(n);
                }),
                  n.$on("$destroy", function () {
                    r.removeImage();
                  }),
                  i.$on("lazyImg.runCheck", function () {
                    r.checkImages();
                  }),
                  i.$on("lazyImg:refresh", function () {
                    r.checkImages();
                  }));
              },
              restrict: "A",
            };
          },
        ])
        .directive("lazyImgContainer", [
          "LazyImgMagic",
          function (e) {
            "use strict";
            return {
              link: function (n, t) {
                (e.addContainer(t),
                  n.$on("$destroy", function () {
                    e.removeContainer(t);
                  }));
              },
              restrict: "A",
            };
          },
        ]);
    },
    function (n, t) {
      n.exports = CoreRobloxUtilities;
    },
    function (t, n) {
      (function (n) {
        t.exports = n;
      }).call(this, {});
    },
    ,
    function (n, t, e) {},
    function (n, t, e) {
      var r = { "./2dThumbnailComponent.js": 18 };
      function i(n) {
        var t = a(n);
        return e(t);
      }
      function a(n) {
        var t = r[n];
        if (t + 1) return t;
        var e = new Error("Cannot find module '" + n + "'");
        throw ((e.code = "MODULE_NOT_FOUND"), e);
      }
      ((i.keys = function () {
        return Object.keys(r);
      }),
        (i.resolve = a),
        ((n.exports = i).id = 17));
    },
    function (n, t, e) {
      "use strict";
      e.r(t);
      var r = {
        templateUrl: "2d-thumbnail",
        bindings: {
          thumbnailType: "<",
          thumbnailTargetId: "<",
          thumbnailOptions: "<?",
        },
        controller: "2dThumbnailController",
      };
      (e(4).a.component("thumbnail2d", r), (t.default = r));
    },
    function (n, t, e) {
      var r = { "./thumbnailConstants.js": 20 };
      function i(n) {
        var t = a(n);
        return e(t);
      }
      function a(n) {
        var t = r[n];
        if (t + 1) return t;
        var e = new Error("Cannot find module '" + n + "'");
        throw ((e.code = "MODULE_NOT_FOUND"), e);
      }
      ((i.keys = function () {
        return Object.keys(r);
      }),
        (i.resolve = a),
        ((n.exports = i).id = 19));
    },
    function (n, t, e) {
      "use strict";
      e.r(t);
      var r = e(0),
        i = e(4),
        a = {
          thumbnailTypes: r.ThumbnailTypes,
          thumbnailStates: r.ThumbnailStates,
          formats: r.ThumbnailFormat,
          avatarHeadshotSize: r.ThumbnailAvatarHeadshotSize,
          gameIconSize: r.ThumbnailGameIconSize,
          thumbnailAvatarsSize: r.ThumbnailAvatarsSize,
        };
      (i.a.constant("thumbnailConstants", a), (t.default = a));
    },
    function (n, t, e) {
      var r = { "./2dThumbnailController.js": 22 };
      function i(n) {
        var t = a(n);
        return e(t);
      }
      function a(n) {
        var t = r[n];
        if (t + 1) return t;
        var e = new Error("Cannot find module '" + n + "'");
        throw ((e.code = "MODULE_NOT_FOUND"), e);
      }
      ((i.keys = function () {
        return Object.keys(r);
      }),
        (i.resolve = a),
        ((n.exports = i).id = 21));
    },
    function (n, t, e) {
      "use strict";
      e.r(t);
      var s = e(0),
        r = e(4);
      function i(n, a) {
        var o = this,
          u = "",
          l = s.ThumbnailStates;
        ((o.getCssClasses = function () {
          return o.isThumbnailRequestSending
            ? "shimmer"
            : a.getCssClass(o.thumbnailState);
        }),
          (o.setThumbnailLoadFailed = function () {}),
          (o.isLazyLoadingEnabled = function () {
            return o.thumbnailOptions && o.thumbnailOptions.isLazyLoading;
          }));
        function t() {
          var n,
            t,
            e = "".concat(o.thumbnailType, ":").concat(o.thumbnailTargetId);
          if (u !== e) {
            ((u = e), (o.thumbnailState = l.loading));
            var r =
                (null === (n = o.thumbnailOptions) || void 0 === n
                  ? void 0
                  : n.size) || s.DefaultThumbnailSize,
              i =
                (null === (t = o.thumbnailOptions) || void 0 === t
                  ? void 0
                  : t.format) || s.DefaultThumbnailFormat;
            ((o.isThumbnailRequestSending = !0),
              a
                .getThumbnailImage(o.thumbnailType, o.thumbnailTargetId, r, i)
                .then(
                  function (n) {
                    ((o.thumbnailState = n.state),
                      (o.thumbnailUrl = n.imageUrl));
                  },
                  function () {
                    o.thumbnailState = l.error;
                  },
                )
                .finally(function () {
                  o.isThumbnailRequestSending = !1;
                }));
          }
        }
        ((o.$onInit = t), (o.$onChanges = t));
      }
      ((i.$inject = ["$scope", "thumbnailService"]),
        r.a.controller("2dThumbnailController", i),
        (t.default = i));
    },
    function (n, t, e) {
      var r = {
        "./imageLoadDirective.js": 24,
        "./thumbnailErrorDirective.js": 25,
      };
      function i(n) {
        var t = a(n);
        return e(t);
      }
      function a(n) {
        var t = r[n];
        if (t + 1) return t;
        var e = new Error("Cannot find module '" + n + "'");
        throw ((e.code = "MODULE_NOT_FOUND"), e);
      }
      ((i.keys = function () {
        return Object.keys(r);
      }),
        (i.resolve = a),
        ((n.exports = i).id = 23));
    },
    function (n, t, e) {
      "use strict";
      function r() {
        return {
          restrict: "A",
          link: function (n, t) {
            t.bind("load", function () {
              n.$evalAsync(function () {
                n.isLoaded = !0;
              });
            });
          },
        };
      }
      (e.r(t), e(4).a.directive("imageLoad", r), (t.default = r));
    },
    function (n, t, e) {
      "use strict";
      function r() {
        return {
          scope: { thumbnailError: "<" },
          link: function (n, t) {
            t.on("error", n.thumbnailError);
          },
        };
      }
      (e.r(t), e(4).a.directive("thumbnailError", r), (t.default = r));
    },
    function (n, t, e) {
      var r = { "./thumbnailService.js": 27 };
      function i(n) {
        var t = a(n);
        return e(t);
      }
      function a(n) {
        var t = r[n];
        if (t + 1) return t;
        var e = new Error("Cannot find module '" + n + "'");
        throw ((e.code = "MODULE_NOT_FOUND"), e);
      }
      ((i.keys = function () {
        return Object.keys(r);
      }),
        (i.resolve = a),
        ((n.exports = i).id = 26));
    },
    function (n, t, e) {
      "use strict";
      e.r(t);
      var a = e(7),
        r = e(4);
      function i(n) {
        return {
          getThumbnailImage: function (e, r, i) {
            return n(function (t, n) {
              a.a
                .getThumbnailImage(e, r, i)
                .then(function (n) {
                  t(n);
                })
                .catch(n);
            });
          },
          getCssClass: function (n) {
            return a.a.getCssClass(n);
          },
          reloadThumbnailImage: function (e, r, i) {
            return n(function (t, n) {
              a.a
                .reloadThumbnailImage(e, r, i)
                .then(function (n) {
                  t(n);
                })
                .catch(n);
            });
          },
        };
      }
      ((i.$inject = ["$q"]),
        r.a.factory("thumbnailService", i),
        (t.default = i));
    },
    function (n, t, e) {
      var r = { "./components/templates/2dThumbnail.html": 29 };
      function i(n) {
        var t = a(n);
        return e(t);
      }
      function a(n) {
        var t = r[n];
        if (t + 1) return t;
        var e = new Error("Cannot find module '" + n + "'");
        throw ((e.code = "MODULE_NOT_FOUND"), e);
      }
      ((i.keys = function () {
        return Object.keys(r);
      }),
        (i.resolve = a),
        ((n.exports = i).id = 28));
    },
    function (n, t) {
      n.exports =
        '<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="{{ $ctrl.thumbnailType }}" thumbnail-target-id="{{ $ctrl.thumbnailTargetId }}"> <img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="{{ $ctrl.thumbnailUrl }}" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{\'loading\': $ctrl.thumbnailUrl && !isLoaded }" image-load/> <img ng-if="$ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled()" lazy-img="{{ $ctrl.thumbnailUrl }}" thumbnail-error="$ctrl.setThumbnailLoadFailed"/> </span>';
    },
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    function (n, t, e) {
      "use strict";
      e.r(t);
      var r = e(9),
        i = e.n(r),
        a = e(3),
        o = e(0),
        v = e(8),
        T = e.n(v),
        u = e(11),
        y = e.n(u),
        l = e(5),
        s = e.n(l),
        I = e(7);
      function c(n, t) {
        return (
          (function (n) {
            if (Array.isArray(n)) return n;
          })(n) ||
          (function (n, t) {
            var e = [],
              r = !0,
              i = !1,
              a = void 0;
            try {
              for (
                var o, u = n[Symbol.iterator]();
                !(r = (o = u.next()).done) &&
                (e.push(o.value), !t || e.length !== t);
                r = !0
              );
            } catch (n) {
              ((i = !0), (a = n));
            } finally {
              try {
                r || null == u.return || u.return();
              } finally {
                if (i) throw a;
              }
            }
            return e;
          })(n, t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to destructure non-iterable instance",
            );
          })()
        );
      }
      function m(n) {
        var t = n.errorIconClass,
          e = n.thumbnailUrl,
          r = n.imgClassName,
          i = n.containerClass,
          a = y()("thumbnail-2d-container", t, i),
          o = c(Object(v.useState)(y()(r, "loading")), 2),
          u = o[0],
          l = o[1];
        return T.a.createElement(
          "span",
          { className: a },
          e &&
            T.a.createElement("img", {
              className: u,
              src: e,
              alt: "",
              onLoad: function () {
                l(r);
              },
            }),
        );
      }
      ((m.defaultProps = {
        errorIconClass: "",
        thumbnailUrl: "",
        imgClassName: "",
        containerClass: "",
      }),
        (m.propTypes = {
          errorIconClass: s.a.string,
          thumbnailUrl: s.a.string,
          imgClassName: s.a.string,
          containerClass: s.a.string,
        }));
      var C = m;
      function S(n, t) {
        return (
          (function (n) {
            if (Array.isArray(n)) return n;
          })(n) ||
          (function (n, t) {
            var e = [],
              r = !0,
              i = !1,
              a = void 0;
            try {
              for (
                var o, u = n[Symbol.iterator]();
                !(r = (o = u.next()).done) &&
                (e.push(o.value), !t || e.length !== t);
                r = !0
              );
            } catch (n) {
              ((i = !0), (a = n));
            } finally {
              try {
                r || null == u.return || u.return();
              } finally {
                if (i) throw a;
              }
            }
            return e;
          })(n, t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to destructure non-iterable instance",
            );
          })()
        );
      }
      function f(n) {
        var t = n.type,
          e = n.baseTargetId,
          i = n.targetId,
          a = n.size,
          r = n.imgClassName,
          o = n.containerClass,
          u = n.format,
          l = S(Object(v.useState)(null), 2),
          s = l[0],
          c = l[1],
          m = S(Object(v.useState)(null), 2),
          f = m[0],
          d = m[1],
          h = y()(I.a.getCssClass(s)),
          b = S(Object(v.useState)("shimmer"), 2),
          g = b[0],
          p = b[1];
        return (
          Object(v.useEffect)(
            function () {
              var r = !1;
              return (
                (e
                  ? I.a.getThumbnailImageWithBaseTarget(t, e, i, a, u)
                  : I.a.getThumbnailImage(t, i, a, u)
                )
                  .then(function (n) {
                    var t = n.state,
                      e = n.imageUrl;
                    r || (c(t), d(e));
                  })
                  .finally(function () {
                    p("");
                  }),
                function () {
                  r = !0;
                }
              );
            },
            [t, i, a, r],
          ),
          T.a.createElement(C, {
            thumbnailUrl: f,
            errorIconClass: h,
            imgClassName: r,
            containerClass: y()(g, o),
          })
        );
      }
      ((f.defaultProps = {
        baseTargetId: 0,
        size: "150x150",
        imgClassName: "",
        containerClass: "",
        format: "png",
      }),
        (f.propTypes = {
          type: s.a.string.isRequired,
          baseTargetId: s.a.number,
          targetId: s.a.number.isRequired,
          size: s.a.string,
          format: s.a.string,
          imgClassName: s.a.string,
          containerClass: s.a.string,
        }));
      var d = f,
        h = (e(16), e(12), e(4));
      function b(n, t, e) {
        return (
          t in n
            ? Object.defineProperty(n, t, {
                value: e,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (n[t] = e),
          n
        );
      }
      ((window.RobloxThumbnails = (function (t) {
        for (var n = 1; n < arguments.length; n++) {
          var e = null != arguments[n] ? arguments[n] : {},
            r = Object.keys(e);
          ("function" == typeof Object.getOwnPropertySymbols &&
            (r = r.concat(
              Object.getOwnPropertySymbols(e).filter(function (n) {
                return Object.getOwnPropertyDescriptor(e, n).enumerable;
              }),
            )),
            r.forEach(function (n) {
              b(t, n, e[n]);
            }));
        }
        return t;
      })({ Thumbnail2d: d, thumbnailService: I.a }, o)),
        Object(a.importFilesUnderPath)(e(17)),
        Object(a.importFilesUnderPath)(e(19)),
        Object(a.importFilesUnderPath)(e(21)),
        Object(a.importFilesUnderPath)(e(23)),
        Object(a.importFilesUnderPath)(e(26)));
      var g = e(28);
      Object(a.templateCacheGenerator)(i.a, "thumbnailsTemplates", g, null);
      t.default = h.a;
    },
  ]);
  //# sourceMappingURL=https://js.rbxcdn.com/ac8b8944102dcb21992b-thumbnails.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("Thumbnails");
}
