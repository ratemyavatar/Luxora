var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (a) {
    var n = {};
    function o(e) {
      if (n[e]) return n[e].exports;
      var t = (n[e] = { i: e, l: !1, exports: {} });
      return (a[e].call(t.exports, t, t.exports, o), (t.l = !0), t.exports);
    }
    ((o.m = a),
      (o.c = n),
      (o.d = function (e, t, a) {
        o.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: a });
      }),
      (o.r = function (e) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 }));
      }),
      (o.t = function (t, e) {
        if ((1 & e && (t = o(t)), 8 & e)) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var a = Object.create(null);
        if (
          (o.r(a),
          Object.defineProperty(a, "default", { enumerable: !0, value: t }),
          2 & e && "string" != typeof t)
        )
          for (var n in t)
            o.d(
              a,
              n,
              function (e) {
                return t[e];
              }.bind(null, n),
            );
        return a;
      }),
      (o.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return (o.d(t, "a", t), t);
      }),
      (o.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (o.p = ""),
      o((o.s = 17)));
  })([
    function (e, t) {
      e.exports = React;
    },
    function (e, t) {
      e.exports = PropTypes;
    },
    function (e, t) {
      e.exports = ReactStyleGuide;
    },
    function (e, t) {
      e.exports = HeaderScripts;
    },
    function (e, t) {
      e.exports = CoreUtilities;
    },
    function (e, t) {
      e.exports = Roblox;
    },
    function (e, t, a) {
      var n;
      function c(e) {
        return (c =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      /*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
      /*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
      !(function () {
        "use strict";
        var l = {}.hasOwnProperty;
        function i() {
          for (var e = [], t = 0; t < arguments.length; t++) {
            var a = arguments[t];
            if (a) {
              var n = c(a);
              if ("string" === n || "number" === n) e.push(a);
              else if (Array.isArray(a) && a.length) {
                var o = i.apply(null, a);
                o && e.push(o);
              } else if ("object" === n)
                for (var r in a) l.call(a, r) && a[r] && e.push(r);
            }
          }
          return e.join(" ");
        }
        e.exports
          ? ((i.default = i), (e.exports = i))
          : "object" === c(a(11)) && a(11)
            ? void 0 ===
                (n = function () {
                  return i;
                }.apply(t, [])) || (e.exports = n)
            : (window.classNames = i);
      })();
    },
    ,
    function (e, t) {
      e.exports = CoreRobloxUtilities;
    },
    function (e, t) {
      e.exports = ReactUtilities;
    },
    function (e, t) {
      e.exports = ReactDOM;
    },
    function (t, e) {
      (function (e) {
        t.exports = e;
      }).call(this, {});
    },
    function (e, t, a) {},
    ,
    ,
    ,
    ,
    function (e, t, a) {
      "use strict";
      a.r(t);
      var n = a(0),
        c = a.n(n),
        o = a(10),
        i = a(4),
        r = "account-settings-language-selector",
        l = { common: [], feature: "CommonUI.Features" },
        s = [
          {
            name: "about",
            path: "/info/about-us",
            labelTranslationKey: "Label.AboutUs",
          },
          {
            name: "jobs",
            path: "/info/jobs",
            labelTranslationKey: "Label.Jobs",
          },
          {
            name: "blog",
            path: "/info/blog",
            labelTranslationKey: "Label.sBlog",
          },
          {
            name: "parents",
            path: "/info/parents",
            labelTranslationKey: "Label.Parents",
          },
          {
            name: "help",
            path: "/info/help",
            labelTranslationKey: "Label.Help",
          },
          {
            name: "terms",
            path: "/info/terms",
            labelTranslationKey: "Label.Terms",
          },
          {
            name: "privacy",
            path: "/info/privacy",
            labelTranslationKey: "Label.Privacy",
            cssClass: "privacy",
          },
        ],
        u = a(1),
        p = a.n(u),
        d = a(9),
        f = a(3),
        g = a(5);
      function h(e) {
        var t = e.translate,
          a = new Date().getFullYear();
        return c.a.createElement(
          "p",
          { className: "text-footer footer-note" },
          t("Description.CopyRightMessageDynamicYear", { copyrightYear: a }),
        );
      }
      h.propTypes = { translate: p.a.func.isRequired };
      var y = h,
        m = a(6),
        v = a.n(m),
        b = a(2);
      function L(e) {
        var n = e.translate,
          o = e.intl,
          t = s.map(function (e) {
            var t = {
                pathname: e.path,
                query: { locale: o.getRobloxLocale() },
              },
              a = v()("text-footer-nav", e.cssClass);
            return c.a.createElement(
              "li",
              { key: e.name, className: "footer-link" },
              c.a.createElement(
                b.Link,
                {
                  url: i.urlService.formatUrl(t),
                  cssClasses: a,
                  target: "_blank",
                },
                n(e.labelTranslationKey),
              ),
            );
          });
        return c.a.createElement("ul", { className: "row footer-links" }, t);
      }
      L.propTypes = {
        translate: p.a.func.isRequired,
        intl: p.a.shape({ getRobloxLocale: p.a.func.isRequired }).isRequired,
      };
      var w = L,
        U = a(8),
        S = U.eventStreamService.eventTypes,
        E = "Localization",
        x = {
          changeLanguage: {
            name: "changeLanguage",
            type: S.formInteraction,
            context: E,
            requiredParams: [
              "userId",
              "newSupportedLocaleCode",
              "previousSupportedLocaleCode",
            ],
          },
          changeLanguageModal: {
            name: "changeLanguageModal",
            type: S.formInteraction,
            context: E,
            requiredParams: ["userId", "newSupportedLocaleCode"],
          },
        },
        C = 6e5;
      function N(e) {
        return (N =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              })(e);
      }
      function O(e) {
        return (
          (function (e) {
            if (Array.isArray(e)) {
              for (var t = 0, a = new Array(e.length); t < e.length; t++)
                a[t] = e[t];
              return a;
            }
          })(e) ||
          (function (e) {
            if (
              Symbol.iterator in Object(e) ||
              "[object Arguments]" === Object.prototype.toString.call(e)
            )
              return Array.from(e);
          })(e) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to spread non-iterable instance",
            );
          })()
        );
      }
      function M(t) {
        for (var e = 1; e < arguments.length; e++) {
          var a = null != arguments[e] ? arguments[e] : {},
            n = Object.keys(a);
          ("function" == typeof Object.getOwnPropertySymbols &&
            (n = n.concat(
              Object.getOwnPropertySymbols(a).filter(function (e) {
                return Object.getOwnPropertyDescriptor(a, e).enumerable;
              }),
            )),
            n.forEach(function (e) {
              j(t, e, a[e]);
            }));
        }
        return t;
      }
      function j(e, t, a) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = a),
          e
        );
      }
      function P(e, t) {
        for (var a = 0; a < t.length; a++) {
          var n = t[a];
          ((n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n));
        }
      }
      function T(e) {
        return (T = Object.setPrototypeOf
          ? Object.getPrototypeOf
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            })(e);
      }
      function k(e) {
        if (void 0 === e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called",
          );
        return e;
      }
      function F(e, t) {
        return (F =
          Object.setPrototypeOf ||
          function (e, t) {
            return ((e.__proto__ = t), e);
          })(e, t);
      }
      function A(e) {
        return e.locale && e.locale.nativeName
          ? e.isEnabledForFullExperience
            ? e.locale.nativeName
            : "".concat(e.locale.nativeName, "*")
          : "";
      }
      var R = U.dataStores.localeDataStore,
        I = (function () {
          function a(e) {
            var t;
            return (
              (function (e, t) {
                if (!(e instanceof t))
                  throw new TypeError("Cannot call a class as a function");
              })(this, a),
              ((t = (function (e, t) {
                return !t || ("object" !== N(t) && "function" != typeof t)
                  ? k(e)
                  : t;
              })(this, T(a).call(this, e))).state = {
                supportedLocales: [],
                userLocale: {},
                showUnsupportedModal: !1,
                isUserLocaleUnsupported: !1,
                isLocaleUpdateInProgress: !1,
              }),
              (t.handleNativeLanguageChange = t.handleNativeLanguageChange.bind(
                k(t),
              )),
              (t.hideUnsupportedModal = t.hideUnsupportedModal.bind(k(t))),
              t
            );
          }
          return (
            (function (e, t) {
              if ("function" != typeof t && null !== t)
                throw new TypeError(
                  "Super expression must either be null or a function",
                );
              ((e.prototype = Object.create(t && t.prototype, {
                constructor: { value: e, writable: !0, configurable: !0 },
              })),
                t && F(e, t));
            })(a, c.a.Component),
            (function (e, t, a) {
              (t && P(e.prototype, t), a && P(e, a));
            })(a, [
              {
                key: "componentDidMount",
                value: function () {
                  this.loadSupportedLocales();
                },
              },
              {
                key: "getNativeSelector",
                value: function () {
                  var e = this.state,
                    t = e.supportedLocales,
                    a = e.userLocale,
                    n = t.map(function (e) {
                      return {
                        value: e.locale.locale,
                        key: e.locale.id,
                        label: A(e),
                      };
                    }),
                    o = a.locale && a.locale.locale;
                  return (
                    0 < n.length &&
                    c.a.createElement(b.NativeDropdown, {
                      id: "language-switcher",
                      selectionItems: n,
                      onChange: this.handleNativeLanguageChange,
                      selectedItemvalue: o,
                    })
                  );
                },
              },
              {
                key: "getDefaultSelector",
                value: function () {
                  var t = this,
                    e = this.state,
                    a = e.supportedLocales,
                    n = e.userLocale,
                    o = e.isLocaleUpdateInProgress,
                    r = a.map(function (e) {
                      return c.a.createElement(
                        b.Dropdown.Item,
                        {
                          key: e.locale.id,
                          onClick: function () {
                            return t.handleLanguageChange(e);
                          },
                        },
                        A(e),
                      );
                    }),
                    l = A(n);
                  return c.a.createElement(
                    b.Dropdown,
                    {
                      currSelectionLabel: l,
                      id: "language-switcher",
                      icon: "icon-globe",
                      disabled: o,
                    },
                    r,
                  );
                },
              },
              {
                key: "setUserLocaleByLocaleCode",
                value: function (e) {
                  var t = this.findSupportedLocaleByLocaleCode(e);
                  (this.setState({ userLocale: M({}, t) }),
                    t.isEnabledForFullExperience ||
                      this.showUnsupportedLocaleMessage());
                },
              },
              {
                key: "sortSupportedLocalesByFullExperience",
                value: function (e) {
                  if (Array.isArray(e)) {
                    var t = e
                        .filter(function (e) {
                          return e.isEnabledForFullExperience;
                        })
                        .sort(function (e, t) {
                          return e.locale.nativeName > t.locale.nativeName
                            ? 1
                            : -1;
                        }),
                      a = e
                        .filter(function (e) {
                          return !e.isEnabledForFullExperience;
                        })
                        .sort(function (e, t) {
                          return e.locale.nativeName > t.locale.nativeName
                            ? 1
                            : -1;
                        });
                    return [].concat(O(t), O(a));
                  }
                  return e;
                },
              },
              {
                key: "findSupportedLocaleByLocaleCode",
                value: function (t) {
                  return this.state.supportedLocales.find(function (e) {
                    return e.locale.locale === t;
                  });
                },
              },
              {
                key: "loadSupportedLocales",
                value: function () {
                  var t = this;
                  R.getLocalesWithCache(C).then(
                    function (e) {
                      (t.setState({
                        supportedLocales:
                          t.sortSupportedLocalesByFullExperience(e.data),
                      }),
                        t.loadUserLocale());
                    },
                    function (e) {
                      console.debug(e);
                    },
                  );
                },
              },
              {
                key: "loadUserLocale",
                value: function () {
                  var a = this,
                    e = i.urlService.getQueryParam("locale");
                  if (e) this.setUserLocaleByLocaleCode(e);
                  else {
                    var n = this.props.isAuthenticatedUser;
                    R.getUserLocale().then(
                      function (e) {
                        var t = n
                          ? e.data.ugc.locale
                          : e.data.signupAndLogin.locale;
                        a.setUserLocaleByLocaleCode(t);
                      },
                      function (e) {
                        console.debug(e);
                      },
                    );
                  }
                },
              },
              {
                key: "showUnsupportedLocaleModal",
                value: function (e) {
                  this.props.showWarningModalForUnsupportedLocale &&
                    (this.setState({ showUnsupportedModal: !0 }),
                    U.eventStreamService.sendEvent(x.changeLanguageModal, {
                      userId: f.authenticatedUser.id,
                      newSupportedLocaleCode: e.locale,
                    }));
                },
              },
              {
                key: "hideUnsupportedModal",
                value: function () {
                  (0, this.props.onLanguageChange)(this.state.userLocale);
                },
              },
              {
                key: "showUnsupportedLocaleMessage",
                value: function () {
                  this.props.showWarningMessageForUnsupportedLocale &&
                    this.setState({ isUserLocaleUnsupported: !0 });
                },
              },
              {
                key: "handleLanguageChange",
                value: function (e) {
                  var t = this,
                    a = M({}, e.locale),
                    n = this.state.userLocale,
                    o = this.props,
                    r = o.isAuthenticatedUser,
                    l = o.onLanguageChange,
                    i = M({}, n);
                  (r
                    ? (this.setState({ isLocaleUpdateInProgress: !0 }),
                      R.setUserLocale(a.locale)
                        .then(
                          function () {
                            e.isEnabledForFullExperience
                              ? l(a)
                              : (t.showUnsupportedLocaleMessage(),
                                t.showUnsupportedLocaleModal(a));
                          },
                          function (e) {
                            console.debug(e);
                          },
                        )
                        .finally(function () {
                          t.setState({ isLocaleUpdateInProgress: !1 });
                        }))
                    : l(a),
                    this.setUserLocaleByLocaleCode(a.locale),
                    U.eventStreamService.sendEvent(x.changeLanguage, {
                      userId: f.authenticatedUser.id,
                      newSupportedLocaleCode: a.locale,
                      previousSupportedLocaleCode: i.locale.locale,
                    }));
                },
              },
              {
                key: "handleNativeLanguageChange",
                value: function (e) {
                  var t = this.state.supportedLocales,
                    a = e.target.value,
                    n = t.find(function (e) {
                      return e.locale.locale === a;
                    });
                  this.handleLanguageChange(n);
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this.props,
                    t = e.translate,
                    a = e.isNative,
                    n = this.state,
                    o = n.showUnsupportedModal,
                    r = n.isUserLocaleUnsupported,
                    l = n.supportedLocales,
                    i = n.userLocale;
                  return c.a.createElement(
                    c.a.Fragment,
                    null,
                    0 < l.length && i.locale
                      ? c.a.createElement(
                          "div",
                          { className: "language-selector-wrapper" },
                          a
                            ? this.getNativeSelector()
                            : this.getDefaultSelector(),
                        )
                      : c.a.createElement(b.Loading, null),
                    c.a.createElement(b.SimpleModal, {
                      title: t("Heading.UnsupportedLanguage"),
                      body: t("Description.UnsupportedLanguage"),
                      show: o,
                      neutralButtonText: t("Action.Ok"),
                      onNeutral: this.hideUnsupportedModal,
                    }),
                    r &&
                      c.a.createElement(
                        "div",
                        { className: "row" },
                        c.a.createElement(
                          "span",
                          { className: "text text-error" },
                          t("Description.UnsupportedLanguage"),
                        ),
                      ),
                  );
                },
              },
            ]),
            a
          );
        })();
      ((I.defaultProps = {
        onLanguageChange: function () {},
        isAuthenticatedUser: !1,
        isNative: !1,
        showWarningModalForUnsupportedLocale: !0,
        showWarningMessageForUnsupportedLocale: !0,
      }),
        (I.propTypes = {
          isAuthenticatedUser: p.a.bool,
          onLanguageChange: p.a.func,
          isNative: p.a.bool,
          showWarningModalForUnsupportedLocale: p.a.bool,
          showWarningMessageForUnsupportedLocale: p.a.bool,
          translate: p.a.func.isRequired,
        }));
      var D = I;
      function _(e) {
        var n =
            i.pageName.PageNameProvider &&
            i.pageName.PageNameProvider.isLandingPage(),
          t =
            null === f.authenticatedUser || void 0 === f.authenticatedUser
              ? void 0
              : f.authenticatedUser.isAuthenticated,
          a = g.DeviceMeta && new g.DeviceMeta(),
          o = a && (a.isPhone || a.isTablet),
          r = t || n,
          l = e.translate;
        return c.a.createElement(
          "div",
          { className: "footer" },
          c.a.createElement(w, e),
          c.a.createElement(
            "div",
            { className: "row copyright-container" },
            c.a.createElement(
              "div",
              { className: "col-sm-6 col-md-3" },
              r &&
                c.a.createElement(D, {
                  translate: l,
                  onLanguageChange: function (e) {
                    var t = e.locale;
                    if (n && t) {
                      var a = {
                        pathname: window.location.pathname,
                        query: { locale: t },
                      };
                      window.location.href = i.urlService.formatUrl(a);
                    } else window.location.reload();
                  },
                  isAuthenticatedUser: t,
                  showWarningMessageForUnsupportedLocale: !1,
                  isNative: o,
                }),
            ),
            c.a.createElement(
              "div",
              { className: r ? "col-sm-6 col-md-9" : "col-sm-12" },
              c.a.createElement(y, e),
            ),
          ),
        );
      }
      _.propTypes = { translate: p.a.func.isRequired };
      var q = _;
      function B(e) {
        var t = e.translate,
          a = e.intl;
        return c.a.createElement(q, { translate: t, intl: a });
      }
      B.propTypes = {
        translate: p.a.func.isRequired,
        intl: p.a.shape({ getRobloxLocale: p.a.func.isRequired }).isRequired,
      };
      var K = Object(d.withTranslations)(B, l);
      var W = function (e, t) {
        g.DeviceMeta &&
          U.hybridService &&
          new g.DeviceMeta().isInApp &&
          U.hybridService.localization &&
          U.hybridService.localization(e, t);
      };
      function H(e) {
        var t = e.translate,
          a =
            null === f.authenticatedUser || void 0 === f.authenticatedUser
              ? void 0
              : f.authenticatedUser.isAuthenticated;
        return c.a.createElement(
          "div",
          { className: "col-xs-12 col-sm-6" },
          c.a.createElement(D, {
            onLanguageChange: function (e) {
              var t = e.locale;
              (t &&
                W(t, function () {
                  console.debug("Language Change Hybrid Event: ".concat(t));
                }),
                window.location.reload());
            },
            translate: t,
            isAuthenticatedUser: a,
            isNative: !0,
          }),
        );
      }
      H.propTypes = { translate: p.a.func.isRequired };
      var z = Object(d.withTranslations)(H, l);
      a(12);
      Object(i.ready)(function () {
        var e = document.getElementById("footer-container");
        e && Object(o.render)(c.a.createElement(K, null), e);
        var t = document.getElementById(r),
          a = 10;
        (!(function e() {
          !(t = document.getElementById(r)) && 0 < a
            ? ((a -= 1), setTimeout(e, 200))
            : t && Object(o.render)(c.a.createElement(z, null), t);
        })(),
          (window.onhashchange = function () {
            if ("#!/info" === window.location.hash) {
              var e = document.getElementById(r);
              e && Object(o.render)(c.a.createElement(z, null), e);
            }
          }));
      });
    },
  ]);
  //# sourceMappingURL=https://js.rbxcdn.com/7b7516a652a8504937a7-footer.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("Footer");
}
