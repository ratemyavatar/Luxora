var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  var Roblox = Roblox || {};
  Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
  Roblox.LangDynamicDefault["CommonUI.Features"] = {
    "Label.Avatar": "Avatar",
    "Label.Help": "Help",
    "Action.Ok": "Ok",
    "Label.sGames": "Games",
    "Label.sCatalog": "Catalog",
    "Label.sDevelop": "Develop",
    "Label.sRobux": "Robux",
    "Label.sSearch": "Search",
    "Label.sHome": "Home",
    "Label.sProfile": "Profile",
    "Label.sMessages": "Messages",
    "Label.sFriends": "Friends",
    "Label.sAvatar": "Avatar",
    "Label.sInventory": "Inventory",
    "Label.sTrade": "Trade",
    "Label.sGroups": "Groups",
    "Label.sForum": "Forum",
    "Label.sBlog": "Blog",
    "Label.sShop": "Shop",
    "Label.sEvents": "Events",
    "Label.sLogin": "Log In",
    "Label.sSignUp": "Sign Up",
    "Label.sSearchPhrase": 'Search "{phrase}" in {location}',
    "Action.sUpgradeNow": "Upgrade Now",
    "Label.AboutUs": "About Us",
    "Label.Careers": "Careers",
    "Label.Parents": "Parents",
    "Label.Terms": "Terms",
    "Label.Privacy": "Privacy",
    "Label.Jobs": "Jobs",
    "Label.Players": "Players",
    "Label.Library": "Library",
    "Label.Create": "Create",
    "Label.TermsOfUse": "Terms of Use",
    "Label.Upgrade": "Upgrade",
    "Label.CreateGroup": "Create Group",
    "Label.Favorites": "Favorites",
    "Label.CreateGame": "Create Game",
    "Label.ConfigurePlace": "Configure Place",
    "Label.Configure": "Configure",
    "Description.CopyRightMessage":
      "©2018 Roblox Corporation. Roblox, the Roblox logo and Powering Imagination are among our registered and unregistered trademarks in the U.S. and other countries.",
    "Label.ConfigureGame": "Configure Game",
    "Label.RedeemRobloxCards": "Redeem Roblox Cards",
    "Label.ConfigurePrivateServer": "Configure VIP Server",
    "Label.Support": "Support",
    "Label.ContactUs": "Contact Us",
    "Label.AuthenticationError": "Authentication Error",
    "Label.PlaceStatistics": "Place Statistics",
    "Label.Badges": "Badges",
    "Label.Thanks": "Thanks",
    "Heading.BuyItem": "Buy Item",
    "Action.BuyAccess": "Buy Access",
    "Action.Cancel": "Cancel",
    BuyAccessToGameForModal:
      "Would you like to buy access to the Place: {placeName} from {creatorName} for {robux}?",
    "Label.Feeds": "My Feed",
    "Action.BackToTop": "Back To Top",
    "Label.FindMyFeed": "Looking for My Feed? It's now in side menu",
    "Description.CopyRightMessageDynamicYear":
      "©{copyrightYear} Roblox Corporation. Roblox, the Roblox logo and Powering Imagination are among our registered and unregistered trademarks in the U.S. and other countries.",
    "Heading.UnsupportedLanguage": "Unsupported Language",
    "Description.UnsupportedLanguage":
      "While some games may use the selected language, it is not fully supported by roblox.com.",
    "Description.UnsupportedLanguageModal":
      "{userLanguage} is currently unavailable on roblox.com. You will see in-game content in {platformLanguage}, and roblox.com has been set to English.",
    "Label.Discover": "Discover",
    "Label.Merch": "Merchandise",
    "Label.Store": "Store",
    "Label.AvatarShop": "Avatar Shop",
    "Label.OfficialStore": "Official Store",
    "Label.GiftCards": "Gift Cards",
    "Label.RealNameVerified": "Real Name Verified",
    "Label.DisplayName": "Display Name",
    ActionsGetPremium: "Get Premium",
    "Label.CreateUserAd": "Create User Ad",
    ActionsPremium: "Premium",
    "Heading.ConfigurePrivateServer": "Configure Private Server",
  };
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected(
      "DynamicLocalizationResourceScript_CommonUI.Features",
    );
}
