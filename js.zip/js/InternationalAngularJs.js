var _____WB$wombat$assign$function_____ = function (name) {
  return (
    (self._wb_wombat &&
      self._wb_wombat.local_init &&
      self._wb_wombat.local_init(name)) ||
    self[name]
  );
};
if (!self.__WB_pmw) {
  self.__WB_pmw = function (obj) {
    this.__WB_source = obj;
    return this;
  };
}
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opens = _____WB$wombat$assign$function_____("opens");
  !(function (n) {
    var r = {};
    function o(t) {
      if (r[t]) return r[t].exports;
      var e = (r[t] = { i: t, l: !1, exports: {} });
      return (n[t].call(e.exports, e, e.exports, o), (e.l = !0), e.exports);
    }
    ((o.m = n),
      (o.c = r),
      (o.d = function (t, e, n) {
        o.o(t, e) || Object.defineProperty(t, e, { enumerable: !0, get: n });
      }),
      (o.r = function (t) {
        ("undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(t, "__esModule", { value: !0 }));
      }),
      (o.t = function (e, t) {
        if ((1 & t && (e = o(e)), 8 & t)) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (
          (o.r(n),
          Object.defineProperty(n, "default", { enumerable: !0, value: e }),
          2 & t && "string" != typeof e)
        )
          for (var r in e)
            o.d(
              n,
              r,
              function (t) {
                return e[t];
              }.bind(null, r),
            );
        return n;
      }),
      (o.n = function (t) {
        var e =
          t && t.__esModule
            ? function () {
                return t.default;
              }
            : function () {
                return t;
              };
        return (o.d(e, "a", e), e);
      }),
      (o.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
      }),
      (o.p = ""),
      o((o.s = 5)));
  })([
    function (t, e) {
      t.exports = Roblox;
    },
    function (t, e, n) {
      "use strict";
      var r = n(3),
        o = n.n(r).a.module("intlUtils", []);
      e.a = o;
    },
    ,
    function (t, e) {
      t.exports = angular;
    },
    function (t, e) {
      function a(t) {
        return t.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
      }
      function u(t) {
        return t.split("/").pop().replace(".html", "");
      }
      var n = {
        importFilesUnderPath: function (t) {
          t.keys().forEach(t);
        },
        templateCacheGenerator: function (t, e, r, o) {
          return t.module(e, []).run([
            "$templateCache",
            function (n) {
              (r &&
                r.keys().forEach(function (t) {
                  var e = a(u(t));
                  n.put(e, r(t));
                }),
                o &&
                  o.keys().forEach(function (t) {
                    var e = a(u(t));
                    n.put(
                      e,
                      (function (t) {
                        return t.replace(/<\/?script[^>]*>/gi, "");
                      })(o(t)),
                    );
                  }));
            },
          ]);
        },
      };
      t.exports = n;
    },
    function (t, e, n) {
      "use strict";
      n.r(e);
      var r = n(4);
      n(1);
      (Object(r.importFilesUnderPath)(n(6)),
        Object(r.importFilesUnderPath)(n(11)));
    },
    function (t, e, n) {
      var r = {
        "./datetime.js": 7,
        "./localNumberFormat.js": 8,
        "./translate.js": 9,
        "./translateParams.js": 10,
      };
      function o(t) {
        var e = a(t);
        return n(e);
      }
      function a(t) {
        var e = r[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((o.keys = function () {
        return Object.keys(r);
      }),
        (o.resolve = a),
        ((t.exports = o).id = 6));
    },
    function (t, e, n) {
      "use strict";
      n.r(e);
      var o = n(0);
      function r() {
        return function (t, e) {
          var n;
          if (
            "Invalid Date" ===
            (n =
              t && null !== t
                ? "string" == typeof t || "number" == typeof t
                  ? new Date(t)
                  : t
                : "Invalid Date").toString()
          )
            return t;
          var r = new o.Intl().getDateTimeFormatter();
          return "full" === e
            ? r.getFullDate(n)
            : "short" === e
              ? r.getShortDate(n)
              : e
                ? r.getCustomDateTime(n, e)
                : r.getShortDate(n);
        };
      }
      (n(1).a.filter("datetime", r), (e.default = r));
    },
    function (t, e, n) {
      "use strict";
      n.r(e);
      var r = n(1);
      function o(u) {
        return function (t, a) {
          if (!t) return t;
          var e = t;
          return (
            "string" != typeof t && (e = t.toString()),
            e.replace(/(\d+)/g, function (t, e, n, r) {
              if (e) {
                var o = Number(e);
                if (u.intl && o) return a ? u.intl.n(o, a) : u.intl.n(o);
              }
              return r;
            })
          );
        };
      }
      ((o.$inject = ["languageResource"]),
        r.a.filter("localNumberFormat", o),
        (e.default = o));
    },
    function (t, e, n) {
      "use strict";
      n.r(e);
      var r = n(1);
      function o(o, a) {
        return function (t, e, n) {
          var r = o.get(t, e, n);
          return r || (a.debug("Unable to translate key:".concat(t)), "");
        };
      }
      ((o.$inject = ["languageResource", "$log"]),
        r.a.filter("translate", o),
        (e.default = o));
    },
    function (t, e, n) {
      "use strict";
      n.r(e);
      var r = n(1);
      function o(i, c) {
        return function (t, e, n) {
          var r = {};
          for (var o in e)
            if (Object.prototype.hasOwnProperty.call(e, o)) {
              var a = i.get(e[o]);
              if (!a)
                return (c.debug("Unable to translate key:".concat(e[o])), "");
              r[o] = a;
            }
          var u = i.get(t, r, n);
          return u || (c.debug("Unable to translate key:".concat(t)), "");
        };
      }
      ((o.$inject = ["languageResource", "$log"]),
        r.a.filter("translateParams", o),
        (e.default = o));
    },
    function (t, e, n) {
      var r = { "./languageResourceProvider.js": 12 };
      function o(t) {
        var e = a(t);
        return n(e);
      }
      function a(t) {
        var e = r[t];
        if (e + 1) return e;
        var n = new Error("Cannot find module '" + t + "'");
        throw ((n.code = "MODULE_NOT_FOUND"), n);
      }
      ((o.keys = function () {
        return Object.keys(r);
      }),
        (o.resolve = a),
        ((t.exports = o).id = 11));
    },
    function (t, e, n) {
      "use strict";
      n.r(e);
      var r = n(3),
        i = n.n(r),
        c = n(0);
      function f(t) {
        return (f =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function o() {
        function t(t, e) {
          var n = o[t];
          return (
            n
              ? e && 0 < Object.keys(e).length && (n = u.f(n, e))
              : (console.warn(
                  "Language key '".concat(
                    t,
                    "' not found. Please check for any typo or a missing key.",
                  ),
                ),
                (n = "")),
            n
          );
        }
        function e(t, e, n) {
          if (n && "string" == typeof n) {
            if (a[n]) return a[n].get(t, e);
            throw new Error(
              "Provided Namespace '".concat(n, "' is not found or is not set"),
            );
          }
          return a[r].get(t, e);
        }
        var r,
          o = {},
          a = {},
          u = new c.Intl(),
          n = !1;
        ((this.setLanguageKeysFromFile = function (t) {
          t && "object" === f(t) && !Array.isArray(t) && i.a.extend(o, t);
        }),
          (this.setTranslationResources = function (t) {
            i.a.forEach(t, function (t) {
              ((a[t.namespace] = t), (n = !0), (r = r || t.namespace));
            });
          }),
          (this.$get = [
            function () {
              return { get: n ? e : t, intl: u };
            },
          ]));
      }
      (n(1).a.provider("languageResource", o), (e.default = o));
    },
  ]);
  //# sourceMappingURL=https://jsak.rbxcdn.com/1fcb6099a973a65303cf-internationalAngularJs.js.map

  /* Bundle detector */
  window.Roblox &&
    window.Roblox.BundleDetector &&
    window.Roblox.BundleDetector.bundleDetected("InternationalAngularJs");
}
